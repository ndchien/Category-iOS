//
//  Global.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 02/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "Global.h"


@implementation Global
static Global *pGlobal;
static TokenAccess *currentToken;
static TabBarViewController *currentTabbar;
static NSInteger countRequestFriend = 0;
static NSInteger countAllNotify = 0;
static NSInteger countNotifyCalender = 0;

#pragma mark - Return instance object
+ (instancetype) getInstance {
    if (!pGlobal) {
        pGlobal = [[Global alloc] init];
    }
    return pGlobal;
}

- (NSString *)currentTokenString{
    return currentToken.token_string;
}

- (void)setCurrentToken:(TokenAccess *)token{
    currentToken = token;
}

- (TokenAccess *)currentToken{
    if (!currentToken) {
        TokenAccess *token = [[TokenAccess MR_findAll]firstObject];
        NSLog(@"tokenString: %@", token.token_string);
        currentToken = token;
    }
    return currentToken;
}

- (void)deleteToken{
    self.currentToken = nil;
    [TokenAccess MR_truncateAll];
    SAVE_DATABASE;
}

+ (BOOL)tokenIsExpire:(TokenAccess *)token{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:KDATE_TOKEN];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:[[NSLocale preferredLanguages] objectAtIndex:0]];
    [format setLocale:locale];
    NSDate *date = [format dateFromString:token.token_expire];
    if (!date) {
        [format setDateFormat:KDATE_TOKEN1];
    }
    NSString *currentDate = [format stringFromDate:[NSDate date]];
    Order order = [Util compareDateStart:token.token_expire End:currentDate];
    if (order == OrderSame || order == OrderedAscending) {
        return YES;
    }
    return NO;
}

- (void)setTabbarCurrent:(TabBarViewController*)tabbar{
    currentTabbar = tabbar;
}
- (TabBarViewController*)getTabbarCurrent{
    return currentTabbar;
}

- (void)getListFriendsFromSever{
//    [[NetworksManager shareInstance] getListFriendsWithCallback:^(BOOL success, id result) {
//        if (success) {
//            // remove all Friends
//            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"bFriend = 1"];
//            [StudentObject MR_truncateWithPredicate:predicate];
//            
//            if ([result isKindOfClass:[NSArray class]]) {
//                for (NSDictionary *dict in result) {
//                    NSString *userName = [dict valueForKey:@"userName"];
//                    StudentObject *friend = [StudentObject MR_createEntity];
//                    friend.status = STT_OFFLINE;
//                    friend.username = userName;
//                    friend.bFriend = @"1";
//                }
//                SAVE_DATABASE;
//            }
//        }else{
//            NSLog(@"get list friend from server fail");
//        }
//    }];
}

- (NSString *)getUUIDDevice{
    static NSString *uuID;
    if (uuID.length == 0) {
        // get UDID
        NSString* uniqueIdentifier = nil;
        if( [UIDevice instancesRespondToSelector:@selector(identifierForVendor)] ) {
            // iOS 6+
            uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        } else {
            // before iOS 6, so just generate an identifier and store it
            uniqueIdentifier = [[NSUserDefaults standardUserDefaults] objectForKey:@"identiferForVendor"];
            if( !uniqueIdentifier ) {
                CFUUIDRef uuidRef = CFUUIDCreate(NULL);
                CFStringRef uuidStringRef = CFUUIDCreateString(NULL, uuidRef);
                CFRelease(uuidRef);
                uniqueIdentifier = [NSString stringWithString:(__bridge NSString *)uuidStringRef];
                CFRelease(uuidStringRef);
                [[NSUserDefaults standardUserDefaults] setObject:uniqueIdentifier forKey:@"identiferForVendor"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
        }
        uuID        = [uniqueIdentifier mutableCopy];
        NSLog(@"==================>>>>>>> UUID: %@", uuID);
    }
    return uuID;
}


// request friend
- (NSInteger)totalRequestFriend{
    return countRequestFriend;
}

- (void)setTotalRequestFriend:(NSInteger )count{
    countRequestFriend = count;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_REQUEST_FRIEND_RECIVE object:nil];
   // [self setTotalAllNotify:(countAllNotify+count)];
}


#pragma mark - setTotalAllNotify - Notify Tab

-(NSInteger)totalAllNotify{
    return countAllNotify;
}

- (void)setTotalAllNotify:(NSInteger )count{
    countAllNotify = count;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_REQUEST_NOTIFY_TAB object:nil];
}


#pragma mark - Khi chọn 1 lịch học rồi tạo thông báo thì nó phải báo số đỏ lịch mới ở icon lịch
-(NSInteger)getCountNotifyCalendar{
    return  countAllNotify;
}

-(void)setCountNotifyCalendar:(NSInteger)count{
    countNotifyCalender=count;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_NEW_CALENDAR_TAB object:nil];
}

- (void)resetDataLogout{
    FBSDKLoginManager *loginFB = [[FBSDKLoginManager alloc] init];
    if ([FBSDKAccessToken currentAccessToken]) {
        [FBSDKAccessToken setCurrentAccessToken:nil];
        [FBSDKProfile setCurrentProfile:nil];
        
        [loginFB logOut];
    }
    
    [StudentObject MR_truncateAll];
    [MyFriendObject MR_truncateAll];
    [MyFriendMenuFriendObject MR_truncateAll];
    [MessageStore MR_truncateAll];
    
    [[MessageManager getInstance].listUserUnRead removeAllObjects];
    SAVE_DATABASE;
    
    // stop hub
    [[MessageManager getInstance] stopConnection];
    [[HubConnectionOnline getInstance] disconnectOnline];
    
    // delete global token access
    SetBoolValue(YES, LOGOUT);
    SAVE_USER_DEFAULT;
}


@end
