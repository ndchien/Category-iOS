//
//  Constant.h
//  X-Youtube
//
//  Created by CMC iOS Dev on 21/07/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//



#ifndef X_Youtube_Constant_h
#define X_Youtube_Constant_h
typedef enum {
    Stt_Fail = 0,
    Stt_Success,
    Stt_Loading
}UploadStt;

typedef void (^Callback)(BOOL success, id result);
typedef void (^CallbackStt)(UploadStt stt, id result);

typedef  enum{
    OrderSame = 0,
    OrderedAscending = 1,
    OrderedDescending = 2
}Order;

typedef enum {
    KeyboardTypeAlpha = 0,
    KeyboardTypeEmoji,
    KeyboardTypeImages
}KeyboardType;

typedef void(^EMSVEventCalender)(BOOL granted, NSError *error);

// font Myrial Pro

// color Top: #4caf50   67 175 80   -> blur
// color : #acacac 175 175 175  -> darkgray
// color Text button: #ebebeb  235 235 235  -> lightgray
#define HEX_COLOR_GREEN             @"4caf50"
#define HEX_COLOR_LIGHTGRAY         @"ebebeb"
#define HEX_COLOR_DARKGRAY          @"acacac"
#define HEX_COLOR_BORDER_DEFAULT    @"E0E0E0"
#define BORDER_COLOR_HIGHLIGHT      [[UIColor colorWithRed:78/255.f green:220/255.f blue:255/255.f alpha:1.0f]CGColor]


//#define SERVER_API                  @"http://dev.emsv.vn:2020"

//#define SERVER_API                  @"http://192.168.35.132:28733"
//#define SERVER_API                  @"http://192.168.35.110:8088"

// Server Triển Khai
#define SERVER_API                  @"http://emsv.vn:2020"

#define CLIENT_SECRET               @"5YV7M1r981yoGhELyB84aC+KiYksxZf1OY3++C1CtRM="
#define CLIENT_ID                   @"iOS"
#define Provider_FACE               @"Facebook"



#define TOAST_NOTIFY_BACKGROUND_COLOR [UIColor colorWithRed:0.267f green:0.635f blue:0.267f alpha:1.00f]

//Khoảng cách màn hình chính cách bên phải , khi mà left menu được hiển thị
#define MAX_ITEM                    @"10"

#define RADIUS_BUTTON               5

#define TIME_OUT                    30
#define MIN_CHARACTER               4
#define MAX_CHARACTER               50
#define MIN_USER_GROUP              3

#define MENU_SLIDE_OFFSET           70
#define REFRESH_VIEW_HEIGHT         60

#define LINE_SPACE_IMAGE            4
#define ITEM_SPACE                  4
#define HEIGHT_ITEM_IMAGE           75
#define WIDTH_ITEM_IMAGE            104
#define HEIGHT_CMB_CELL             35
#define HEIGHT_DEFAULT_NEWSFEED_CELL 123

#define RECENT_EMOJIS               @"RecentUsedEmojiCharactersKey"
#define RECENT_EMOJIS_MAINTAINED_COUNT 50
#define OSDEmoticonsKeyboardDefaultSize {320,194}

#define REGULAR_VALID_PASSWORD      @"(?=.*?[0-9])(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[\\W_])[\\w\\W]+.{6,32}"

#define TYPE_EMAIL                  @"email" //^(?=.{6,32}$)(?=.*\d)(?=.*[a-zA-Z]).*$
#define TYPE_PHONE                  @"phone"
#define TYPE_UNIVER                 @"university"
#define TYPE_CLASS                  @"classs"

#define NEWSFEED_TYPE_UNIVERSITY    @"0"
#define NEWSFEED_TYPE_CLASS         @"1"
#define NEWSFEED_TYPE_USER          @"2"

#define NEWSFEED_NOTI_TYPE_UNIVERSITY @"IN_UNIVERSITY"
#define NEWSFEED_NOTI_TYPE_CLASS    @"IN_CLASS"
#define NEWSFEED_NOTI_TYPE_USER     @"PEOPLE"

#define NOTI_TYPE_ADD_COMMENT       @"ADD_NEW_COMMENT"
#define NOTI_TYPE_ADD_POSTS         @"ADD_NEW_POSTS"
#define NOTI_TYPE_LIKE_POSTS        @"LIKE_POSTS"
#define NOTI_TYPE_LIKE_COMMENT      @"LIKE_COMMENT"


#define FRIEND_NONE                 @"0"
#define FRIEND_SEND_REQUEST         @"1"
#define FRIEND_RECIVE_REQUEST       @"2"
#define FRIEND_SUCCESS              @"3"

#define FRIEND_TYPE_CLASS           @"1"
#define FRIEND_TYPE_UNIVERSITY      @"0"


#define COUNT_UNREAD_NEWSFEED       0
#define COUNT_UNREAD_UNIVERSITY     1
#define COUNT_UNREAD_CLASS          2
#define COUNT_UNREAD_SCHEDULE_TEST  3
#define COUNT_UNREAD_SCHEDULE       4

#define LIMIT_SHOW_NOTIFY_ITEM       20




#define MESG_TYPE_USER              @"U"
#define MESG_TYPE_GROUP             @"G"

#define STT_ONLINE                  @"1"
#define STT_OFFLINE                 @"0"


#define TAG_SUBJECT_VIEW            11

// notification
#define NOTI_POST_NOTIFICATION_INFO     @"PostNotificationInfo"

#define NOTI_INTERNET_CONNECTED         @"NotificationInternetConnected"
#define NOTI_INTERNET_DISCONNECT        @"NotificationInternetDisconnect"
#define NOTI_ONLINE_CHANGED             @"NotificationFriendOnlineChange"
#define NOTI_ONLINE_CHANGE_STT          @"NotificationFriendChangeStatus"
#define NOTI_MESG_USER_UNREAD           @"NotificationUserMessageUnReadChange"
#define NOTI_GET_LIST_MAY_BE_CHANGE_FRIEND  @"NotificationGetListMaybeChangeFriend"
#define NOTI_MESG_UNREAD                @"NotificationMessageUnRead"
#define NOTI_MESG_UNREAD_NEW_GROUP      @"NotificationMessageNewGroup"
#define NOTI_REQUEST_FRIEND_RECIVE      @"NotificationRequestFriend"
#define NOTI_NOTIFICATION_RECIVE        @"NotificationNewRecived"
#define NOTI_REQUEST_NOTIFY_TAB         @"NotificationRequestNotifyTab"
#define NOTI_NEW_CALENDAR_TAB           @"NotificationNewCalendarTab"
#define NOTI_ACCEPT_FRIEND              @"NotificationAcceptFriendRequest"
#define NOTI_NEWSFEED                   @"NotificationNewsfeedAll"


// Message
#define MESG_BLANK(typeName)        [NSString stringWithFormat:@"%@ phải lớn hơn %d kí tự", typeName, MIN_CHARACTER]
#define MESG_EMAIL_INVALID          @"Email không hợp lệ."
#define MESG_EMAIL_CONFIRM_INVALID  @"Xác nhận email không hợp lệ."
#define MESG_LOGIN_FAIL             @"Tên đăng nhập hoặc mật khẩu không đúng."
#define MESG_NOT_EXIST              @"Tài khoản này chưa tồn tại."
#define MESG_PASSWORD_INVALID       @"Mật khẩu phải có ít nhất 1 kí tự viết hoa, 1 viết thường, số, 1 ký tự khác."

// setting
#define CURRENT_VIEWCONTROLLER_NAME @"CURRENT_VIEWCONTROLLER_NAME"
#define MESG_USER_UNREAD(username)            [NSString stringWithFormat:@"MessageUserUnRead_%@", username]
#define KEY_SETTING_NOTI_GROUP(username, groupId) [NSString stringWithFormat:@"%@+++%@", username,groupId]

#define LOGOUT                      @"Logout"

#define LESSON_COLOR_0001           @"9C27B0"
#define LESSON_COLOR_0002           @"D32F2F"
#define LESSON_COLOR_0003           @"42A5F6"
#define LESSON_COLOR_0004           @"FBC02D"


#define BoolValue(key)              [[NSUserDefaults standardUserDefaults] boolForKey:key]
#define SetBoolValue(value, key)    [[NSUserDefaults standardUserDefaults] setBool:value forKey:key]

#define UserValue(key)              [[NSUserDefaults standardUserDefaults] valueForKey:key]
#define SetValueUser(value, key)    [[NSUserDefaults standardUserDefaults] setValue:value forKey:key]

#define GetStringValue(key)         [[NSUserDefaults standardUserDefaults] stringForKey:key]
#define SetStringValue(vlue, key)   [[NSUserDefaults standardUserDefaults] setValue:vlue forKey:key]
#define SAVE_DATABASE               [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait]
#define SAVE_USER_DEFAULT           [[NSUserDefaults standardUserDefaults] synchronize]

#define kSERVER_DATE_FORMAT         @"yyyy-MM-dd HH:mm:ss"
#define KDATE_TOKEN                 @"MM/dd/yyyy HH:mm:ss a Z"
#define KDATE_TOKEN1                @"EEE, dd MMM yyyy HH:mm:ss 'GMT'"
#define KDATE_MESSAGE               @"MM/dd/yyyy hh:mm:ss a"
#define KDATE_SHORT                 @"MM/dd/yyyy"
#define KDATE_LESSON                @"dd/MM/yyyy"

// SERVICE API =====================
#pragma mark -  REGISTER & LOGIN
#define API_REGISTER_NORMAL         [NSString stringWithFormat:@"%@/api/Account/Register", SERVER_API]

#define API_REGISTER_FACEBOOK       [NSString stringWithFormat:@"%@/api/Account/RegisterExternal", SERVER_API]

#define API_LOGIN_REFRESH_NORMAL    [NSString stringWithFormat:@"%@/authtoken", SERVER_API]

#define API_LOGIN_FACEBOOK          [NSString stringWithFormat:@"%@/api/Account/RegisterExternal", SERVER_API]

#define API_GET_TOKEN_BY_FACEBOOK   [NSString stringWithFormat:@"%@/api/Account/ObtainLocalAccessToken", SERVER_API]

#define API_GET_FRIENDS             [NSString stringWithFormat:@"%@/api/Account/GetFriendChat", SERVER_API]

#define API_GET_INVITE_FRIENDS      [NSString stringWithFormat:@"%@/api/Account/GetListFriendRequest", SERVER_API] //api/Account/GetListFriendRequest

#define API_GET_MY_FRIENDS          [NSString stringWithFormat:@"%@/api/Account/GetListFriends", SERVER_API]

#define API_GET_MY_FRIENDS_CHAT      [NSString stringWithFormat:@"%@/api/Account/GetListFriendsMess", SERVER_API]


#define API_GET_LINK_APP            [NSString stringWithFormat:@"%@/api/DownloadApp/GetLinkAppEmSV", SERVER_API]

#define API_SEND_PRODUCT_COMMENT      [NSString stringWithFormat:@"%@/api/FeedBack/SendProductComments", SERVER_API]

#define API_SEND_PRODUCT_ERROR      [NSString stringWithFormat:@"%@/api/FeedBack/SendProductErrors", SERVER_API]

#define API_GET_MAY_BE_FRIENDS      [NSString stringWithFormat:@"%@/api/Account/GetListFriendMayKnow", SERVER_API]

#define API_REMOVE_FRIENDS          [NSString stringWithFormat:@"%@/api/Account/RemoveFriendRequest", SERVER_API]

#define API_REMOVE_MY_FRIENDS          [NSString stringWithFormat:@"%@/api/Account/RemoveFriend", SERVER_API]

#define API_ADD_FRIENDS             [NSString stringWithFormat:@"%@/api/Account/SendInviteFriendRequest", SERVER_API]

#define API_ACCEPT_FRIENDS          [NSString stringWithFormat:@"%@/api/Account/AcceptFriendRequest", SERVER_API]

#define API_GET_LIST_FRIENDS_SEARCH [NSString stringWithFormat:@"%@/api/Account/SearchFriendInvite", SERVER_API]

#define API_CONFIRM_UNIVERSITY      [NSString stringWithFormat:@"%@/api/Warrant/WarrantUniversity", SERVER_API]

#define API_GET_LIST_UNIVERSITY     [NSString stringWithFormat:@"%@/api/University/GetList", SERVER_API]

#define API_UPLOAD_AVATAR           [NSString stringWithFormat:@"%@/api/Uploading/Post", SERVER_API]

#define API_GET_FRIEND_CLASS                [NSString stringWithFormat:@"%@/api/Account/GetFriendsByClass", SERVER_API]

#define API_GET_FRIEND_UNIVERSITY           [NSString stringWithFormat:@"%@/api/Account/GetFriendsByUniversity", SERVER_API]

#define API_GET_FRIEND_NONE_UNIVERSITY      [NSString stringWithFormat:@"%@/api/Account/GetFriendsNotUniversity", SERVER_API]


#pragma mark -  CHANGE PASSWORD
#define API_SEARCH_ACCOUNT          [NSString stringWithFormat:@"%@/api/ChangePassword/SearchAccount", SERVER_API]

#define API_CHANGE_PASSWORD         [NSString stringWithFormat:@"%@/api/ChangePassword/Change", SERVER_API]

#define API_GET_CODE_CHANGE_PASS    [NSString stringWithFormat:@"%@/api/ChangePassword/GetCode", SERVER_API]

#define API_VERIFY_CODE_CHANGE_PASS [NSString stringWithFormat:@"%@/api/ChangePassword/Verify", SERVER_API]

#define API_VERIFY_CODE_UNIVERCITY_CHANGE_PASS [NSString stringWithFormat:@"%@/api/Account/Validated", SERVER_API]

#define API_GET_MENU                [NSString stringWithFormat:@"%@/api/Menu/GetMenus", SERVER_API]

#define API_GET_STUDENT_INFO        [NSString stringWithFormat:@"%@/api/Menu/GetUserInfo", SERVER_API]

#define API_GET_NEWSFEED_UNREAD     [NSString stringWithFormat:@"%@/api/News/GetNewsUread", SERVER_API]

#define API_POST_STT_READ           [NSString stringWithFormat:@"%@/api/News/UpdateStatusNews", SERVER_API]


#pragma mark -  CHAT
#define API_SEND_MESSAGE            [NSString stringWithFormat:@"%@/api/Message/SendMessage", SERVER_API]

#define API_GET_LAST_MESSAGE        [NSString stringWithFormat:@"%@/api/Message/getMessagesBy", SERVER_API]

#define API_CREATE_GROUP            [NSString stringWithFormat:@"%@/api/Message/CreateGroupChat", SERVER_API]

#define API_ADD_USER_GROUP          [NSString stringWithFormat:@"%@/api/Message/AddUserForGroup", SERVER_API]

#define API_DELETE_USER_GROUP       [NSString stringWithFormat:@"%@/api/Message/DeleteUserForGroup", SERVER_API]

#define API_GET_USER_GROUP          [NSString stringWithFormat:@"%@/api/Message/GetListUserByGroupId", SERVER_API]

#define API_GET_GROUPS_BY_USER      [NSString stringWithFormat:@"%@/api/Message/GetListGroupByUserName", SERVER_API]




#pragma mark -  CALENDAR
#define API_GET_LESSON_WEEKEND      [NSString stringWithFormat:@"%@/api/Subject/GetLessonsByWeek", SERVER_API]

#define API_GET_DETAIL_LESSON_BY_ID [NSString stringWithFormat:@"%@/api/Subject/GetLessonById", SERVER_API]

#define API_GET_LESSON_RANGE_DATE   [NSString stringWithFormat:@"%@/api/Subject/GetLessonsByRange", SERVER_API]

#define API_GET_LESSON_MONTH        [NSString stringWithFormat:@"%@/api/Subject/GetLessonsByMonth", SERVER_API]

#define API_CREATE_NOTICE_LESSON    [NSString stringWithFormat:@"%@/api/Subject/CreateNotice", SERVER_API]

#define API_GET_NOTICE_LESSON       [NSString stringWithFormat:@"%@/api/Subject/GetNoticesByLesson", SERVER_API]

#define API_DELETE_NOTICE_LESSON    [NSString stringWithFormat:@"%@/api/Subject/DeleteNotice", SERVER_API]



#pragma mark -  LOOKUP SCORES
#define API_GET_DEPARTMENTS         [NSString stringWithFormat:@"%@/api/Department/GetList", SERVER_API]

#define API_GET_COURSE              [NSString stringWithFormat:@"%@/api/Course/GetCourseNames", SERVER_API]

#define API_GET_DETAIL_SEMESTER     [NSString stringWithFormat:@"%@/api/Course/GetMarkByCourse", SERVER_API]

#define API_GET_COURSE_TOTAL        [NSString stringWithFormat:@"%@/api/Course/GetCourseInfo", SERVER_API]

#define API_GET_SUBJECT_SCORE_DETAIL(subID) [NSString stringWithFormat:@"%@/api/Course/GetSubjectInfo?SubjectId=%@", SERVER_API, subID]



#pragma mark -  API Thao tác với lớp học
#define API_GET_CLASS_INFO             [NSString stringWithFormat:@"%@/api/Classes/GetClassInfo", SERVER_API]  //Lấy thông tin lớp của sinh viên

#define API_LIKE_FAN_PAGE_CLASS        [NSString stringWithFormat:@"%@/api/Classes/like_fanpage_class", SERVER_API]  //Like lớp của tôi

#define API_ADD_POST_CLASS             [NSString stringWithFormat:@"%@/api/Posts/add_post_class", SERVER_API]  //Đăng bài

#define API_LIKE_POST_CLASS            [NSString stringWithFormat:@"%@/api/Classes/GetClassInfo", SERVER_API]  //Like bài viết

#define API_ADD_COMMENT_CLASS            [NSString stringWithFormat:@"%@/api/Posts/add_comment_class", SERVER_API]

#define API_LIST_COMMENT_POST_CLASS            [NSString stringWithFormat:@"%@/api/Classes/GetClassInfo", SERVER_API]

#define API_LIST_POST_CLASS            [NSString stringWithFormat:@"%@/api/Posts/list_post_class", SERVER_API]

#define API_LIST_MEMBER_CLASS            [NSString stringWithFormat:@"%@/api/Classes/GetMembersInGroup", SERVER_API]


#pragma mark -  MY UNIVERSITY
#define API_GET_DETAIL_UNIVERSITY       [NSString stringWithFormat:@"%@/api/University/GetUniInfo", SERVER_API]

#define API_GET_INTRODUCT_UNIVERSITY    [NSString stringWithFormat:@"%@/api/University/GetInstruction", SERVER_API]

#define API_GET_DEPARTMENT_UNIVERSITY   [NSString stringWithFormat:@"%@/api/Department/GetDepartments", SERVER_API]

#define API_GET_FACULTY_UNIVERSITY      [NSString stringWithFormat:@"%@/api/Department/GetFaculties", SERVER_API]

#define API_GET_NEWSFEED_UNIVERSITY     [NSString stringWithFormat:@"%@/api/Posts/GetPostsInUniversity", SERVER_API]

#define API_POST_LIKE_UNIVERSITY_PAGE   [NSString stringWithFormat:@"%@/api/University/like_fanpage_university", SERVER_API]

#define API_POST_LIKE_NEWSFEED          [NSString stringWithFormat:@"%@/api/Posts/like_post", SERVER_API]

#define API_POST_LIKE_COMMENT           [NSString stringWithFormat:@"%@/api/Posts/like_comment", SERVER_API]

#define API_GET_MEMBER_UNIVERSITY       [NSString stringWithFormat:@"%@/api/University/GetListMembers", SERVER_API]



#pragma mark -  STUDENT
#define API_GET_NEWSFEED_STUDENT        [NSString stringWithFormat:@"%@/api/NewsFeed/GetList", SERVER_API]

#define API_GET_COMMENT_NEWSFEED        [NSString stringWithFormat:@"%@/api/Posts/GetListCommentByPostsId", SERVER_API]

#define API_GET_NEWSFEED_BY_ID          [NSString stringWithFormat:@"%@/api/Posts/GetPostById", SERVER_API]


#pragma mark -  THONG TIN NGUOI DUNG
#define API_GET_PROFILE_USER            [NSString stringWithFormat:@"%@/api/Account/GetUserProfile", SERVER_API] // Lay thong tin nguoi dung

#define API_GET_PROFILE_BY_USER         [NSString stringWithFormat:@"%@/api/Account/GetUserProfileByUserId", SERVER_API]

#define API_UPDATE_PROFILE_USER         [NSString stringWithFormat:@"%@/api/Account/UpdateUserProfile", SERVER_API]  // Cap nhat thong tin nguoi dung


#pragma mark - CAU HINH
#define API_SETTING_CHANGE_PASSWORD      [NSString stringWithFormat:@"%@/api/ChangePassword/Change", SERVER_API]  // Thay doi mat khau

#define API_SETTING_CHANGE_EMAIL         [NSString stringWithFormat:@"%@/api/Account/ChangeEmail", SERVER_API]  // Thay doi Email

#define API_SETTING_GET_CODE      [NSString stringWithFormat:@"%@/api/ChangePassword/GetCode", SERVER_API]  //Lấy mã xác nhận

#define API_SETTING_VERIFY_CODE      [NSString stringWithFormat:@"%@/api/ChangePassword/Verify", SERVER_API]  //Xác nhận mã xác thực

#define API_SETTING_CONFIG_SHOW_NOTIFICATION  [NSString stringWithFormat:@"%@/api/Account/ConfigShowNotification", SERVER_API]  //Cấu hình hiển thị thông báo




#pragma mark -  NOTIFICATION

#define API_GET_ALL_NOTIFICATION    [NSString stringWithFormat:@"%@/api/Notification/GetList", SERVER_API]















































#endif
