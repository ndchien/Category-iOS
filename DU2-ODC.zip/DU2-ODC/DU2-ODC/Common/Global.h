//
//  Global.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 02/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TokenAccess.h"
#import "TabBarViewController.h"
#import "MessageStore.h"
#import "MyFriendMenuFriendObject.h"

@interface Global : NSObject
@property (assign, nonatomic) NSInteger countUniversityUnread;
@property (assign, nonatomic) NSInteger countClassUnread;
@property (assign, nonatomic) NSInteger countNewsfeedUnread;
@property (assign, nonatomic) NSInteger countScheduleTestUnread;
@property (assign, nonatomic) NSInteger countScheduleUnread;

+ (instancetype) getInstance;
- (NSString *)currentTokenString;
- (NSInteger)totalRequestFriend;

-(NSInteger)totalAllNotify;
    
- (void)setTotalRequestFriend:(NSInteger)count;

- (void)setCurrentToken:(TokenAccess *)token;
- (TokenAccess *)currentToken;
- (void)deleteToken;
+ (BOOL)tokenIsExpire:(TokenAccess *)token;

- (void)setTabbarCurrent:(TabBarViewController*)tabbar;
- (TabBarViewController*)getTabbarCurrent;

- (void)getListFriendsFromSever;

- (NSString *)getUUIDDevice;

- (void)setTotalAllNotify:(NSInteger )count;


#pragma mark - Khi chọn 1 lịch học rồi tạo thông báo thì nó phải báo số đỏ lịch mới ở icon lịch
-(NSInteger)getCountNotifyCalendar;

-(void)setCountNotifyCalendar:(NSInteger)count;

- (void)resetDataLogout;

@end
