//
//  HubConnectionOnline.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 17/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "HubConnectionOnline.h"

@implementation HubConnectionOnline
+ (instancetype)getInstance{
    static HubConnectionOnline *instance;
    if (instance == nil) {
        instance = [[HubConnectionOnline alloc] init];
    }
    
    return instance;
}

- (void)connectHubOnline{
    if (connectionOnline) {
        [self disconnectOnline];
    }
    
    TokenAccess *token = [Global getInstance].currentToken;
    if (token == nil) {
        return;
    }
    NSString *server = [Router sharedRouter].server_url;
    
    connectionOnline = [SRHubConnection connectionWithURLString:server];
    [connectionOnline addValue:token.username forHTTPHeaderField:@"MHub-Username"];
    
    hubOnline = [connectionOnline createHubProxy:@"MobiUserOnlineHub"];
    
    [[hubOnline state] setValue:@YES forKey:@"focus"];
    [[hubOnline state] setValue:0 forKey:@"unread"];
    [hubOnline on:@"ClientBroadOnline" perform:self selector:@selector(reciveOnlineStatus:)];
    
    [connectionOnline setDelegate:self];
    [connectionOnline start];
    
    
//    [self connectHubFriend];
}

- (void)connectHubFriend{
    if (connectionFriend) {
        [self disconnectFriend];
    }
    
    TokenAccess *token = [Global getInstance].currentToken;
    if (token == nil) {
        return;
    }
    NSString *server = [Router sharedRouter].server_url;
    
    connectionFriend = [SRHubConnection connectionWithURLString:server];
    [connectionFriend addValue:token.username forHTTPHeaderField:@"MHub-Username"];
    
    hubFriend = [connectionFriend createHubProxy:@"MobiFriendRequestHub"];
    
    [[hubFriend state] setValue:@YES forKey:@"focus"];
    [[hubFriend state] setValue:0 forKey:@"unread"];
    [hubFriend on:@"ClientFriendsBroadcast" perform:self selector:@selector(reciveFriendRequestOnline:)];
    
    [hubFriend on:@"getCountFriendsRequest" perform:self selector:@selector(reciveFriendRequestOffline:)];
    
    [hubFriend on:@"ClientNotificationBroadcast" perform:self selector:@selector(reciveNewNotification:)];
    
    [hubFriend on:@"ClientScheduleBroadcast" perform:self selector:@selector(reciveNotificationSchedule:)];
    
    [hubFriend on:@"ClientAcceptFriendsRequest" perform:self selector:@selector(reciveNotificationAcceptFriend:)];
    
    [connectionFriend setDelegate:self]; //RequestFriendAccept
    [connectionFriend start];
    
}

// DISCONNECT HUB
- (void)disconnectOnline{
    [connectionOnline stop];
    hubOnline = nil;
    connectionOnline.delegate = nil;
    connectionOnline = nil;
    [self disconnectFriend];
}

- (void)disconnectFriend{
    [connectionFriend stop];
    hubFriend = nil;
    connectionFriend.delegate = nil;
    connectionFriend = nil;
}

// call hub
- (void)acceptFriendWithUsername:(NSString*)username{
    [hubFriend invoke:@"RequestFriendAccept" withArgs:@[username]];
}



- (void)reciveOnlineStatus:(id)data{
//    NSLog(@"Data User Change status: %@", data);
    if ([data isKindOfClass:[NSDictionary class]]) {
        NSString *username  = [data valueForKey:@"UserName"];
        NSString *webStt    = [data valueForKey:@"Web"];
        NSString *mobileStt = [data valueForKey:@"Mobile"];
        NSString *status    = (webStt.boolValue || mobileStt.boolValue)?@"1":@"0";
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ONLINE_CHANGE_STT object:@{@"username":username, @"status":status}];
        
        MyFriendObject *myFriendObj = [[MyFriendObject MR_findByAttribute:@"username" withValue:username] firstObject];
        if (!myFriendObj) {
            myFriendObj             = [MyFriendObject MR_createEntity];
        }
        myFriendObj.statusUser      = status;
        myFriendObj.userId          = username;
        myFriendObj.username        = username;
        SAVE_DATABASE;
    }
}

- (void)reciveFriendRequestOnline:(id)data{
//    NSLog(@"data: %@", data);
    if (data) {
        NSString *username = [NSString stringWithFormat:@"%@", data];
        if ([username isEqualToString:[Global getInstance].currentToken.username]) {
            NSInteger count = [Global getInstance].totalRequestFriend;
            [[Global getInstance] setTotalRequestFriend:count+1];
        }
    }
    
}

- (void)reciveFriendRequestOffline:(id)data{
//    NSLog(@"data: %@", data);
    [[Global getInstance] setTotalRequestFriend:[data integerValue]];
}

- (void)reciveNewNotification:(id)data{
    NSLog(@"data: %@", data);
    if ([data isKindOfClass:[NSDictionary class]]) {
        NSString *username = [data valueForKey:@"UserName"];
        if (![username isEqualToString:[Global getInstance].currentToken.username]) {
            NSInteger countNew = [Global getInstance].totalAllNotify;
            [[Global getInstance] setTotalAllNotify:countNew+1];
            
            [hubFriend invoke:@"UpdateNotification" withArgs:@[data[@"Id"]]];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_NEWSFEED object:data];
        }
    }
    
}

- (void)reciveNotificationSchedule:(id)data{
//    NSLog(@"data: %@", data);
    if ([data isKindOfClass:[NSDictionary class]]) {
        NSString *username = [data valueForKey:@"UserName"];
        if (![username isEqualToString:[Global getInstance].currentToken.username]) {
            [hubFriend invoke:@"UpdateNotification" withArgs:@[data[@"Id"]]];
            [[Global getInstance] setCountNotifyCalendar:[Global getInstance].countScheduleUnread+1];
            
            
        }
    }
}

- (void)reciveNotificationAcceptFriend:(id)data{
//    NSLog(@"adfadsf");
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ACCEPT_FRIEND object:nil];
}

- (void)updateNotification{
    
}

#pragma mark -
#pragma mark SRConnection Delegate

- (void)SRConnectionDidOpen:(SRConnection *)connection
{

}

- (void)SRConnectionWillReconnect:(id<SRConnectionInterface>)connection{
    NSLog(@"HubOnline reconnect");
}

- (void)SRConnectionDidReconnect:(id<SRConnectionInterface>)connection{
    NSLog(@"HubOnline Did reconnect");
}

- (void)SRConnection:(SRConnection *)connection didReceiveData:(id)data
{
}

- (void)SRConnectionDidClose:(SRConnection *)connection
{
    NSLog(@"HubOnline Did Close");
}

- (void)SRConnection:(SRConnection *)connection didReceiveError:(NSError *)error
{

}

@end
