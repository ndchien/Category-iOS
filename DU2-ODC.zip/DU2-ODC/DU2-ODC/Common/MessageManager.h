//
//  MessageManager.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 06/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ModelDataMessage.h"
#import "SRHubProxy.h"

@protocol  MessageManagerDelegate <NSObject>

@optional
- (void)reciveMessageWithObject:(JSQMessage*)message Saved:(BOOL)saved;
- (void)reciveMessageMe:(JSQMessage*)message Saved:(BOOL)saved Device:(NSString*)device;
- (void)connectionDidConnect;
- (void)connectionDidClose;
@end

@interface MessageManager : NSObject<JSQMessagesComposerTextViewPasteDelegate, SRConnectionDelegate>
{
    SRHubConnection *connection;
    SRHubProxy *hub;
    

}
@property (strong, nonatomic) SRHubConnection *connection;
@property (assign, nonatomic) BOOL bActive;
@property (strong, nonatomic) ModelDataMessage *demoData;
@property (strong, nonatomic) NSMutableArray *listUserUnRead;
@property (assign, nonatomic) BOOL bChating;
@property (strong, nonatomic) id<MessageManagerDelegate> delegate;
- (void)checkConnection;
+ (MessageManager *)getInstance;
- (void)stopConnection;
- (void)connectHub;

-(void)LoadUserMessageUnRead;
-(void)addUserMessageUnRead:(id)obj Type:(NSString*)type;
- (void)removeUserMessageUnRead:(id)obj;
- (void)changeStatusOnline:(BOOL)status;
@end
