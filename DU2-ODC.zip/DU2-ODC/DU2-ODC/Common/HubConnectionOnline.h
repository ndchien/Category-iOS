//
//  HubConnectionOnline.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 17/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HubConnectionOnline : NSObject <SRConnectionDelegate>{
    SRHubConnection *connectionOnline;
    SRHubProxy *hubOnline;
    
    // friend
    SRHubConnection *connectionFriend;
    SRHubProxy *hubFriend;
}
+ (instancetype)getInstance;
- (void)connectHubOnline;
- (void)connectHubFriend;

- (void)disconnectOnline;
- (void)disconnectFriend;

- (void)updateNotification;
- (void)acceptFriendWithUsername:(NSString*)username;
@end
