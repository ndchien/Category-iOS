//
//  MessageManager.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 06/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "MessageManager.h"
#import "MessageStore.h"
#import "HubConnectionOnline.h"

@implementation MessageManager
@synthesize demoData;

- (instancetype)init{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(internetStateConnected) name:NOTI_INTERNET_CONNECTED object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(internetStateDisconnect) name:NOTI_INTERNET_DISCONNECT object:nil];
    }
    return self;
}

+ (MessageManager *)getInstance{
    static MessageManager *instance;
    if (instance == nil) {
        instance = [[MessageManager alloc] init];
        
    }
    return instance;
}

- (void)checkConnection{
    if (connection && connection.state == disconnected) {
        [connection start];
    }
}

- (void)internetStateConnected{
    [self connectHub];
}

- (void)internetStateDisconnect{
    [connection stop];
}

- (void)changeStatusOnline:(BOOL)status{
    [hub invoke:@"statusOnlineFriend" withArgs:nil];
}

- (void)stopConnection{
    [connection disconnect];
    [connection stop];
    hub = nil;
    connection.delegate = nil;
    connection = nil;
}


- (void)connectHub{
    if (connection) {
        [connection stop];
    }
    if (!self.bActive) {
        return;
    }
    TokenAccess *token = [Global getInstance].currentToken;
    if (token == nil) {
        return;
    }
    NSString *server = [Router sharedRouter].server_url;
    
    connection = [SRHubConnection connectionWithURLString:server];
    [connection addValue:token.username forHTTPHeaderField:@"MHub-Username"];
    
    hub = [connection createHubProxy:@"MobiChatHub"];
    
    [[hub state] setValue:@YES forKey:@"focus"];
    [[hub state] setValue:0 forKey:@"unread"];
    [hub on:@"ClientBroadcastWithList" perform:self selector:@selector(receiveListMessage:)];
    [hub on:@"ClientBroadcast" perform:self selector:@selector(receiveMessage:)];
    
    
    [connection setDelegate:self];
    [connection start];
}

- (void)addMessageContent:(id)id content:(id)content
{
    NSLog(@"addMessageContent: %@", content);
}



- (void)receiveMessage:(id)message
{
    if ([message isKindOfClass:[NSDictionary class]]){
        NSString *mesgID        = [message valueForKey:@"Id"];
        JSQMessage *messageObj  = [self parserMessageRecive:message];
        messageObj.mesgId       = mesgID;
        messageObj.status       = MESG_SUCCESS;
        NSString *groupId       = [message valueForKey:@"GroupId"];
        messageObj.typeMesg = (groupId.length > 0)?MESG_TYPE_GROUP:MESG_TYPE_USER;
        NSString *deviceRecive  = [message valueForKey:@"Device"];
        
        if ([messageObj.typeMesg isEqualToString:MESG_TYPE_USER]) {
            messageObj.receiveId    = [message valueForKey:@"UserName"];
        }else{
            messageObj.receiveId    = groupId;
        }
        TokenAccess *token = [Global getInstance].currentToken;
        if ([messageObj.typeMesg isEqualToString:MESG_TYPE_GROUP] && [messageObj.senderId isEqualToString:token.username]) {
            return;
        }
        
        [hub invoke:@"ReceivedMessage" withArgs:@[mesgID]];
        // check case senderID is loging
        if ([messageObj.senderId isEqualToString:token.username] && [deviceRecive isKindOfClass:[NSString class]]) {
            if (![deviceRecive isEqualToString:[[Global getInstance] getUUIDDevice]]) {
                // add message to list
                if ([_delegate conformsToProtocol:@protocol(MessageManagerDelegate)]) {
                    if ([_delegate respondsToSelector:@selector(reciveMessageMe:Saved:Device:)]) {
                        [_delegate reciveMessageMe:messageObj Saved:!self.bChating Device:deviceRecive];
                    }
                }
                if (!self.bChating) { // save is not read
                    [self saveMessage:messageObj Read:YES];
                }
            }
            return;
        }
        
        
        if ([_delegate conformsToProtocol:@protocol(MessageManagerDelegate)]) {
            if ([_delegate respondsToSelector:@selector(reciveMessageWithObject:Saved:)]) {
                
                [_delegate reciveMessageWithObject:messageObj Saved:!self.bChating];
            }
        }
        if (!self.bChating) { // save is not read
            [self saveMessage:messageObj Read:NO];
            if ([messageObj.typeMesg isEqualToString:MESG_TYPE_GROUP]) {
                BOOL notificationDisable = BoolValue(KEY_SETTING_NOTI_GROUP(token.username, messageObj.receiveId));
                if (notificationDisable) {
                    return;
                }
            }
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_MESG_UNREAD object:messageObj.senderId];
        }
    }
}

- (void)receiveListMessage:(id)listMesg{
//    NSLog(@"listMessage: %@", listMesg);
    if ([listMesg isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict in listMesg) {
            [self receiveMessage:dict];
        }
    }
    
}


- (JSQMessage *)parserMessageRecive:(NSDictionary *)dictMessage{
    NSString *content   = [Util convertStringToEmoji:[dictMessage valueForKey:@"Content"]];
    if (content == nil) {
        content = @"";
        NSLog(@"Get Content Nil: %@", dictMessage);
    }
    NSString *sendDate  = [dictMessage valueForKey:@"SendDate"];
    NSString *sendId    = [dictMessage valueForKey:@"SenderId"];
    
    return [[JSQMessage alloc] initWithSenderId:sendId senderDisplayName:sendId date:[Util getDateWithFormat:KDATE_MESSAGE String:sendDate] text:content];
}

- (void)saveMessage:(JSQMessage *)mesg Read:(BOOL)read{
    TokenAccess *token = [Global getInstance].currentToken;
    if ([mesg.typeMesg isEqualToString:MESG_TYPE_USER]) {
        if (![token.username isEqualToString:mesg.senderId]) {
            [self addUserMessageUnRead:mesg.senderId Type:mesg.typeMesg];
        }
    }else{
        if (![token.username isEqualToString:mesg.senderId]) {
            [self addUserMessageUnRead:mesg.receiveId Type:mesg.typeMesg];
        }
    }
    
    MessageStore *mesgStore = [MessageStore MR_createEntity];
    mesgStore.mesg_id = mesg.mesgId;
    mesgStore.mesg_content = mesg.text;
    mesgStore.mesg_receiveId = mesg.receiveId;
    mesgStore.mesg_senderId = mesg.senderId;
    mesgStore.mesg_type = mesg.typeMesg;
    if ([mesg.typeMesg isEqualToString:MESG_TYPE_GROUP]) {
        BOOL notificationDisable = BoolValue(KEY_SETTING_NOTI_GROUP(token.username, mesg.receiveId));
        if (notificationDisable) {
            mesgStore.mesg_read = @"1";
        }else{
            mesgStore.mesg_read = read?@"1":@"0";
        }
    }else{
        mesgStore.mesg_read = read?@"1":@"0";
    }
    
    mesgStore.mesg_status = [@(mesg.status)stringValue];
    mesgStore.mesg_createTime = [Util getStringWithFormat:KDATE_MESSAGE Date:mesg.date];
    SAVE_DATABASE;
}


#pragma mark -
#pragma mark SRConnection Delegate

- (void)SRConnectionDidOpen:(SRConnection *)connection
{
    [hub invoke:@"Join" withArgs:@[]];
    if ([_delegate respondsToSelector:@selector(connectionDidConnect)]) {
        [_delegate connectionDidConnect];
    }
}

- (void)SRConnectionWillReconnect:(id<SRConnectionInterface>)connection{
    NSLog(@"Manager reconnect");
    if ([Util connected]) {
//        [self.connection stop];
//        [self connectHub];
    }
}

- (void)SRConnectionDidReconnect:(id<SRConnectionInterface>)connection{
    NSLog(@"Manager Did reconnect");
}

- (void)SRConnection:(SRConnection *)connection didReceiveData:(id)data
{
}

- (void)SRConnectionDidClose:(SRConnection *)connection
{
    NSLog(@"Manager Did Close");
    if ([_delegate respondsToSelector:@selector(connectionDidClose)]) {
        [_delegate connectionDidClose];
    }
}

- (void)SRConnection:(SRConnection *)connection didReceiveError:(NSError *)error
{
//    [connection performSelector:@selector(start) withObject:nil afterDelay:5];
}

-(void)LoadUserMessageUnRead
{
    TokenAccess *token = [Global getInstance].currentToken;
    NSUserDefaults *currentDefaults = [NSUserDefaults standardUserDefaults];
    NSData *dataRepresentingSavedArray = [currentDefaults objectForKey:MESG_USER_UNREAD(token.username)];
    if (dataRepresentingSavedArray != nil)
    {
        NSArray *oldSavedArray = [NSKeyedUnarchiver unarchiveObjectWithData:dataRepresentingSavedArray];
        if (oldSavedArray != nil)
            self.listUserUnRead = [[NSMutableArray alloc] initWithArray:oldSavedArray];
        
        else
            self.listUserUnRead = [[NSMutableArray alloc] init];
    }
    else{
        self.listUserUnRead = [[NSMutableArray alloc] init];
    }

//    NSMutableArray *listTmp = [_listUserUnRead mutableCopy];
//    for (NSString *string in listTmp) {
//        NSArray *arrCount = [MessageStore MR_findAllWithPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"mesg_senderId == '%@' && mesg_read == '0'", string]]];
//        if (arrCount.count == 0) {
//            [_listUserUnRead removeObject:string];
//        }
//    }
//    [listTmp removeAllObjects];
}

-(void)addUserMessageUnRead:(id)obj Type:(NSString*)type
{
    if (![self.listUserUnRead containsObject:obj]) {
        if ([type isEqualToString:MESG_TYPE_GROUP]) {
            BOOL disableNotification = BoolValue(KEY_SETTING_NOTI_GROUP([Global getInstance].currentToken.username, obj));
            if (disableNotification) {
                return;
            }
        }
        [self.listUserUnRead insertObject:obj atIndex:0];
        [self SaveUserMessageUnRead];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_MESG_USER_UNREAD object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_MESG_UNREAD_NEW_GROUP object:type];
        
    }
}

- (void)removeUserMessageUnRead:(id)obj{
    if ([self.listUserUnRead containsObject:obj]) {
        [self.listUserUnRead removeObject:obj];
        [self SaveUserMessageUnRead];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_MESG_USER_UNREAD object:nil];
    }
}

-(void)SaveUserMessageUnRead
{
    TokenAccess *token = [Global getInstance].currentToken;
    NSUserDefaults *currentDefaults = [NSUserDefaults standardUserDefaults];
    [currentDefaults setObject:[NSKeyedArchiver archivedDataWithRootObject:self.listUserUnRead] forKey:MESG_USER_UNREAD(token.username)];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


@end
