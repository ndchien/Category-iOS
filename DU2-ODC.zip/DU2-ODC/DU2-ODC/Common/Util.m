//
//  Util.m
//  X-Youtube
//
//  Created by CMC iOS Dev on 22/07/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "Util.h"
#import "MBProgressHUD.h"
#import "Reachability.h"
#import "CRToast.h"
#import "CRToastManager.h"
//#import "CRToastConfig.m"
#import <EventKit/EventKit.h>
#import <EventKitUI/EventKitUI.h>

@implementation Util

static UIView *currentViewShowProgress;
static BOOL finishCheck;
static SRHubConnection *connection;

//EKEventStore *eventStore;

+ (instancetype)shareInstance{
    static Util *instance;
    if (instance == nil) {
        instance = [[Util alloc] init];
        
    }
    return instance;
}

- (NSString *)parseDuration:(NSString *)duration {
    NSLog(@"Parser Duration: %@", duration);
    if(duration == nil || duration.length == 0){
        return @"";
    }
    NSInteger hours = 0;
    NSInteger minutes = 0;
    NSInteger seconds = 0;
    
    //Get Time part from ISO 8601 formatted duration http://en.wikipedia.org/wiki/ISO_8601#Durations
    duration = [duration substringFromIndex:[duration rangeOfString:@"T"].location];
    
    while ([duration length] > 1) { //only one letter remains after parsing
        duration = [duration substringFromIndex:1];
        
        NSScanner *scanner = [[NSScanner alloc] initWithString:duration];
        
        NSString *durationPart = [[NSString alloc] init];
        [scanner scanCharactersFromSet:[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] intoString:&durationPart];
        
        NSRange rangeOfDurationPart = [duration rangeOfString:durationPart];
        
        duration = [duration substringFromIndex:rangeOfDurationPart.location + rangeOfDurationPart.length];
        
        if ([[duration substringToIndex:1] isEqualToString:@"H"]) {
            hours = [durationPart intValue];
        }
        if ([[duration substringToIndex:1] isEqualToString:@"M"]) {
            minutes = [durationPart intValue];
        }
        if ([[duration substringToIndex:1] isEqualToString:@"S"]) {
            seconds = [durationPart intValue];
        }
    }
    
    NSString *time = @"";
    if (hours > 0) {
        time = [NSString stringWithFormat:@"%d:%02d:%02d", hours, minutes, seconds];
        //        time = [NSString stringWithFormat:@"%@:%@:%@", hours, minutes, seconds];
    }else{
        time = [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];
        //        time = [NSString stringWithFormat:@"%@:%@", minutes, seconds];
    }
    
    return time;
}


- (NSString *)formatNumber:(NSString *)number{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithInt:number.intValue]];
    return formattedNumberString;
}

+ (UIImage *)imageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

+ (NSString *) getDateStringWithFormat:(NSString *)format DateString:(NSString *) datestring {
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    NSLocale *enUSPOSIXLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [formater setLocale:enUSPOSIXLocale];
    [formater setDateFormat:kSERVER_DATE_FORMAT];
    NSCalendar* calendar = [NSCalendar currentCalendar];
    unsigned int flags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute;
    NSDate *date = [formater dateFromString:datestring];
    NSDateComponents* components = [calendar components:flags fromDate:date];
    NSArray *months = @[@"Jan", @"Feb", @"Mar", @"Apr", @"May", @"Jun", @"Jul", @"Aug", @"Sep", @"Oct", @"Nov", @"Dec"];
    NSString *dateString = [NSString stringWithFormat:format, components.day, months[components.month - 1], components.year];
    return dateString;
}

+ (NSString *)getStringDateWithFormat:(NSString *)format String:(NSString *)string{
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:kSERVER_DATE_FORMAT];
    NSDate *date = [formater dateFromString:string];
    [formater setDateFormat:format];
    return [formater stringFromDate:date];
}

+ (NSDate *)getDateWithFormat:(NSString*)format String:(NSString*)string{
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setLocale:[[NSLocale alloc] initWithLocaleIdentifier:NSLocaleIdentifier]];
    [formater setDateFormat:format];
    [formater setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    return [formater dateFromString:string];
}

+ (NSString *)getDateWithFromFormat:(NSString*)format ToFormat:(NSString*)toFormat String:(NSDate*)date{
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setLocale:[[NSLocale alloc] initWithLocaleIdentifier:NSLocaleIdentifier]];
    [formater setDateFormat:format];
    [formater setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    NSString *stringDate = [formater stringFromDate:date];
    [formater setDateFormat:toFormat];
    return [formater stringFromDate:[formater dateFromString:stringDate]];
}

+ (NSString *)getStringWithFormat:(NSString*)format Date:(NSDate*)date{
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setLocale:[[NSLocale alloc] initWithLocaleIdentifier:NSLocaleIdentifier]];
    [formater setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [formater setDateFormat:format];
    return [formater stringFromDate:date];
}

+ (BOOL) isContainString:(NSString *) sourcestring CompareString:(NSString *) stringcompare {
    return [sourcestring rangeOfString:stringcompare options:NSCaseInsensitiveSearch].location != NSNotFound;
}

+ (NSString *)getPathDocumentTemp{
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    documentPath = [documentPath stringByAppendingPathComponent:@"DocumentsTemp"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:documentPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:documentPath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return documentPath;
}

+ (NSString *)pathByFileName:(NSString *)fileName{
    return [[self getPathDocumentTemp] stringByAppendingPathComponent:fileName];
}

+ (BOOL )fileExistWithName:(NSString *)fileName{
    return [[NSFileManager defaultManager] fileExistsAtPath:[self pathByFileName:fileName]];
}

//+ (void) loadBannerView:(GADBannerView *)banner videoController:(UIViewController*)vc {
//    banner.adUnitID = @"ca-app-pub-4605016795143238/6308338707";
//    banner.rootViewController = vc;
//    GADRequest *request = [GADRequest request];
//    // Requests test ads on devices you specify. Your test device ID is printed to the console when
//    // an ad request is made. GADBannerView automatically returns test ads when running on a
//    // simulator.
//    request.testDevices = @[
//                            @"2077ef9a63d2b398840261c8221a0c9a"  // Eric's iPod Touch
//                            ];
//    [banner loadRequest:request];
//}

+ (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url controller:(UIViewController *) control {
    NSMutableArray *shareItems = [NSMutableArray new];
    
    if (text) {
        [shareItems addObject:text];
    }
    if (image) {
        [shareItems addObject:image];
    }
    if (url) {
        [shareItems addObject:url];
    }
    
    UIActivityViewController * avc = [[UIActivityViewController alloc] initWithActivityItems:shareItems applicationActivities:nil];
    [control presentViewController:avc animated:YES completion:nil];
}

+ (NSURL *)getURLVideoWithName:(NSString *)name{
    
    NSArray *URLs = [[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
    NSURL *destinationURL = [[URLs objectAtIndex:0] URLByAppendingPathComponent:name];
    return destinationURL;
}

+ (BOOL)checkFileExistWithURL:(NSURL *)url{
    BOOL result;
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    if ([fileManager fileExistsAtPath:[url path]]) {
//        unsigned long long fileSize = [[[NSFileManager defaultManager] attributesOfItemAtPath:[url path] error:nil] fileSize];
        result = YES;
    }else{
        result = NO;
    }
    return result;
}

+(BOOL) IsValidEmail:(NSString *)checkString {
    NSString *pattern = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    return [self validateWithString:checkString withPattern:pattern];
}

+ (NSString *)validatePassword:(NSString *)password{
    NSString *specialCharacterString = @"!~`@#$%^&*-+();:={}[],.<>?\\/\"\'";
    
    NSCharacterSet *specialCharacterSet = [NSCharacterSet
                                           characterSetWithCharactersInString:specialCharacterString];
    NSCharacterSet *uppercaseCharacterSet = [NSCharacterSet
                                           uppercaseLetterCharacterSet];
    NSCharacterSet *lowercaseCharacterSet = [NSCharacterSet
                                             lowercaseLetterCharacterSet];
    NSCharacterSet *digitcaseCharacterSet = [NSCharacterSet
                                             decimalDigitCharacterSet];
    
    if (![password rangeOfCharacterFromSet:specialCharacterSet].length) {
        return @"Có ít nhất một ký tự đặc biệt (!@#$%^&*()_+|..)";
    }
    if ([password rangeOfCharacterFromSet:uppercaseCharacterSet].length) {
        return @"Có ít nhất một ký tự viết hoa";
    }
    if ([password rangeOfCharacterFromSet:lowercaseCharacterSet].length) {
        return @"Có ít nhất một ký tự viết thường";
    }
    if ([password rangeOfCharacterFromSet:digitcaseCharacterSet].length) {
        return @"Có ít nhất một ký tự là số";
    }
    return @"";
}

+ (BOOL)validateWithString:(NSString *)string withPattern:(NSString *)pattern {
//    NSError *error = nil;
//    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
//    
//    NSAssert(regex, @"Unable to create regular expression");
//    
//    NSRange textRange = NSMakeRange(0, string.length);
//    NSRange matchRange = [regex rangeOfFirstMatchInString:string options:NSMatchingReportProgress range:textRange];
//    
//    BOOL didValidate = NO;
//    
//    // Did we find a matching range
//    if (matchRange.location != NSNotFound)
//        didValidate = YES;
//    
//    return didValidate;
    
    NSRegularExpression* regex = [[NSRegularExpression alloc] initWithPattern:pattern options:0 error:nil];
    return [regex numberOfMatchesInString:string options:0 range:NSMakeRange(0, [string length])] > 0;
}



// image

+ (UIImage *)blurWithCoreImage:(UIImage *)sourceImage Frame:(CGRect )frame Blur:(id)blur
{
    CIImage *inputImage = [CIImage imageWithCGImage:sourceImage.CGImage];
    
    // Apply Affine-Clamp filter to stretch the image so that it does not
    // look shrunken when gaussian blur is applied
    CGAffineTransform transform = CGAffineTransformIdentity;
    CIFilter *clampFilter = [CIFilter filterWithName:@"CIAffineClamp"];
    [clampFilter setValue:inputImage forKey:@"inputImage"];
    [clampFilter setValue:[NSValue valueWithBytes:&transform objCType:@encode(CGAffineTransform)] forKey:@"inputTransform"];
    
    // Apply gaussian blur filter with radius of 30
    CIFilter *gaussianBlurFilter = [CIFilter filterWithName: @"CIGaussianBlur"];
    [gaussianBlurFilter setValue:clampFilter.outputImage forKey: @"inputImage"];
    [gaussianBlurFilter setValue:blur forKey:@"inputRadius"];
    
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef cgImage = [context createCGImage:gaussianBlurFilter.outputImage fromRect:[inputImage extent]];
    
    // Set up output context.
    UIGraphicsBeginImageContext(frame.size);
    CGContextRef outputContext = UIGraphicsGetCurrentContext();
    
    // Invert image coordinates
    CGContextScaleCTM(outputContext, 1.0, -1.0);
    CGContextTranslateCTM(outputContext, 0, -frame.size.height);
    
    // Draw base image.
    CGContextDrawImage(outputContext, frame, cgImage);
    
    // Apply white tint
    CGContextSaveGState(outputContext);
    CGContextSetFillColorWithColor(outputContext, [UIColor colorWithWhite:1 alpha:0.2].CGColor);
    CGContextFillRect(outputContext, frame);
    CGContextRestoreGState(outputContext);
    
    // Output image is ready.
    UIImage *outputImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return outputImage;
}

+ (UIImage*)imageByCroppingForSize:(CGSize)targetSize andImage:(UIImage *)sourceImage
{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
        {
            scaleFactor = widthFactor; // scale to fit height
        }
        else
        {
            scaleFactor = heightFactor; // scale to fit width
        }
        
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else
        {
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
            }
        }
    }
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    if(newImage == nil)
    {
        NSLog(@"could not scale image");
    }
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    
    return newImage;
}

+ (UIImage *) imageFromWebView:(UIWebView *)view
{
    UIImage *screenImage=[[UIImage alloc] init];
    UIScrollView *browserScrollableView=[[UIScrollView alloc] init];
    browserScrollableView=view.scrollView;
    UIGraphicsBeginImageContext(browserScrollableView.contentSize);
    CGPoint savedContentOffset = browserScrollableView.contentOffset;
    CGRect savedFrame = browserScrollableView.frame;
    
    browserScrollableView.contentOffset = CGPointZero;
    browserScrollableView.frame = CGRectMake(0, 0, browserScrollableView.contentSize.width, browserScrollableView.contentSize.height);
    
    [browserScrollableView.layer renderInContext: UIGraphicsGetCurrentContext()];
    screenImage = UIGraphicsGetImageFromCurrentImageContext();
    
    browserScrollableView.contentOffset = savedContentOffset;
    browserScrollableView.frame = savedFrame;
    UIGraphicsEndImageContext();
    
    NSLog(@"Captured image size is %f X %f",screenImage.size.width,screenImage.size.height);
    
    UIImageWriteToSavedPhotosAlbum(screenImage, nil, nil, nil);
    return screenImage;
}

+ (void)showAlertWithTitle:(NSString *)title Message:(NSString *)mesg{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:mesg delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alert show];
}

+ (UIImage *)compressForUpload:(UIImage *)original Size:(CGSize )size
{
    // Calculate new size given scale factor.
    CGSize newSize = CGSizeMake(size.width, size.height);
    
    // Scale the original image to match the new size.
    UIGraphicsBeginImageContext(newSize);
    [original drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage* compressedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return compressedImage;
}

+ (bool) isImage: (NSString *) fname {
    if(NSNotFound != [fname rangeOfString:@".jpg"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".JPG"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".jpeg"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".JPEG"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".jfif"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".JFIF"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".png"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".PNG"].location)
        return true;
    
    return false;
}

+ (bool) isPDF: (NSString *) fname {
   	if(NSNotFound != [fname rangeOfString:@".pdf"].location)
        return true;
    
    if(NSNotFound != [fname rangeOfString:@".PDF"].location)
        return true;
    
    return false;
}

// Check networking

+ (void)getStateNetworking{
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
            case AFNetworkReachabilityStatusReachableViaWWAN:
            case AFNetworkReachabilityStatusReachableViaWiFi:
                //available
                NSLog(@"available WIFI");
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_INTERNET_CONNECTED object:nil];
                break;
            case AFNetworkReachabilityStatusNotReachable:
                //not available
                NSLog(@"No Internet Connection");
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_INTERNET_DISCONNECT object:nil];
                break;
            default:
                break;
        }
    }];
    
    //start monitoring
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
}

+ (BOOL)connected {
    if (finishCheck) {
        return [AFNetworkReachabilityManager sharedManager].reachable;
    }
    Reachability *reach = [Reachability reachabilityWithHostname:@"google.com"];
    return reach.isReachable;
}

+ (Order)compareDateStart:(NSString *)start End:(NSString *)end{
    NSLog(@"Date Token Expire: %@", start);
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//    formatter.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
//    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:[[NSLocale preferredLanguages] objectAtIndex:0]];
//    [formatter setLocale:locale];
    
    [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    
    [formatter setDateFormat:KDATE_TOKEN];
    
    NSDate* startDate = [formatter dateFromString:start];
    if (!startDate) {
        [formatter setDateFormat:KDATE_TOKEN1];
        startDate = [formatter dateFromString:start];
    }
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:[[NSLocale preferredLanguages] objectAtIndex:0]];
    [formatter setLocale:locale];

    NSDate* endDate = [formatter dateFromString:end];
    if ([startDate compare:endDate] == NSOrderedDescending) {
        return OrderedDescending;
    } else if ([startDate compare:endDate] == NSOrderedAscending) {
        return OrderedAscending;
    } else {
        return OrderSame;
    }

    return OrderSame;
}

+ (Order)compareDate:(NSDate *)start End:(NSDate *)end{
    if ([start compare:end] == NSOrderedDescending) {
        return OrderedDescending;
    } else if ([start compare:end] == NSOrderedAscending) {
        return OrderedAscending;
    } else {
        return OrderSame;
    }
    
    return OrderSame;
}

+ (NSString *)convertEmojiToString:(NSString*)emoji{
//    NSData *data = [emoji dataUsingEncoding:NSNonLossyASCIIStringEncoding];
//    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return emoji;
}

+ (NSString *)convertStringToEmoji:(NSString*)string{
//    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
//    return [[NSString alloc] initWithData:data encoding:NSNonLossyASCIIStringEncoding];
    return string;
}

#pragma mark - Progress while getting data from service
+ (void) showProgressGettingDataWithView:(UIView *) view ShowStatus:(BOOL) show{
    
    if (show == YES) {
        [MBProgressHUD showHUDAddedTo:view animated:YES];
    } else {
        [MBProgressHUD hideHUDForView:currentViewShowProgress animated:YES];
    }
    
    //chiennd : lưu lại view hiện tại để có thể fix lỗi khi có cuộc gọi đến , thì indicator không tắt , sẽ được tắt trong phần appdelegate -> DidBecomeActive
    if (view) {
        currentViewShowProgress = view;
    }
    
}

+(NSString *)stringEncodeUsingEncoding:(NSString *)encoding {
    return (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                                 (CFStringRef)encoding,
                                                                                 NULL,
                                                                                 (CFStringRef)@"!*'\"();:@&=+$,/?%#[]% ",
                                                                                 CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding)));
}

+(NSMutableArray*)stringsBetweenString:(NSString *)string Start:(NSString*)start endString:(NSString*)end
{
    
    NSMutableArray* strings = [NSMutableArray arrayWithCapacity:0];
    NSRange startRange = [string rangeOfString:start];
    
    while (YES) {
        if (startRange.location != NSNotFound)
        {
            NSRange targetRange;
            targetRange.location = startRange.location + startRange.length;
            targetRange.length = [string length] - targetRange.location;
            
            NSRange endRange = [string rangeOfString:end options:0 range:targetRange];
            
            if (endRange.location != NSNotFound)
            {
                targetRange.length = endRange.location - targetRange.location;
                [strings addObject:[string substringWithRange:targetRange]];
                
                NSRange restOfString;
                restOfString.location = endRange.location + endRange.length;
                restOfString.length = [string length] - restOfString.location;
                
                startRange = [string rangeOfString:start options:0 range:restOfString];
                
            }
            else
                break;
        }
        else
            break;
    }
    return strings;
}

// calendar
+(NSArray*)daysThisWeek
{
    return  [self daysInWeek:0 fromDate:[NSDate date]];
}

+(NSArray*)daysInWeek:(int)index
{
    return  [self daysInWeek:index fromDate:[NSDate date]];
}
+(NSArray*)daysInWeek:(int)weekOffset fromDate:(NSDate*)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [calendar setFirstWeekday:2]; // set monday is first day in weeeks
    //ask for current week
    
    NSDateComponents* comps = [calendar components:NSYearForWeekOfYearCalendarUnit |NSYearCalendarUnit|NSMonthCalendarUnit|NSWeekCalendarUnit|NSWeekdayCalendarUnit fromDate:date];
    
    [comps setWeekday:2]; // 2: monday
    NSDate *weekstart = [calendar dateFromComponents:comps];
    
    
//    NSDateComponents *comps = [[NSDateComponents alloc] init];
//    comps=[calendar components:NSWeekCalendarUnit|NSYearCalendarUnit fromDate:date];
//
//    //create date on week start
//    NSDate* weekstart=[calendar dateFromComponents:comps];
    if (weekOffset != 0) {
        NSDateComponents* moveWeeks=[[NSDateComponents alloc] init];
        [moveWeeks setWeekOfMonth:weekOffset];
        weekstart=[calendar dateByAddingComponents:moveWeeks toDate:weekstart options:0];
    }
    
    //add 7 days
    NSMutableArray* week=[NSMutableArray arrayWithCapacity:7];
    [week addObject:weekstart];
    for (int i=1; i<=6; i++) {
        NSDateComponents *compsToAdd = [[NSDateComponents alloc] init];
        compsToAdd.day=i;
        NSDate *nextDate = [calendar dateByAddingComponents:compsToAdd toDate:weekstart options:0];
        [week addObject:nextDate];
        
    }
    return [NSArray arrayWithArray:week];
}

+ (NSDate *)firstDayOfMonthContainingDate:(NSDate *)date {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    comps.day = 1;
    return [[NSCalendar currentCalendar] dateFromComponents:comps];
}

+ (NSDate *)firstDayOfNextMonthContainingDate:(NSDate *)date {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    comps.day = 1;
    comps.month = comps.month + 1;
    return [[NSCalendar currentCalendar] dateFromComponents:comps];
}

+ (NSDate *)_nextDay:(NSDate *)date {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    [comps setDay:1];
    return [[NSCalendar currentCalendar] dateByAddingComponents:comps toDate:date options:0];
}

+ (NSDate*)moveCalendarToPreviousMonth:(NSDate *)date {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    [comps setDay:-1];
   return [[NSCalendar currentCalendar] dateFromComponents:comps];
}

+ (NSDate*)moveCalendarToNextMonth:(NSDate *)date {
//    NSDateComponents *comps = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
//    [comps setDay:1];
//    return [[NSCalendar currentCalendar] dateFromComponents:comps];
    NSDateComponents *dateComponents = [NSDateComponents new];
    dateComponents.month = 1;
    return [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:date options:0];
}

+ (NSInteger)_numberOfDaysFromDate:(NSDate *)startDate toDate:(NSDate *)endDate {
    NSInteger startDay = [[NSCalendar currentCalendar] ordinalityOfUnit:NSDayCalendarUnit inUnit:NSEraCalendarUnit forDate:startDate];
    NSInteger endDay = [[NSCalendar currentCalendar] ordinalityOfUnit:NSDayCalendarUnit inUnit:NSEraCalendarUnit forDate:endDate];
    return endDay - startDay;
}

+ (NSMutableArray *)getDaysInMonthByDate:(NSDate*)date{
    NSMutableArray *results = [[NSMutableArray alloc] init];
    //Create an NSDate for the first and last day of the month
    NSDateComponents *comp = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    [comp setDay:1];
    NSDate *firstOfMonth = [[NSCalendar currentCalendar] dateFromComponents:comp];
//    [comp setMonth:[comp month]+1];
//    [comp setDay:0];
//    NSDate *lastOfMonth = [[NSCalendar currentCalendar] dateFromComponents:comp];
    int nWeek = 0;
    while (results.count != 42) {
        NSArray *daysInWeek = [self daysInWeek:nWeek fromDate:firstOfMonth];
        [results addObjectsFromArray:daysInWeek];
        nWeek++;
        if (results.count > 42) {
            break;
        }
    }
    return results;
}

+ (NSDate*)lastDateMonthDate:(NSDate *)date{
    NSDateComponents *comp = [[NSCalendar currentCalendar] components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    [comp setMonth:[comp month]+1];
    [comp setDay:0];
    return [[NSCalendar currentCalendar] dateFromComponents:comp];
}

+ (NSComparisonResult)compareByMonth:(NSDate *)date toDate:(NSDate *)otherDate {
    NSDateComponents *day = [[NSCalendar currentCalendar] components:NSYearCalendarUnit|NSMonthCalendarUnit fromDate:date];
    NSDateComponents *day2 = [[NSCalendar currentCalendar] components:NSYearCalendarUnit|NSMonthCalendarUnit fromDate:otherDate];
    
    if (day.year < day2.year) {
        return NSOrderedAscending;
    } else if (day.year > day2.year) {
        return NSOrderedDescending;
    } else if (day.month < day2.month) {
        return NSOrderedAscending;
    } else if (day.month > day2.month) {
        return NSOrderedDescending;
    } else {
        return NSOrderedSame;
    }
}

+ (NSCalendar*)calendar{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [calendar setTimeZone:sourceTimeZone];
    return calendar;
}

+ (NSComparisonResult)compareByDate:(NSDate *)date toDate:(NSDate *)otherDate {
    
    NSDateComponents *day = [[self calendar] components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit fromDate:date];
    NSDateComponents *day2 = [[self calendar] components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit fromDate:otherDate];
    
    if (day.year < day2.year) {
        return NSOrderedAscending;
    } else if (day.year > day2.year) {
        return NSOrderedDescending;
    } else if (day.month < day2.month) {
        return NSOrderedAscending;
    } else if (day.month > day2.month) {
        return NSOrderedDescending;
    } else if (day.day < day2.day) {
        return NSOrderedAscending;
    } else if (day.day > day2.day) {
        return NSOrderedDescending;
    }else{
        return NSOrderedSame;
    }
}

+ (NSComparisonResult)compareSameDate:(NSDate *)date toDate:(NSDate *)toDate{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"MM/dd/yyyyy"];
    
    NSDate *dateConvert = [format dateFromString:[format stringFromDate:date]];
    NSDate *toDateConvert = [format dateFromString:[format stringFromDate:toDate]];
    return [dateConvert compare:toDateConvert];
}

+ (NSDate*)currentDateGMT{
    NSDate* sourceDate = [NSDate date];
    
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    NSTimeZone* destinationTimeZone = [NSTimeZone systemTimeZone];
    
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:sourceDate];
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate];
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    
    return [[NSDate alloc] initWithTimeInterval:interval sinceDate:sourceDate];
}

+ (NSInteger)weekdayByDate:(NSDate*)date{
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *weekdayComponents =
    [gregorian components:(NSDayCalendarUnit | NSWeekdayCalendarUnit) fromDate:date];
    return [weekdayComponents weekday];
}

+ (NSString*)stringWeekdayByDate:(NSDate*)date{
    NSString *result = @"";
    NSInteger day = [self weekdayByDate:date];
    switch (day) {
        case 2:
            result = @"THỨ 2";
            break;
        case 3:
            result = @"THỨ 3";
            break;
        case 4:
            result = @"THỨ 4";
            break;
        case 5:
            result = @"THỨ 5";
            break;
        case 6:
            result = @"THỨ 6";
            break;
        case 7:
            result = @"THỨ 7";
            break;
        case 8:
            result = @"CHỦ NHẬT";
            break;
        default:
            break;
    }
    return result;
}

+ (NSString*)hexcolorLessonID:(NSString*)lessonID{
    NSString *hexColor = @"";
    switch (lessonID.intValue) {
        case 1:
            hexColor = LESSON_COLOR_0001;
            break;
        case 2:
            hexColor = LESSON_COLOR_0002;
            break;
        case 3:
            hexColor = LESSON_COLOR_0003;
            break;
        case 4:
            hexColor = LESSON_COLOR_0004;
            break;
        default:
            hexColor = LESSON_COLOR_0001;
            break;
    }
    if ([lessonID isEqualToString:@"M001"]) {
        
    }
    return hexColor;
}

+ (NSDate *)nextDay:(NSDate *)date {
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setDay:1];
    return [[self calendar] dateByAddingComponents:comps toDate:date options:0];
}

+ (NSDate *)previousDay:(NSDate *)date {
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setDay:-1];
    return [[self calendar] dateByAddingComponents:comps toDate:date options:0];
}

+ (NSString*)getPathAvatar:(NSString *)data{
    if (![data isKindOfClass:[NSString class]]) {
        return @"";
    }
    if (data.length > 0) {
        return [NSString stringWithFormat:@"%@%@", SERVER_API, data];
    }
    return @"";
}

+ (BOOL)showToastWithStatus:(ToastStatus)status andMessage:(NSString *)message {
    NSMutableDictionary *options = [@{kCRToastNotificationTypeKey               : @(CRToastTypeNavigationBar),
                                      kCRToastNotificationPresentationTypeKey   : @(CRToastPresentationTypeCover),
                                      kCRToastUnderStatusBarKey                 : @(YES),
                                      kCRToastTextKey                           : message,
                                      kCRToastTextAlignmentKey                  : @(NSTextAlignmentCenter),
                                      kCRToastBackgroundColorKey  : TOAST_NOTIFY_BACKGROUND_COLOR,
                                      kCRToastTimeIntervalKey                   : @(1.0)} mutableCopy];
    if (status == ToastStatusSuccess) {
        options[kCRToastImageKey] = [UIImage imageNamed:@"teal_checkmark"];
        options[kCRToastImageAlignmentKey] = @(NSTextAlignmentLeft);
    } else {
        options[kCRToastImageKey] = [UIImage imageNamed:@"alert_icon"];
        options[kCRToastImageAlignmentKey] = @(NSTextAlignmentLeft);
    }
    
    [CRToastManager showNotificationWithOptions:[NSDictionary dictionaryWithDictionary:options]
                                 apperanceBlock:^(void) {
                                     NSLog(@"Appeared");
                                 }
                                completionBlock:^(void) {
                                    NSLog(@"Completed");
                                }];
    return YES;
}





#pragma mark - Add Event to Calender of Device
+(void)addEventsToCalenderOfDevice:(NSArray *)arr{
    if(arr && arr.count>0){
        
        EKEventStore *store = [EKEventStore new];
        // request permissions
        [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError * error) {
            
            for (LessonObject *obj in arr) {
                NSString * startTime =[NSString stringWithFormat:@"%@ %@",obj.lesson_day ,obj.lesson_start_time];
                NSString * endTime =[NSString stringWithFormat:@"%@ %@",obj.lesson_day ,obj.lesson_end_time];
                NSString * eventName =obj.lesson_name;
                
                if(eventName ==nil || eventName.length==0){
                    continue;
                }
                
                NSString * notes = [NSString stringWithFormat:@"Địa điểm:%@, Thời gian:%@ - %@ \n\n(Event được tạo bởi ứng dụng EMSV)", obj.lesson_code,obj.lesson_start_time, obj.lesson_end_time];
                
                NSDateFormatter *formater = [[NSDateFormatter alloc] init];
                [formater setLocale:[[NSLocale alloc] initWithLocaleIdentifier:NSLocaleIdentifier]];
                [formater setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
                [formater setLocale:[NSLocale currentLocale]];
                [formater setTimeZone:[NSTimeZone systemTimeZone]];
                
                NSDate *startTimeDate =[formater dateFromString:startTime];
                NSDate *endTimeDate = [formater dateFromString:endTime];
                
                //Kiem tra su ton tai Event hay chua ?
                NSPredicate *predicateForEventsOnHolidayDate = [store predicateForEventsWithStartDate:startTimeDate endDate:endTimeDate calendars:nil]; // nil
                NSArray *eventsOnHolidayDate = [store eventsMatchingPredicate:predicateForEventsOnHolidayDate] ;
                
                BOOL eventExists = NO;
                
                for (EKEvent *eventToCheck in eventsOnHolidayDate) {
                    if ([eventToCheck.title isEqualToString:eventName]) {
                        eventExists = YES;
                    }
                }
                
                if(eventExists){
                    continue ;
                }
                
                EKEvent *event = [EKEvent eventWithEventStore:store];
                
                if(eventName && eventName.length>0){
                    event.title = eventName;
                    event.notes=notes;
                    
                }else{
                    event.title=notes;
                }
                
                
                event.startDate = startTimeDate;
                event.endDate = endTimeDate;
                
                event.calendar = [store defaultCalendarForNewEvents];
                NSError *err = nil;
                [store saveEvent:event span:EKSpanThisEvent commit:YES error:&err];
            }
            
        }];
        
    }
}

#pragma mark - Remove HTML Tags from an NSString
+(NSString *) stringByStrippingHTML:(NSString *)stringHTML{
    NSRange r;
    NSString *s = [stringHTML copy];
    while ((r = [s rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        s = [s stringByReplacingCharactersInRange:r withString:@""];
    return s;
}

@end
