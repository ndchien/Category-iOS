//
//  Util.h
//  X-Youtube
//
//  Created by CMC iOS Dev on 22/07/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Constant.h"
#import "SRHubConnection.h"
#import "CRToastConfig.h"

typedef NS_ENUM(NSInteger, ToastStatus){
    ToastStatusError,
    ToastStatusSuccess
};

typedef void (^CRToastInteractionResponderBlock) (CRToastInteractionType interactionType);

@interface Util : NSObject{
    
}
+ (instancetype)shareInstance;

+ (SRHubConnection *)getHubRConnection;

- (NSString *)parseDuration:(NSString *)duration;
- (NSString *)formatNumber:(NSString *)number;

+ (NSString *) getDateStringWithFormat:(NSString *)format DateString:(NSString *) datestring;

+ (NSString *)getDateWithFromFormat:(NSString*)format ToFormat:(NSString*)toFormat String:(NSDate*)date;

+ (NSString *)getStringWithFormat:(NSString*)format Date:(NSDate*)date;
+ (NSDate *)getDateWithFormat:(NSString*)format String:(NSString*)string;

+ (NSString *)getStringDateWithFormat:(NSString *)format String:(NSString *)string;

+ (BOOL) isContainString:(NSString *) sourcestring CompareString:(NSString *) stringcompare ;
+ (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url controller:(UIViewController *) control;

+ (UIImage *)imageWithColor:(UIColor *)color;

+ (NSURL *)getURLVideoWithName:(NSString *)name;

+ (void)showAlertWithTitle:(NSString *)title Message:(NSString *)mesg;

+ (BOOL)checkFileExistWithURL:(NSURL *)url;

+(BOOL) IsValidEmail:(NSString *)checkString;

+ (NSString *)validatePassword:(NSString *)password;

+ (BOOL)validateWithString:(NSString *)string withPattern:(NSString *)pattern;

+ (NSString *)pathByFileName:(NSString *)fileName;

+ (BOOL )fileExistWithName:(NSString *)fileName;

+ (UIImage *)blurWithCoreImage:(UIImage *)sourceImage Frame:(CGRect )frame Blur:(id)blur;

+ (UIImage*)imageByCroppingForSize:(CGSize)targetSize andImage:(UIImage *)sourceImage;

+ (UIImage *)compressForUpload:(UIImage *)original Size:(CGSize )size;

+ (UIImage *) imageFromWebView:(UIWebView *)view;

+ (void)getStateNetworking;

+(NSString *)stringEncodeUsingEncoding:(NSString *)encoding;

+ (BOOL)connected;

+ (NSString *)convertEmojiToString:(NSString*)emoji;

+ (NSString *)convertStringToEmoji:(NSString*)string;

+ (Order)compareDateStart:(NSString *)start End:(NSString *)end;

+ (Order)compareDate:(NSDate *)start End:(NSDate *)end;

+ (void) showProgressGettingDataWithView:(UIView *) view ShowStatus:(BOOL) show;

+(NSMutableArray*)stringsBetweenString:(NSString *)string Start:(NSString*)start endString:(NSString*)end;

+ (bool) isImage: (NSString *) fname;

+ (bool) isPDF: (NSString *) fname;

// calendar
+(NSArray*)daysInWeek:(int)weekOffset fromDate:(NSDate*)date;

+(NSArray*)daysThisWeek;

+(NSArray*)daysInWeek:(int)index;

+ (NSMutableArray *)getDaysInMonthByDate:(NSDate*)date;

+ (NSComparisonResult)compareByMonth:(NSDate *)date toDate:(NSDate *)otherDate ;

+ (NSComparisonResult)compareByDate:(NSDate *)date toDate:(NSDate *)otherDate;

+ (NSDate*)moveCalendarToPreviousMonth:(NSDate *)date;

+ (NSDate*)moveCalendarToNextMonth:(NSDate *)date;
+ (NSDate*)lastDateMonthDate:(NSDate *)date;

+ (NSDate*)currentDateGMT;

+ (NSComparisonResult)compareSameDate:(NSDate *)date toDate:(NSDate *)toDate;
+ (NSInteger)weekdayByDate:(NSDate*)date;

+ (NSString*)stringWeekdayByDate:(NSDate*)date;

+ (NSDate *)nextDay:(NSDate *)date;

+ (NSDate *)previousDay:(NSDate *)date;

+ (NSString*)hexcolorLessonID:(NSString*)lessonID;

+ (NSString*)getPathAvatar:(NSString *)data;

+ (BOOL)showToastWithStatus:(ToastStatus)status andMessage:(NSString *)message;

#pragma mark - Add Event to Calender of Device
+(void)addEventsToCalenderOfDevice:(NSArray *)arr;


#pragma mark - Remove HTML Tags from an NSString
+(NSString *) stringByStrippingHTML:(NSString *)stringHTML;


@end
