//
//  OSDEmoticonsKeyboardKeyItemGroup.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardKeyItemGroup.h"
#import "OSDEmoticonsKeyboardKeyCell.h"
#import "OSDEmoticonsKeyboardKeysPageFlowLayout.h"

@implementation OSDEmoticonsKeyboardKeyItemGroup
@synthesize keyItemCellClass = _keyItemCellClass;

- (Class)keyItemCellClass {
    if (!_keyItemCellClass) {
        _keyItemCellClass = [OSDEmoticonsKeyboardKeyCell class];
    }
    return _keyItemCellClass;
}

- (UICollectionViewLayout *)keyItemsLayout {
    if (!_keyItemsLayout) {
        OSDEmoticonsKeyboardKeysPageFlowLayout *layout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(44, 44);
        layout.pageContentInsets = UIEdgeInsetsMake(5, 5, 5, 5);
        layout.itemSpacing = 0;
        layout.lineSpacing = 0;
        _keyItemsLayout = layout;
    }
    return _keyItemsLayout;
}

- (void)setKeyItemCellClass:(Class)keyItemCellClass {
    if ([keyItemCellClass isSubclassOfClass:[OSDEmoticonsKeyboardKeyCell class]]) {
        _keyItemCellClass = keyItemCellClass;
    }else{
        NSAssert(NO, @"WUEmoticonsKeyboardKeyItemGroup: Setting keyItemCellClass - keyItemCellClass must be a subclass of WUEmoticonsKeyboardKeyCell.class");
    }
}

@end