//
//  OSDEmoticonsKeyboardKeyItem.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardKeyItem.h"

@implementation OSDEmoticonsKeyboardKeyItem

@end