//
//  OSDEmoticonsKeyboardKeyCell.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboardKeyItem.h"

@interface OSDEmoticonsKeyboardKeyCell : UICollectionViewCell
@property (nonatomic,weak,readonly) UIButton *keyButton;
@property (nonatomic,strong) OSDEmoticonsKeyboardKeyItem *keyItem;
@end

