//
//  OSDEmoticonsKeyboardKeysPageFlowLayout.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OSDEmoticonsKeyboardKeysPageFlowLayout : UICollectionViewLayout
@property (nonatomic) CGSize       itemSize;
@property (nonatomic) CGFloat      lineSpacing;
@property (nonatomic) CGFloat      itemSpacing;
@property (nonatomic) UIEdgeInsets pageContentInsets;
@end