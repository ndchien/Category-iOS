//
//  OSDEmoticonsKeyboardKeyItem.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSDEmoticonsKeyboardKeyItem : NSObject
@property (nonatomic,copy)    NSString *title;
@property (nonatomic,strong)  UIImage  *image;
@property (nonatomic,copy)    NSString *textToInput;
@end
