//
//  OSDEmoticonsKeyboardKeyItemGroupView.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardKeyItemGroupView.h"
#import "OSDEmoticonsKeyboardKeyCell.h"

CGFloat const OSDEmoticonsKeyboardKeyItemGroupViewPageControlHeight = 20;

@interface OSDEmoticonsKeyboardKeyItemGroupView () <UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)              UICollectionView             *collectionView;
@property (nonatomic,weak)              UIPageControl                *pageControl;
@property (nonatomic,weak)              OSDEmoticonsKeyboardKeyCell   *lastPressedCell;
@property (nonatomic,weak)              UILongPressGestureRecognizer *longPressGestureRecognizer;
@property (nonatomic,weak,readwrite)    UIImageView        *backgroundImageView;
@end

@implementation OSDEmoticonsKeyboardKeyItemGroupView
@synthesize collectionView;

- (void)setKeyItemGroup:(OSDEmoticonsKeyboardKeyItemGroup *)keyItemGroup {
    _keyItemGroup = keyItemGroup;
    self.collectionView.collectionViewLayout = self.keyItemGroup.keyItemsLayout;
    [self.collectionView registerClass:self.keyItemGroup.keyItemCellClass forCellWithReuseIdentifier:NSStringFromClass(self.keyItemGroup.keyItemCellClass)];
    [self.collectionView reloadData];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIImageView *backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        backgroundImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self addSubview:backgroundImageView];
        self.backgroundImageView = backgroundImageView;
        
        UIPageControl *pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.bounds), OSDEmoticonsKeyboardKeyItemGroupViewPageControlHeight)];
        pageControl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
        pageControl.userInteractionEnabled = NO;
        [self addSubview:pageControl];
        self.pageControl = pageControl;
        
        UICollectionViewLayout *layout = [[UICollectionViewLayout alloc] init];
        collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, OSDEmoticonsKeyboardKeyItemGroupViewPageControlHeight, CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds) - OSDEmoticonsKeyboardKeyItemGroupViewPageControlHeight) collectionViewLayout:layout];
        collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        collectionView.delegate = self;
        collectionView.dataSource = self;
        collectionView.backgroundColor = [UIColor clearColor];
        collectionView.pagingEnabled = YES;
        collectionView.showsHorizontalScrollIndicator = NO;
        collectionView.showsVerticalScrollIndicator = NO;
        [self addSubview:collectionView];
//        self.collectionView = collectionView;
        
        
        UILongPressGestureRecognizer *longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(collectionViewLongPress:)];
        longPressGestureRecognizer.minimumPressDuration = 0.08;
//        [self.collectionView addGestureRecognizer:longPressGestureRecognizer];
        self.longPressGestureRecognizer = longPressGestureRecognizer;
    }
    return self;
}

- (void)refreshItems{
    [self.collectionView reloadData];
}

#pragma mark - Long Press

- (void)collectionViewLongPress:(UILongPressGestureRecognizer *)gestureRecognizer {
    CGPoint touchedLocation = [gestureRecognizer locationInView:self.collectionView];
    NSIndexPath *__block touchedIndexPath = [NSIndexPath indexPathForItem:NSNotFound inSection:NSNotFound];
    [self.collectionView.indexPathsForVisibleItems enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSIndexPath *indexPath = obj;
        if (CGRectContainsPoint([[self.collectionView layoutAttributesForItemAtIndexPath:indexPath] frame], touchedLocation)) {
            touchedIndexPath = indexPath;
            *stop = YES;
        }
    }];
    
    if (touchedIndexPath.item == NSNotFound || gestureRecognizer.state == UIGestureRecognizerStateEnded) {
        if (self.pressedKeyItemCellChangedBlock) {
            self.pressedKeyItemCellChangedBlock(self.lastPressedCell,nil);
        }
        [self.lastPressedCell setSelected:NO];
        self.lastPressedCell = nil;
        
        if (touchedIndexPath.item != NSNotFound) {
            OSDEmoticonsKeyboardKeyItem *tappedKeyItem = self.keyItemGroup.keyItems[touchedIndexPath.item];
            if (self.keyItemTappedBlock) {
                self.keyItemTappedBlock(tappedKeyItem);
            }
        }
    }else{
        [self.lastPressedCell setSelected:NO];
        OSDEmoticonsKeyboardKeyCell *pressedCell = (OSDEmoticonsKeyboardKeyCell *)[self.collectionView cellForItemAtIndexPath:touchedIndexPath];
        [pressedCell setSelected:YES];
        
        if (self.pressedKeyItemCellChangedBlock) {
            self.pressedKeyItemCellChangedBlock(self.lastPressedCell,pressedCell);
        }
        self.lastPressedCell = pressedCell;
    }
}


#pragma mark - CollectionView Delegate & DataSource

- (void)refreshPageControl {
    self.pageControl.numberOfPages = ceil(self.collectionView.contentSize.width / CGRectGetWidth(self.collectionView.bounds));
    self.pageControl.currentPage = floor(self.collectionView.contentOffset.x / CGRectGetWidth(self.collectionView.bounds));
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self refreshPageControl];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self refreshPageControl];
        NSLog(@"Title: %@    TAG: %d", self.keyItemGroup.title, self.tag);
    });
    
    return self.keyItemGroup.keyItems.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    OSDEmoticonsKeyboardKeyCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass(self.keyItemGroup.keyItemCellClass) forIndexPath:indexPath];
    if (indexPath.row < self.keyItemGroup.keyItems.count) {
        cell.keyItem = self.keyItemGroup.keyItems[indexPath.row];
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [self.collectionView deselectItemAtIndexPath:indexPath animated:YES];
    OSDEmoticonsKeyboardKeyItem *tappedKeyItem = self.keyItemGroup.keyItems[indexPath.item];
    if (self.keyItemTappedBlock) {
        self.keyItemTappedBlock(tappedKeyItem);
    }
}

@end
