//
//  OSDEmoticonsKeyboardToolsView.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardToolsView.h"

@interface OSDEmoticonsKeyboardToolsView ()
@property (nonatomic,weak,readwrite) UIButton           *keyboardSwitchButton;
@property (nonatomic,weak,readwrite) UIButton           *backspaceButton;
@property (nonatomic,weak,readwrite) UIButton           *spaceButton;
@property (nonatomic,weak)           UISegmentedControl *segmentedControl;
@end

@implementation OSDEmoticonsKeyboardToolsView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        UIButton *keyboardSwitchButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        keyboardSwitchButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
//        [keyboardSwitchButton addTarget:self action:@selector(keyboardSwitchButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
//        [self addSubview:keyboardSwitchButton];
//        self.keyboardSwitchButton = keyboardSwitchButton;
        
        UIButton *backspaceButton = [UIButton buttonWithType:UIButtonTypeCustom];
        backspaceButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight;
        [backspaceButton addTarget:self action:@selector(backspaceButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
//        backspaceButton.backgroundColor = [UIColor redColor];
        [self addSubview:backspaceButton];
        self.backspaceButton = backspaceButton;
        
        UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithFrame:CGRectZero];
        segmentedControl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [segmentedControl addTarget:self action:@selector(segmentedControlValueChanged:) forControlEvents:UIControlEventValueChanged];
        
        
        [self addSubview:segmentedControl];
        self.segmentedControl = segmentedControl;
        
        self.segmentedControl.tintColor = [UIColor clearColor];
        [self.segmentedControl setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateNormal];
        
//        UIButton *spaceButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        spaceButton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//        [spaceButton addTarget:self action:@selector(spaceButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
//        [self addSubview:spaceButton];
//        self.spaceButton = spaceButton;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
//    CGSize keyboardSwitchButtonSize = [self.keyboardSwitchButton sizeThatFits:self.bounds.size];
//    CGSize backspaceButtonSize = [self.backspaceButton sizeThatFits:self.bounds.size];
    
//    self.keyboardSwitchButton.frame = (CGRect){CGPointZero,keyboardSwitchButtonSize};
    
    self.backspaceButton.frame = CGRectMake(CGRectGetWidth(self.frame)-CGRectGetHeight(self.frame), 0, CGRectGetHeight(self.frame), CGRectGetHeight(self.frame));
    
    self.segmentedControl.frame = CGRectMake(0, 0, CGRectGetWidth(self.bounds) - CGRectGetWidth(self.backspaceButton.frame), CGRectGetHeight(self.bounds));
}

- (void)setKeyItemGroups:(NSArray *)keyItemGroups {
    _keyItemGroups = keyItemGroups;
    [self.segmentedControl removeAllSegments];

    [self.keyItemGroups enumerateObjectsUsingBlock:^(OSDEmoticonsKeyboardKeyItemGroup *obj, NSUInteger idx, BOOL *stop) {
        if (obj.image) {
            [self.segmentedControl insertSegmentWithImage:obj.image atIndex:idx animated:NO];
        }else{
            [self.segmentedControl insertSegmentWithTitle:obj.title atIndex:idx animated:NO];
        }
    }];
    if (self.segmentedControl.numberOfSegments) {
        self.segmentedControl.selectedSegmentIndex = 1;
        [self segmentedControlValueChanged:self.segmentedControl];
    }
    
    if (keyItemGroups.count > 1) {
        self.segmentedControl.hidden = NO;
        self.spaceButton.hidden = YES;
    } else {
        self.segmentedControl.hidden = YES;
        self.spaceButton.hidden = NO;
    }
}

- (void)segmentedControlValueChanged:(UISegmentedControl *)sender {

    [self.keyItemGroups enumerateObjectsUsingBlock:^(OSDEmoticonsKeyboardKeyItemGroup *obj, NSUInteger idx, BOOL *stop) {
        if (obj.image) {
            if (obj.selectedImage && (NSInteger)idx == self.segmentedControl.selectedSegmentIndex) {
                [self.segmentedControl setImage:obj.selectedImage forSegmentAtIndex:idx];
            } else {
                [self.segmentedControl setImage:obj.image forSegmentAtIndex:idx];
            }
        } else {
            [self.segmentedControl setTitle:obj.title forSegmentAtIndex:idx];
        }
    }];
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor lightGrayColor], NSForegroundColorAttributeName,
                                nil];
    [self.segmentedControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    NSDictionary *highlightedAttributes = [NSDictionary dictionaryWithObject:[UIColor whiteColor] forKey:NSForegroundColorAttributeName];
    [self.segmentedControl setTitleTextAttributes:highlightedAttributes forState:UIControlStateSelected];
    if (self.keyItemGroupSelectedBlock) {
        OSDEmoticonsKeyboardKeyItemGroup *selectedKeyItemGroup = [self.keyItemGroups objectAtIndex:self.segmentedControl.selectedSegmentIndex];
        self.keyItemGroupSelectedBlock(selectedKeyItemGroup);
    }
}

- (void)keyboardSwitchButtonTapped:(UIButton *)sender {
    if (self.keyboardSwitchButtonTappedBlock) {
        self.keyboardSwitchButtonTappedBlock();
    }
}

- (void)backspaceButtonTapped:(UIButton *)sender {
    if (self.backspaceButtonTappedBlock) {
        self.backspaceButtonTappedBlock();
    }
}

- (void)spaceButtonTapped:(UIButton *)sender {
    if (self.spaceButtonTappedBlock) {
        self.spaceButtonTappedBlock();
    }
}


@end