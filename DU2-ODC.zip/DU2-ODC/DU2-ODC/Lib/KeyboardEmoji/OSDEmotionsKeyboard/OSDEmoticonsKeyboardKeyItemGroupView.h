//
//  OSDEmoticonsKeyboardKeyItemGroupView.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboardKeyItemGroup.h"
#import "OSDEmoticonsKeyboardKeyItem.h"
#import "OSDEmoticonsKeyboardKeyCell.h"

@interface OSDEmoticonsKeyboardKeyItemGroupView : UIView
@property (nonatomic,strong)        OSDEmoticonsKeyboardKeyItemGroup *keyItemGroup;
@property (nonatomic,copy)          void                            (^keyItemTappedBlock)(OSDEmoticonsKeyboardKeyItem *keyItem);
@property (nonatomic,copy)          void                            (^pressedKeyItemCellChangedBlock)(OSDEmoticonsKeyboardKeyCell *fromKeyCell, OSDEmoticonsKeyboardKeyCell *toKeyCell);
@property (nonatomic,weak,readonly) UIImageView                     *backgroundImageView;
- (void)refreshItems;
@end