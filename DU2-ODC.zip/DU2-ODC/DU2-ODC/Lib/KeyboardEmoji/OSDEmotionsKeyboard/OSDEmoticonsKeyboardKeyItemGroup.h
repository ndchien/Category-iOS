//
//  OSDEmoticonsKeyboardKeyItemGroup.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSDEmoticonsKeyboardKeyItemGroup : NSObject

@property (nonatomic,copy)              NSString                 *title;
@property (nonatomic,strong)            UIImage                  *image;
@property (nonatomic,strong)            UIImage                  *selectedImage;

@property (nonatomic,strong)            NSArray                  *keyItems;

/* CollectionViewLayout for this keyItemGroup, this property has a default value. Using WUEmoticonsKeyboardKeysPageFlowLayout is recommanded. */
@property (nonatomic,strong)            UICollectionViewLayout   *keyItemsLayout;

/* CollectionViewCell class for this keyItemGroup. default is WUEmoticonsKeyboardKeyCell.class */
@property (nonatomic,unsafe_unretained) Class                     keyItemCellClass;

@end