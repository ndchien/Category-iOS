//
//  OSDEmoticonsKeyboard.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

extern NSString * const OSDEmoticonsKeyboardDidSwitchToDefaultKeyboardNotification;

//extern CGSize const OSDEmoticonsKeyboardDefaultSize;

typedef NS_ENUM(NSUInteger, OSDEmoticonsKeyboardButton) {
    OSDEmoticonsKeyboardButtonKeyboardSwitch,
    OSDEmoticonsKeyboardButtonBackspace,
    OSDEmoticonsKeyboardButtonSpace
};

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboardKeyItemGroup.h"
#import "OSDEmoticonsKeyboardKeyItem.h"
#import "OSDEmoticonsKeyboardKeysPageFlowLayout.h"
#import "OSDEmoticonsKeyboardKeyCell.h"

@interface OSDEmoticonsKeyboard : UIView <UIAppearance,UIAppearanceContainer>

@property (nonatomic)      BOOL    enableStandardSystemKeyboardClickSound;

/*
 an array of OSDEmoticonsKeyboardKeyItemGroup.
 */
@property (nonatomic,copy) NSArray *keyItemGroups;

@property (nonatomic,copy) void(^keyItemGroupPressedKeyCellChangedBlock)(OSDEmoticonsKeyboardKeyItemGroup *keyItemGroup, OSDEmoticonsKeyboardKeyCell *fromKeyCell, OSDEmoticonsKeyboardKeyCell *toKeyCell);

@property (nonatomic,copy) void (^keyItemTappedBlock)(OSDEmoticonsKeyboardKeyItem *keyItem);
/*
 Note:
 Use the `UIResponder (OSDEmoticonsKeyboard)` -switchToEmoticonsKeyboard: method to make a textInput switch to a OSDEmoticonsKeyboard.
 The textInput object will retain the OSDEmoticonsKeyboard which attached to it.
 
 You may get the OSDEmoticonsKeyboard object though the textInput's inputView or emoticonsKeyboard property.
 */

@property (nonatomic,weak,readonly) UIResponder<UITextInput> *textInput;

+ (instancetype)keyboard;

#pragma mark - Apperance

- (void)setBackgroundImage:(UIImage *)image UI_APPEARANCE_SELECTOR;
- (void)setBackgroundImage:(UIImage *)image forKeyItemGroup:(OSDEmoticonsKeyboardKeyItemGroup *)keyItemGroup UI_APPEARANCE_SELECTOR;
- (void)setBackgroundColor:(UIColor *)backgroundColor forKeyItemGroup:(OSDEmoticonsKeyboardKeyItemGroup *)keyItemGroup UI_APPEARANCE_SELECTOR;

- (void)setImage:(UIImage *)image forButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state UI_APPEARANCE_SELECTOR;
- (UIImage *)imageForButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state;

- (void)setBackgroundImage:(UIImage *)image forButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state UI_APPEARANCE_SELECTOR;
- (UIImage *)backgroundImageForButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state;

- (void)setAttributedTitle:(NSAttributedString *)title forButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state UI_APPEARANCE_SELECTOR;
- (NSAttributedString *)attributedTitleForButton:(OSDEmoticonsKeyboardButton)button state:(UIControlState)state;

@property (nonatomic) CGFloat toolsViewHeight UI_APPEARANCE_SELECTOR; //Default 45.0f

@end

@interface UIResponder (OSDEmoticonsKeyboard)
@property (readonly, strong) OSDEmoticonsKeyboard *emoticonsKeyboard;
- (void)switchToDefaultKeyboard;
- (void)switchToEmoticonsKeyboard:(OSDEmoticonsKeyboard *)keyboard;
@end