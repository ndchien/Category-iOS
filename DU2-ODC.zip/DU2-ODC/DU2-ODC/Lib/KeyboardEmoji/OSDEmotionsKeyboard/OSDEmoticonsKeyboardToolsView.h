//
//  OSDEmoticonsKeyboardToolsView.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboardKeyItemGroup.h"

@interface OSDEmoticonsKeyboardToolsView : UIView

@property (nonatomic,strong) NSArray *keyItemGroups;

@property (nonatomic,copy)   void    (^keyboardSwitchButtonTappedBlock)(void);
@property (nonatomic,copy)   void    (^backspaceButtonTappedBlock)(void);
@property (nonatomic,copy)   void    (^spaceButtonTappedBlock)(void);
@property (nonatomic,copy)   void    (^keyItemGroupSelectedBlock)(OSDEmoticonsKeyboardKeyItemGroup *keyItemGroup);

@property (nonatomic,weak,readonly) UIButton *keyboardSwitchButton;
@property (nonatomic,weak,readonly) UIButton *backspaceButton;
@property (nonatomic,weak,readonly) UIButton *spaceButton;

@end