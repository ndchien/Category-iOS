//
//  OSDEmoticonsKeyboardKeyCell.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardKeyCell.h"

@interface OSDEmoticonsKeyboardKeyCell ()
@property (nonatomic,weak,readwrite) UIButton *keyButton;
@end

@implementation OSDEmoticonsKeyboardKeyCell

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.userInteractionEnabled = NO;
        button.frame = self.contentView.bounds;
        [self.contentView addSubview:button];
        self.keyButton = button;
//        self.backgroundColor = [UIColor greenColor];
    }
    return self;
}

- (void)setKeyItem:(OSDEmoticonsKeyboardKeyItem *)keyItem {
    _keyItem = keyItem;
    if (self.keyItem.image) {
        [self.keyButton setTitle:nil forState:UIControlStateNormal];
        [self.keyButton setImage:self.keyItem.image forState:UIControlStateNormal];
    }else{
        [self.keyButton setImage:nil forState:UIControlStateNormal];
        [self.keyButton setTitle:self.keyItem.title forState:UIControlStateNormal];
    }
}

- (void)setSelected:(BOOL)selected {
    [super setSelected:selected];
    [self.subviews enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if ([obj respondsToSelector:@selector(setSelected:)]) {
            [obj setSelected:selected];
        }
    }];
}

@end