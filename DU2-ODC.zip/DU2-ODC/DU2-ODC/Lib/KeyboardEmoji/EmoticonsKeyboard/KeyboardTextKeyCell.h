//
//  KeyboardTextKeyCell.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "OSDEmoticonsKeyboardKeyCell.h"

@interface KeyboardTextKeyCell : OSDEmoticonsKeyboardKeyCell

@end
