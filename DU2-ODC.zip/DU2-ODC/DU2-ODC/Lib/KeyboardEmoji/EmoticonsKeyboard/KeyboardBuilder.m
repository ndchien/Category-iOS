//
//  KeyboardBuilder.m
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import "KeyboardBuilder.h"
#import "KeyboardTextKeyCell.h"
#import "KeyboardPressedCellPopupView.h"

@implementation KeyboardBuilder

+ (OSDEmoticonsKeyboard *)sharedEmoticonsKeyboard {
    static OSDEmoticonsKeyboard *_sharedEmoticonsKeyboard;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        OSDEmoticonsKeyboardKeysPageFlowLayout *textIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        textIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        textIconsLayout.itemSpacing = 0;
        textIconsLayout.lineSpacing = 0;
        textIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        
        //create a keyboard of default size
        OSDEmoticonsKeyboard *keyboard = [OSDEmoticonsKeyboard keyboard];
        
//        //Icon keys
//        OSDEmoticonsKeyboardKeyItem *loveKey = [[OSDEmoticonsKeyboardKeyItem alloc] init];
//        loveKey.image = [UIImage imageNamed:@"love"];
//        loveKey.textToInput = @"[love]";
//        
//        OSDEmoticonsKeyboardKeyItem *applaudKey = [[OSDEmoticonsKeyboardKeyItem alloc] init];
//        applaudKey.image = [UIImage imageNamed:@"applaud"];
//        applaudKey.textToInput = @"[applaud]";
//        
//        OSDEmoticonsKeyboardKeyItem *weicoKey = [[OSDEmoticonsKeyboardKeyItem alloc] init];
//        weicoKey.image = [UIImage imageNamed:@"weico"];
//        weicoKey.textToInput = @"[weico]";
//        
//        //Icon key group
//        OSDEmoticonsKeyboardKeyItemGroup *imageIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
//        imageIconsGroup.keyItems = @[loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey,loveKey,applaudKey,weicoKey];
//        UIImage *keyboardEmotionImage = [UIImage imageNamed:@"keyboard_emotion"];
//        UIImage *keyboardEmotionSelectedImage = [UIImage imageNamed:@"keyboard_emotion_selected"];
//        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
//            keyboardEmotionImage = [keyboardEmotionImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//            keyboardEmotionSelectedImage = [keyboardEmotionSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//        }
//        imageIconsGroup.image = keyboardEmotionImage;
//        imageIconsGroup.keyItemsLayout = textIconsLayout;
//        imageIconsGroup.selectedImage = keyboardEmotionSelectedImage;
        
        NSDictionary *peopletextKeys = [[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]]valueForKey:@"People"];
        NSDictionary *naturetextKeys = [[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]]valueForKey:@"Nature"];
        NSDictionary *objecttextKeys = [[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]]valueForKey:@"Objects"];
        NSDictionary *placetextKeys = [[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]]valueForKey:@"Places"];
        NSDictionary *symboltextKeys = [[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]]valueForKey:@"Symbols"];
        //Text keys
        //        NSArray *textKeys = [[NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EmotionTextKeys" ofType:@"plist"]] valueForKey:@"People"];
        // people
        NSMutableArray *peopleKeyItems = [NSMutableArray array];
        for (NSString *text in peopletextKeys) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [peopleKeyItems addObject:keyItem];
        }
        
        // nature
        NSMutableArray *natureKeyItems = [NSMutableArray array];
        for (NSString *text in naturetextKeys) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [natureKeyItems addObject:keyItem];
        }
        
        // objects
        NSMutableArray *objectKeyItems = [NSMutableArray array];
        for (NSString *text in objecttextKeys) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [objectKeyItems addObject:keyItem];
        }
        
        // place
        NSMutableArray *placeKeyItems = [NSMutableArray array];
        for (NSString *text in placetextKeys) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [placeKeyItems addObject:keyItem];
        }
        
        // symbol
        NSMutableArray *symbolKeyItems = [NSMutableArray array];
        for (NSString *text in symboltextKeys) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [symbolKeyItems addObject:keyItem];
        }
        
        //people
        OSDEmoticonsKeyboardKeysPageFlowLayout *peopleIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        peopleIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        peopleIconsLayout.itemSpacing = 0;
        peopleIconsLayout.lineSpacing = 0;
        peopleIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        
        OSDEmoticonsKeyboardKeyItemGroup *peopleIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        peopleIconsGroup.title = @"People";
        peopleIconsGroup.keyItems = peopleKeyItems;
        peopleIconsGroup.keyItemsLayout = peopleIconsLayout;
        peopleIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardTextImage = [UIImage imageNamed:@"face_n"];
        UIImage *keyboardTextSelectedImage = [UIImage imageNamed:@"face_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardTextImage = [keyboardTextImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardTextSelectedImage = [keyboardTextSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        peopleIconsGroup.image = keyboardTextImage;
        peopleIconsGroup.selectedImage = keyboardTextSelectedImage;
        
        // nature
        OSDEmoticonsKeyboardKeysPageFlowLayout *natureIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        natureIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        natureIconsLayout.itemSpacing = 0;
        natureIconsLayout.lineSpacing = 0;
        natureIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        OSDEmoticonsKeyboardKeyItemGroup *natureIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        natureIconsGroup.title = @"Nature";
        natureIconsGroup.keyItems = natureKeyItems;
        natureIconsGroup.keyItemsLayout = natureIconsLayout;
        natureIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardNatureImage = [UIImage imageNamed:@"flower_n"];
        UIImage *keyboardNatureSelectedImage = [UIImage imageNamed:@"flower_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardNatureImage = [keyboardNatureImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardNatureSelectedImage = [keyboardNatureSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        natureIconsGroup.image = keyboardNatureImage;
        natureIconsGroup.selectedImage = keyboardNatureSelectedImage;
        
        // object
        OSDEmoticonsKeyboardKeysPageFlowLayout *objectIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        objectIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        objectIconsLayout.itemSpacing = 0;
        objectIconsLayout.lineSpacing = 0;
        objectIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        OSDEmoticonsKeyboardKeyItemGroup *objectIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        objectIconsGroup.title = @"Objects";
        objectIconsGroup.keyItems = objectKeyItems;
        objectIconsGroup.keyItemsLayout = objectIconsLayout;
        objectIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardObjectImage = [UIImage imageNamed:@"bell_n"];
        UIImage *keyboardObjectSelectedImage = [UIImage imageNamed:@"bell_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardObjectImage = [keyboardObjectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardObjectSelectedImage = [keyboardObjectSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        objectIconsGroup.image = keyboardObjectImage;
        objectIconsGroup.selectedImage = keyboardObjectSelectedImage;
        
        // place
        OSDEmoticonsKeyboardKeysPageFlowLayout *placeIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        placeIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        placeIconsLayout.itemSpacing = 0;
        placeIconsLayout.lineSpacing = 0;
        placeIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        OSDEmoticonsKeyboardKeyItemGroup *placeIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        placeIconsGroup.title = @"Place";
        placeIconsGroup.keyItems = placeKeyItems;
        placeIconsGroup.keyItemsLayout = placeIconsLayout;
        placeIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardPlaceImage = [UIImage imageNamed:@"characters_n"];
        UIImage *keyboardPlaceSelectedImage = [UIImage imageNamed:@"characters_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardPlaceImage = [keyboardPlaceImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardPlaceSelectedImage = [keyboardPlaceSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        placeIconsGroup.image = keyboardPlaceImage;
        placeIconsGroup.selectedImage = keyboardPlaceSelectedImage;
        
        // symbol
        OSDEmoticonsKeyboardKeysPageFlowLayout *symbolIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        symbolIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        symbolIconsLayout.itemSpacing = 0;
        symbolIconsLayout.lineSpacing = 0;
        symbolIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        OSDEmoticonsKeyboardKeyItemGroup *symbolIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        symbolIconsGroup.title = @"Symbols";
        symbolIconsGroup.keyItems = symbolKeyItems;
        symbolIconsGroup.keyItemsLayout = symbolIconsLayout;
        symbolIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardSymbolImage = [UIImage imageNamed:@"car_n"];
        UIImage *keyboardSymbolSelectedImage = [UIImage imageNamed:@"car_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardSymbolImage = [keyboardSymbolImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardSymbolSelectedImage = [keyboardSymbolSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        symbolIconsGroup.image = keyboardSymbolImage;
        symbolIconsGroup.selectedImage = keyboardSymbolSelectedImage;
        
        // recent
        NSMutableArray *recentKeyItems = [NSMutableArray array];
        for (NSString *text in [KeyboardBuilder recentEmojis]) {
            OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
            keyItem.title = text;
            keyItem.textToInput = text;
            [recentKeyItems addObject:keyItem];
        }
        
        OSDEmoticonsKeyboardKeysPageFlowLayout *recentIconsLayout = [[OSDEmoticonsKeyboardKeysPageFlowLayout alloc] init];
        recentIconsLayout.itemSize = CGSizeMake(45, 132/3.0);
        recentIconsLayout.itemSpacing = 0;
        recentIconsLayout.lineSpacing = 0;
        recentIconsLayout.pageContentInsets = UIEdgeInsetsMake(1,2,1,2);
        OSDEmoticonsKeyboardKeyItemGroup *recentIconsGroup = [[OSDEmoticonsKeyboardKeyItemGroup alloc] init];
        recentIconsGroup.title = @"Recent";
        recentIconsGroup.keyItems = recentKeyItems;
        recentIconsGroup.keyItemsLayout = recentIconsLayout;
        recentIconsGroup.keyItemCellClass = KeyboardTextKeyCell.class;
        
        UIImage *keyboardRecentImage = [UIImage imageNamed:@"recent_n"];
        UIImage *keyboardRecentSelectedImage = [UIImage imageNamed:@"recent_s"];
        if ([UIImage instancesRespondToSelector:@selector(imageWithRenderingMode:)]) {
            keyboardRecentImage = [keyboardRecentImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            keyboardRecentSelectedImage = [keyboardRecentSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        recentIconsGroup.image = keyboardRecentImage;
        recentIconsGroup.selectedImage = keyboardRecentSelectedImage;
        
        //Set keyItemGroups
        keyboard.keyItemGroups = @[recentIconsGroup,peopleIconsGroup,natureIconsGroup, objectIconsGroup, symbolIconsGroup, placeIconsGroup];
        
        __weak __typeof(&*self)weakSelf = self;
        [keyboard setKeyItemTappedBlock:^(OSDEmoticonsKeyboardKeyItem *keyItem) {
            [weakSelf keyItemTap:keyItem];
            NSMutableArray *recentKeyItems = [NSMutableArray array];
            for (NSString *text in [KeyboardBuilder recentEmojis]) {
                OSDEmoticonsKeyboardKeyItem *keyItem = [[OSDEmoticonsKeyboardKeyItem alloc] init];
                keyItem.title = text;
                keyItem.textToInput = text;
                [recentKeyItems addObject:keyItem];
            }
            recentIconsGroup.keyItems = recentKeyItems;
        }];
        
        //Setup cell popup view
        [keyboard setKeyItemGroupPressedKeyCellChangedBlock:^(OSDEmoticonsKeyboardKeyItemGroup *keyItemGroup, OSDEmoticonsKeyboardKeyCell *fromCell, OSDEmoticonsKeyboardKeyCell *toCell) {
            
            [KeyboardBuilder sharedEmotionsKeyboardKeyItemGroup:keyItemGroup pressedKeyCellChangedFromCell:fromCell toCell:toCell];
        }];
        
        //Keyboard appearance
        
        //Custom text icons scroll background
        if (textIconsLayout.collectionView) {
            UIView *textGridBackgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [textIconsLayout collectionViewContentSize].width, [textIconsLayout collectionViewContentSize].height)];
            textGridBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//            textGridBackgroundView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"keyboard_grid_bg"]];
            [textIconsLayout.collectionView addSubview:textGridBackgroundView];
        }
        
        //Custom utility keys
        [keyboard setImage:[UIImage imageNamed:@"keyboard_switch"] forButton:OSDEmoticonsKeyboardButtonKeyboardSwitch state:UIControlStateNormal];
        [keyboard setImage:[UIImage imageNamed:@"keyboard_switch_pressed"] forButton:OSDEmoticonsKeyboardButtonKeyboardSwitch state:UIControlStateHighlighted];
        
        [keyboard setImage:[UIImage imageNamed:@"btn_emoji_backspace"] forButton:OSDEmoticonsKeyboardButtonBackspace state:UIControlStateNormal];
//        [keyboard setImage:[UIImage imageNamed:@"btn_emoji_backspace"] forButton:OSDEmoticonsKeyboardButtonBackspace state:UIControlStateHighlighted];
        
        [keyboard setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"Space", @"") attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:15], NSForegroundColorAttributeName: [UIColor darkGrayColor]}] forButton:OSDEmoticonsKeyboardButtonSpace state:UIControlStateNormal];
        [keyboard setBackgroundImage:[[UIImage imageNamed:@"keyboard_segment_normal"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 10, 0, 10)] forButton:OSDEmoticonsKeyboardButtonSpace state:UIControlStateNormal];
        
        //Keyboard background
        [keyboard setBackgroundImage:[[UIImage imageNamed:@"keyboard_bg"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 1, 0, 1)]];
        
        //SegmentedControl
//        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setBackgroundImage:[[UIImage imageNamed:@"bg_emoji_normal"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
//        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setBackgroundImage:[[UIImage imageNamed:@"bg_emoji_selected"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
//        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setDividerImage:[UIImage imageNamed:@"bg_emoji_normal"] forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
//        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setDividerImage:[UIImage imageNamed:@"bg_emoji_selected"] forLeftSegmentState:UIControlStateSelected rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        
        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setDividerImage:[UIImage imageNamed:@"style_segmented_control_delimiter.png"]
                           forLeftSegmentState:UIControlStateSelected
                             rightSegmentState:UIControlStateNormal
                                    barMetrics:UIBarMetricsDefault];
        
        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setDividerImage:[UIImage imageNamed:@"style_segmented_control_delimiter.png"]
                           forLeftSegmentState:UIControlStateNormal
                             rightSegmentState:UIControlStateNormal
                                    barMetrics:UIBarMetricsDefault];
        
        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setBackgroundImage:[UIImage imageNamed:@"bg_emoji_normal"]
                                         forState:UIControlStateNormal
                                       barMetrics:UIBarMetricsDefault];
        
        [[UISegmentedControl appearanceWhenContainedIn:[OSDEmoticonsKeyboard class], nil] setBackgroundImage:[UIImage imageNamed:@"bg_emoji_selected"]
                                         forState:UIControlStateSelected
                                       barMetrics:UIBarMetricsDefault];
        _sharedEmoticonsKeyboard = keyboard;
    });
    return _sharedEmoticonsKeyboard;
}

+ (void)keyItemTap:(OSDEmoticonsKeyboardKeyItem *)keyItem{
    [self setInRecentsEmoji:keyItem.textToInput];
}

// recent emojis are backed in NSUserDefaults to save them across app restarts.
+ (NSMutableArray *)recentEmojis {
    NSArray *emojis = [[NSUserDefaults standardUserDefaults] arrayForKey:RECENT_EMOJIS];
    NSMutableArray *recentEmojis = [emojis mutableCopy];
    if (recentEmojis == nil) {
        recentEmojis = [NSMutableArray array];
    }
    return recentEmojis;
}

+ (void)setRecentEmojis:(NSMutableArray *)recentEmojis {
    // remove emojis if they cross the cache maintained limit
    if ([recentEmojis count] > RECENT_EMOJIS_MAINTAINED_COUNT) {
        NSIndexSet *indexesToBeRemoved = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(RECENT_EMOJIS_MAINTAINED_COUNT, [recentEmojis count] - RECENT_EMOJIS_MAINTAINED_COUNT)];
        [recentEmojis removeObjectsAtIndexes:indexesToBeRemoved];
    }
    [[NSUserDefaults standardUserDefaults] setObject:recentEmojis forKey:RECENT_EMOJIS];
}

+ (void)setInRecentsEmoji:(NSString *)emoji {
    NSAssert(emoji != nil, @"Emoji can't be nil");
    
    NSMutableArray *recentEmojis = [self recentEmojis];
    for (int i = 0; i < [recentEmojis count]; ++i) {
        if ([recentEmojis[i] isEqualToString:emoji]) {
            [recentEmojis removeObjectAtIndex:i];
        }
    }
    [recentEmojis insertObject:emoji atIndex:0];
    [self setRecentEmojis:recentEmojis];
}

+ (void)clearRecentEmojis {
    [[NSUserDefaults standardUserDefaults] setObject:[NSMutableArray array] forKey:RECENT_EMOJIS];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)sharedEmotionsKeyboardKeyItemGroup:(OSDEmoticonsKeyboardKeyItemGroup *)keyItemGroup
             pressedKeyCellChangedFromCell:(OSDEmoticonsKeyboardKeyCell *)fromCell
                                    toCell:(OSDEmoticonsKeyboardKeyCell *)toCell
{
    static KeyboardPressedCellPopupView *pressedKeyCellPopupView;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pressedKeyCellPopupView = [[KeyboardPressedCellPopupView alloc] initWithFrame:CGRectMake(0, 0, 45, 110)];
        pressedKeyCellPopupView.hidden = YES;
        [[self sharedEmoticonsKeyboard] addSubview:pressedKeyCellPopupView];
    });
    
    if ([[self sharedEmoticonsKeyboard].keyItemGroups indexOfObject:keyItemGroup] == 0) {
        [[self sharedEmoticonsKeyboard] bringSubviewToFront:pressedKeyCellPopupView];
        if (toCell) {
            pressedKeyCellPopupView.keyItem = toCell.keyItem;
            pressedKeyCellPopupView.hidden = NO;
            CGRect frame = [[self sharedEmoticonsKeyboard] convertRect:toCell.bounds fromView:toCell];
            pressedKeyCellPopupView.center = CGPointMake(CGRectGetMidX(frame), CGRectGetMaxY(frame)-CGRectGetHeight(pressedKeyCellPopupView.frame)/2);
        }else{
            pressedKeyCellPopupView.hidden = YES;
        }
    }
}

@end
