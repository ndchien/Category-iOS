//
//  KeyboardPressedCellPopupView.h
//  ImgGlyphExample
//
//  Created by CMC iOS Dev on 21/10/2015.
//  Copyright (c) 2015 dzog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboard.h"

@interface KeyboardPressedCellPopupView : UIView
@property (nonatomic,strong) OSDEmoticonsKeyboardKeyItem *keyItem;
@end
