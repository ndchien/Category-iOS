//
//  ImageHorizontalLayout.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 04/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "ImageHorizontalLayout.h"

@interface ImageHorizontalLayout ()
@property (nonatomic,readonly) NSInteger     numberOfItems;
@property (nonatomic,readonly) NSInteger     numberOfItemsPerRow;
@end

@implementation ImageHorizontalLayout
- (NSInteger)numberOfItems {
    //We only allow 1 section in this kind of layout.
    NSInteger section = 0;
    return [self.collectionView.dataSource collectionView:self.collectionView numberOfItemsInSection:section];
}

- (NSInteger)numberOfItemsPerRow {
//    return floor((CGRectGetWidth(self.collectionView.frame) + self.itemSpacing)/(self.itemSize.width + self.itemSpacing)) ?: 1;
    NSInteger section = 0;
    return [self.collectionView.dataSource collectionView:self.collectionView numberOfItemsInSection:section];
}

- (void)prepareLayout{
    
}

- (CGSize)collectionViewContentSize{
    CGFloat width = self.itemSize.width*self.numberOfItemsPerRow + (self.numberOfItemsPerRow-1)*self.itemSpacing;
    CGFloat height = self.itemSize.height;
    return CGSizeMake(width, height);
}


- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger index = indexPath.row;
    CGRect frame    = (CGRect){
        {index*self.itemSize.width + index*self.itemSpacing,
            0},
        self.itemSize
    };
    
    UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    attributes.frame = frame;
    return attributes;
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect{
    NSMutableArray *array = [NSMutableArray array];
    for (int i=0; i<self.numberOfItems; i++){
        UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        if (CGRectIntersectsRect(rect, attributes.frame)) {
            [array addObject:attributes];
        }
    }
    return [array copy];
}
@end
