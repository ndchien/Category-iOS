//
//  ImageItemViewCell.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 05/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ImageItemViewCellDelegate <NSObject>

@optional
- (void)sendItemClick:(NSIndexPath*)indexPath;

@end

@interface ImageItemViewCell : UICollectionViewCell <UIGestureRecognizerDelegate>
@property (nonatomic) BOOL bSelected;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIImageView *imageBlur;
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;
@property (assign, nonatomic) id<ImageItemViewCellDelegate> delegate;
@property (weak, nonatomic) IBOutlet UIView *viewSelected;
@property (strong, nonatomic) NSIndexPath *indexPath;

- (IBAction)cancelClick:(id)sender;

- (IBAction)sendClick:(id)sender;

- (void)selectedCellItem;

- (void)removeSelected;
@end
