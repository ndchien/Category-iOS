//
//  ImageItemViewCell.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 05/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "ImageItemViewCell.h"

@implementation ImageItemViewCell
- (void)awakeFromNib{
    [super awakeFromNib];
    self.viewSelected.hidden = YES;
    self.viewSelected.alpha = 0;
    
    _btnCancel.layer.masksToBounds  = YES;
    _btnCancel.layer.cornerRadius   = CGRectGetWidth(_btnCancel.frame)/2;
    _btnCancel.layer.borderColor    = [[UIColor whiteColor]CGColor];
    _btnCancel.layer.borderWidth    = 2;
    
    _btnSend.layer.masksToBounds    = YES;
    _btnSend.layer.cornerRadius     = CGRectGetWidth(_btnSend.frame)/2;
    _btnSend.layer.borderColor      = [[UIColor whiteColor]CGColor];
    _btnSend.layer.borderWidth      = 2;
    
//    _btnCancel.backgroundColor      = [[UIColor whiteColor]colorWithAlphaComponent:60];
//    _btnSend.backgroundColor        = [[UIColor whiteColor]colorWithAlphaComponent:60];
    [_btnCancel addTarget:self action:@selector(cancelClick:) forControlEvents:UIControlEventTouchUpInside];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(btnSendTap:)];
    tap.delegate = self;
    [_btnSend addGestureRecognizer:tap];
}

- (void)btnSendTap:(UIGestureRecognizer *)gesture{
    NSLog(@"afasdfadsf");
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    CGPoint touchPointInButton = [touch locationInView:self];
    if (CGRectContainsPoint(_btnSend.frame, touchPointInButton) && self.bSelected) {
        NSLog(@"touch");
        [_delegate sendItemClick:self.indexPath];
    }
    return YES;
}

- (void)selectedCellItem{
    self.bSelected = YES;
    self.viewSelected.hidden = NO;
    NSLog(@"enable: %d", _btnCancel.enabled);
    [UIView animateWithDuration:.5 animations:^{
        self.viewSelected.alpha = 1;
    }];
}

- (void)removeSelected{
    self.bSelected = NO;
    self.viewSelected.alpha = 0;
    self.viewSelected.hidden = YES;
}

- (IBAction)cancelClick:(id)sender {
    NSLog(@"Cancel");
}

- (IBAction)sendClick:(id)sender {
    NSLog(@"Send");
}
@end
