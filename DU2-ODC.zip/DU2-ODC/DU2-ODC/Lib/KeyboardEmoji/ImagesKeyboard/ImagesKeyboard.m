//
//  ImagesKeyboard.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 04/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "ImagesKeyboard.h"
#import "ImageItemViewCell.h"
#import "ImageHorizontalLayout.h"

@interface ImagesKeyboard ()<ImageItemViewCellDelegate>

@end

@implementation ImagesKeyboard
@synthesize collectionView;

- (id)init {
    return [self initWithFrame:(CGRect){CGPointZero,OSDEmoticonsKeyboardDefaultSize}];
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupImagesKeyboard];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setupImagesKeyboard];
}


- (void)setupImagesKeyboard{
    // list image
    [self getAllPhotoCameraroll];
    _arrIndexSelected = [[NSMutableArray alloc] init];
    nibMyCellloaded = NO;
    
    ImageHorizontalLayout *imageLayout = [[ImageHorizontalLayout alloc] init];
    imageLayout.itemSize = CGSizeMake(180, 194);
    imageLayout.itemSpacing = ITEM_SPACE;
    imageLayout.lineSpacing = LINE_SPACE_IMAGE;
    collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), 194) collectionViewLayout:imageLayout];
    collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.backgroundColor = [UIColor whiteColor];
    collectionView.showsHorizontalScrollIndicator = NO;
    collectionView.showsVerticalScrollIndicator = NO;
    [self addSubview:collectionView];
    
}

- (void)layoutSubviews{
    
}

- (void)getAllPhotoCameraroll{
    if (self.assetsLibrary == nil) {
        _assetsLibrary = [[ALAssetsLibrary alloc] init];
    }
    if (self.groups == nil) {
        _groups = [[NSMutableArray alloc] init];
    } else {
        [self.groups removeAllObjects];
    }
    
    // setup our failure view controller in case enumerateGroupsWithTypes fails
    ALAssetsLibraryAccessFailureBlock failureBlock = ^(NSError *error) {
        NSString *errorMessage = nil;
        switch ([error code]) {
            case ALAssetsLibraryAccessUserDeniedError:
            case ALAssetsLibraryAccessGloballyDeniedError:
                errorMessage = @"The user has declined access to it.";
                break;
            default:
                errorMessage = @"Reason unknown.";
                break;
        }
        
    };
    
    // emumerate through our groups and only add groups that contain photos
    ALAssetsLibraryGroupsEnumerationResultsBlock listGroupBlock = ^(ALAssetsGroup *group, BOOL *stop) {
        
        ALAssetsFilter *onlyPhotosFilter = [ALAssetsFilter allPhotos];
        [group setAssetsFilter:onlyPhotosFilter];
        if ([group numberOfAssets] > 0)
        {
            [self.groups addObject:group];
        }
        else
        {
            // load data in first groups
            ALAssetsGroup *groupFirstCell;
            if (self.groups.count > 0) {
                groupFirstCell = self.groups[0];
            }else{
                groupFirstCell = group;
            }
            if (!self.assets) {
                _assets = [[NSMutableArray alloc] init];
            } else {
                [self.assets removeAllObjects];
            }
            
            ALAssetsGroupEnumerationResultsBlock assetsEnumerationBlock = ^(ALAsset *result, NSUInteger index, BOOL *stop) {
                
                if (result) {
                    [self.assets addObject:result];
                }
            };
            
            ALAssetsFilter *onlyPhotosFilter = [ALAssetsFilter allPhotos];
            [groupFirstCell setAssetsFilter:onlyPhotosFilter];
            [groupFirstCell enumerateAssetsUsingBlock:assetsEnumerationBlock];
            
            [self.collectionView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
        }
    };
    
    // enumerate only photos
    NSUInteger groupTypes = ALAssetsGroupAlbum | ALAssetsGroupEvent | ALAssetsGroupFaces | ALAssetsGroupSavedPhotos;
    [self.assetsLibrary enumerateGroupsWithTypes:groupTypes usingBlock:listGroupBlock failureBlock:failureBlock];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.assets.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSString *identifier = [NSString stringWithFormat:@"ImageItemViewCell"];
    
    if(!nibMyCellloaded)
    {
        UINib *nib = [UINib nibWithNibName:@"ImageItemViewCell" bundle: nil];
        [self.collectionView registerNib:nib forCellWithReuseIdentifier:identifier];
        nibMyCellloaded = YES;
    }
    
    ImageItemViewCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
//    [cell setItemStatus:NO];
    if (indexPath.row < self.assets.count) {
        // load the asset for this cell
        
        ALAsset *asset = self.assets[indexPath.row];
        CGImageRef thumbnailImageRef = [asset aspectRatioThumbnail];
        UIImage *thumbnail = [UIImage imageWithCGImage:thumbnailImageRef];
        
        // apply the image to the cell
        cell.imageView.image = thumbnail;
        [cell.imageView setContentMode:UIViewContentModeScaleAspectFill];
//        if (cell.imageBlur.image == nil){
//            cell.imageBlur.image = [Util blurWithCoreImage:[UIImage imageWithCGImage:[asset thumbnail]] Frame:cell.imageView.frame Blur:@3];
//        }
        if ([_arrIndexSelected containsObject:indexPath]) {
            [cell selectedCellItem];
        }else{
            [cell removeSelected];
        }
        cell.indexPath = indexPath;
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ImageItemViewCell *item = (ImageItemViewCell *)[self.collectionView cellForItemAtIndexPath:indexPath];
    item.bSelected = !item.bSelected;
    if (item.bSelected) {
        [_arrIndexSelected removeAllObjects];
        [_arrIndexSelected addObject:indexPath];
        
        [item selectedCellItem];
    }else{
        [_arrIndexSelected removeAllObjects];
        [item removeSelected];
    }
    [self.collectionView reloadData];
}

- (void)sendItemClick:(NSIndexPath *)indexPath{
    ALAsset *asset = self.assets[indexPath.row];
    CGImageRef thumbnailImageRef = [asset aspectRatioThumbnail];
    UIImage *image = [UIImage imageWithCGImage:thumbnailImageRef];
    [_delegate sendImage:image];
}


@end
