//
//  ImagesKeyboard.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 04/11/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "OSDEmoticonsKeyboard.h"
#import <AssetsLibrary/AssetsLibrary.h>

@protocol ImagesKeyboardDelegate <NSObject>

@optional
- (void)sendImage:(UIImage *)image;

@end

@interface ImagesKeyboard : OSDEmoticonsKeyboard<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate>
{
    ALAssetsLibrary *library;
    NSArray *imageArray;
    NSMutableArray *mutableArray;
    BOOL nibMyCellloaded;
    BOOL nibCameraCellLoaded;
}
@property (strong, nonatomic) UIViewController *parrentVC;
@property (assign, nonatomic) id<ImagesKeyboardDelegate>delegate;
@property (strong, nonatomic) UICollectionView *collectionView;
@property (strong, nonatomic) NSMutableArray *arrIndexSelected;
@property (nonatomic, strong) ALAssetsLibrary *assetsLibrary;
@property (nonatomic, strong) NSMutableArray *groups;
@property (nonatomic, strong) NSMutableArray *assets;
@property (nonatomic, strong) ALAssetsGroup *assetsGroup;

@end
