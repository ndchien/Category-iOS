//
//  DownloadFileManager.h
//  X-Youtube
//
//  Created by CMC iOS Dev on 29/07/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FileDownloadInfo.h"

@interface DownloadFileManager : NSObject <NSURLSessionDelegate>
@property (nonatomic, strong) NSURLSession *session;

@property (nonatomic, strong) NSMutableArray *arrFileDownloadData;

@property (nonatomic, strong) NSURL *docDirectoryURL;

+ (instancetype)shareInstance;
-(void)initializeFileDownloadDataArray;
-(int)getFileDownloadInfoIndexWithTaskIdentifier:(unsigned long)taskIdentifier;

- (void)downloadWithFile:(FileDownloadInfo *)fileObj;
- (void)downloadResumeWithFile:(FileDownloadInfo *)fileObj;

- (FileDownloadInfo *)checkFileExits:(NSString *)fileID;

- (void)pauseDownloadFile:(FileDownloadInfo *)fileObj;

- (void)stopDownloadFile:(FileDownloadInfo *)fileObj;

- (void)stopAllDownloadFile;

@end
