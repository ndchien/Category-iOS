//
//  DownloadFileManager.m
//  X-Youtube
//
//  Created by CMC iOS Dev on 29/07/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "DownloadFileManager.h"
#import "AppDelegate.h"
#import "Constant.h"

@implementation DownloadFileManager

- (instancetype)init{
    self = [super init];
    if (self) {
        NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration backgroundSessionConfiguration:@"com.BGTransferDemo"];
        sessionConfiguration.HTTPMaximumConnectionsPerHost = 5;
        
        
        self.session = [NSURLSession sessionWithConfiguration:sessionConfiguration
                                                     delegate:self
                                                delegateQueue:nil];
    }
    self.arrFileDownloadData = [[NSMutableArray alloc] init];
    NSArray *URLs = [[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
    self.docDirectoryURL = [URLs objectAtIndex:0];
    
    return self;
}

+ (instancetype)shareInstance{
    static DownloadFileManager *instance;
    if (instance == nil) {
        instance = [[DownloadFileManager alloc] init];
    }
    return instance;
}



- (void)downloadWithFile:(FileDownloadInfo *)fileObj{
    FileDownloadInfo *obj = [self checkFileExits:fileObj.fileId];
    if (!obj) {
        [self.arrFileDownloadData addObject:fileObj];
        obj = fileObj;
    }
    
    if (!obj.isDownloading) {
        // This is the case where a download task should be started.
        
        // Create a new task, but check whether it should be created using a URL or resume data.
        if (obj.taskIdentifier == -1) {
            // If the taskIdentifier property of the fdi object has value -1, then create a new task
            // providing the appropriate URL as the download source.
            obj.downloadTask = [self.session downloadTaskWithURL:[NSURL URLWithString:obj.downloadSource]];
            
            // Keep the new task identifier.
            obj.taskIdentifier = obj.downloadTask.taskIdentifier;
            
            // Start the task.
            [obj.downloadTask resume];
        }
        else{
            // Create a new download task, which will use the stored resume data.
            obj.downloadTask = [self.session downloadTaskWithResumeData:obj.taskResumeData];
            [obj.downloadTask resume];
            
            // Keep the new download task identifier.
            obj.taskIdentifier = obj.downloadTask.taskIdentifier;
        }
        
        obj.isDownloading = YES;
    }else{
        // Create a new download task, which will use the stored resume data.
        obj.downloadTask = [self.session downloadTaskWithResumeData:obj.taskResumeData];
        [obj.downloadTask resume];
        
        // Keep the new download task identifier.
        obj.taskIdentifier = obj.downloadTask.taskIdentifier;
        
    }
}

- (void)downloadResumeWithFile:(FileDownloadInfo *)fileObj{
    if (![self checkFileExits:fileObj.fileId]) {
        [self.arrFileDownloadData addObject:fileObj];
    }
    NSURLSessionDataTask *dataTask = [self.session dataTaskWithURL:[NSURL URLWithString:fileObj.downloadSource]];
    [dataTask resume];
}

- (FileDownloadInfo *)checkFileExits:(NSString *)fileID{
    for (FileDownloadInfo *obj in self.arrFileDownloadData) {
        if ([obj.fileId isEqualToString:fileID]) {
            return obj;
        }
    }
    return nil;
}

- (void)pauseDownloadFile:(FileDownloadInfo *)fileObj{
    [fileObj.downloadTask cancelByProducingResumeData:^(NSData *resumeData) {
        if (resumeData != nil) {
            fileObj.taskResumeData = [[NSData alloc] initWithData:resumeData];
        }
    }];
    fileObj.isDownloading = NO;
}

- (void)stopDownloadFile:(FileDownloadInfo *)fileObj{
    // Cancel the task.
    [fileObj.downloadTask cancel];
    
    // Change all related properties.
    fileObj.isDownloading = NO;
    fileObj.taskIdentifier = -1;
    fileObj.downloadProgress = 0.0;
}

- (void)stopAllDownloadFile{
    for (FileDownloadInfo *obj in self.arrFileDownloadData) {
        [self stopDownloadFile:obj];
    }
}


-(int)getFileDownloadInfoIndexWithTaskIdentifier:(unsigned long)taskIdentifier{
    int index = 0;
    for (int i=0; i<[self.arrFileDownloadData count]; i++) {
        FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:i];
        if (fdi.taskIdentifier == taskIdentifier) {
            index = i;
            break;
        }
    }
    
    return index;
}

#pragma mark - NSURLSession Delegate method implementation

-(void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location{
    
    // Change the flag values of the respective FileDownloadInfo object.
    int index = [self getFileDownloadInfoIndexWithTaskIdentifier:downloadTask.taskIdentifier];
    FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:index];
    
    NSError *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSString *destinationFilename ;//= [NSString stringWithFormat:@"%@.mp4", downloadTask.originalRequest.URL.lastPathComponent];
//    destinationFilename = FILE_NAME_VIDEO(fdi.fileTitle, fdi.fileId);
    
    NSURL *destinationURL = [self.docDirectoryURL URLByAppendingPathComponent:destinationFilename];
    
    if ([fileManager fileExistsAtPath:[destinationURL path]]) {
        [fileManager removeItemAtURL:destinationURL error:nil];
    }
    
    BOOL success = [fileManager copyItemAtURL:location
                                        toURL:destinationURL
                                        error:&error];
    
    if (success) {
        
        
        fdi.isDownloading = NO;
        fdi.downloadComplete = YES;
        
        // Set the initial value to the taskIdentifier property of the fdi object,
        // so when the start button gets tapped again to start over the file download.
        fdi.taskIdentifier = -1;
        
        // In case there is any resume data stored in the fdi object, just make it nil.
        fdi.taskResumeData = nil;
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // Reload the respective table view row using the main thread.

            NSLog(@"Download finish file: %@", fdi.fileTitle);
            [self.arrFileDownloadData removeObject:fdi];
//            VideoObject *obj = [[VideoObject MR_findByAttribute:@"video_id" withValue:fdi.fileId] firstObject];
//            obj.isSaved = @"1";
//            obj.isDownloading = @"0";
//            obj.pathSaved = [NSString stringWithFormat:@"%@", destinationURL];
//            SAVE_DATABASE;
            [fdi.delegate fileDownloadFinish];
        }];
        
    }
    else{
        NSLog(@"Unable to copy temp file. Error: %@", [error localizedDescription]);
    }
}


-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error{
    if (error != nil) {
        NSLog(@"Download completed with error: %@", [error localizedDescription]);
        int index = [self getFileDownloadInfoIndexWithTaskIdentifier:task.taskIdentifier];
        if (index < self.arrFileDownloadData.count) {
            FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:index];
            [fdi.delegate fileDownloadError];
        }else{
            NSLog(@"out of array - Error");
        }
    }
    else{
        NSLog(@"Download finished successfully.");
        
    }
}


-(void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite{
    
    if (totalBytesExpectedToWrite == NSURLSessionTransferSizeUnknown) {
        NSLog(@"Unknown transfer size");
    }
    else{
        // Locate the FileDownloadInfo object among all based on the taskIdentifier property of the task.
        int index = [self getFileDownloadInfoIndexWithTaskIdentifier:downloadTask.taskIdentifier];
        if (index < self.arrFileDownloadData.count) {
            FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:index];
//            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
//                // Calculate the progress.
//                
//                
//            }];
            
            fdi.downloadProgress = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            if ([fdi.delegate respondsToSelector:@selector(fileDownloadWithPercent:)]) {
                [fdi.delegate fileDownloadWithPercent:fdi.downloadProgress];
            }
        }else{
            NSLog(@"out of array - finish");
        }
        
    }
}


-(void)URLSessionDidFinishEventsForBackgroundURLSession:(NSURLSession *)session{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    
    // Check if all download tasks have been finished.
    [self.session getTasksWithCompletionHandler:^(NSArray *dataTasks, NSArray *uploadTasks, NSArray *downloadTasks) {
        
        if ([downloadTasks count] == 0) {
            if (appDelegate.backgroundTransferCompletionHandler != nil) {
                // Copy locally the completion handler.
                void(^completionHandler)() = appDelegate.backgroundTransferCompletionHandler;
                
                // Make nil the backgroundTransferCompletionHandler.
                appDelegate.backgroundTransferCompletionHandler = nil;
                
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    // Call the completion handler to tell the system that there are no other background transfers.
                    completionHandler();
                    
                    // Show a local notification when all downloads are over.
                    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
                    localNotification.alertBody = @"Files have been downloaded!";
                    [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
                }];
            }
        }
    }];
}



@end
