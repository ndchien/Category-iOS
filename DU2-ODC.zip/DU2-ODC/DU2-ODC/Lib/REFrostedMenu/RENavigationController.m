//
//  RENavigationController.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 12/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//
#import "REFrostedViewController.h"
#import "RENavigationController.h"

@interface RENavigationController ()<UIGestureRecognizerDelegate>

@end

@implementation RENavigationController

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureRecognized:)];
    pan.delegate = self;
    [self.view addGestureRecognizer:pan];
}

#pragma mark -
#pragma mark Gesture recognizer

- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender
{
    // Dismiss keyboard (optional)
    //
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    
    // Present the view controller
    //
    [self.frostedViewController panGestureRecognized:sender];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([self.frostedViewController.delegate respondsToSelector:@selector(frostedViewControllerSlide)]) {
        return [self.frostedViewController.delegate frostedViewControllerSlide];
    }
    return NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
