//
//  UIColor+ColorByCode.h
//  EducationsReadingPractice
//
//  Created by Admin on 8/1/13.
//  Copyright (c) 2013 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (ColorByCode)
+(UIColor *)colorByCode: (NSString *) hexColor;
+(UIColor*)colorWithHexString:(NSString*)hex;
+(UIColor*)colorWithHex:(NSString*)hex alpha:(CGFloat)alpha;
@end
