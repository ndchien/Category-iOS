//
//  PullDownRefreshManager.m
//  DemoPullDownRefresh
//
//  Created by CMC iOS Dev on 19/04/2015.
//  Copyright (c) 2015 CMC iOS Dev. All rights reserved.
//

#import "PullDownRefreshManager.h"
#import <Foundation/Foundation.h>

static CGFloat const kAnimationDuration = 0.2f;

@class PullDownRefreshManager;



@implementation PullDownRefreshManager

- (instancetype)initWithPullToRefreshViewHeight:(CGFloat)height tableView:(UIScrollView *)table withDelegate:(id<PullDownRefreshManagerDelegate>)delegate{
    
    if (self = [super init]) {
        
        _delegate = delegate;
        _table = table;
        _pullToRefreshView = [[PullDownRefreshView alloc] initWithFrame:CGRectMake(0.0f, -height, CGRectGetWidth([_table frame]), height)];
        _pullToRefreshView.backgroundColor = [UIColor clearColor];
        
        [_table addSubview:_pullToRefreshView];
    }
    
    return self;
}

- (instancetype)initWithPullToRefreshViewHeight:(CGFloat)height ScrollView:(UIScrollView *)scrollView withDelegate:(id<PullDownRefreshManagerDelegate>)delegate {
    if (self = [super init]) {
        _delegate = delegate;
        _scrollView = scrollView;
        _pullToRefreshView = [[PullDownRefreshView alloc] initWithFrame:CGRectMake(0.0f, -height, CGRectGetWidth([_scrollView frame]), height)];
        _pullToRefreshView.backgroundColor = [UIColor clearColor];
        [_scrollView addSubview:_pullToRefreshView];
    }
    return self;
}

#pragma mark -
#pragma mark Table view scroll management

/*
 * Checks state of control depending on tableView scroll offset
 */
- (void)tableViewScrolled {
    if (![_pullToRefreshView isHidden] ) {
        CGFloat offset = [_table contentOffset].y;
        if (offset >= 0.0f) {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:offset];
        } else if (offset <= 0.0f && offset >= -[_pullToRefreshView fixedHeight]) {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStatePull withOffset:offset];
        } else {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateRelease withOffset:offset];
        }
    }
}

/*
 * Checks releasing of the tableView
 */
- (void)tableViewReleased {
    if (![_pullToRefreshView isHidden]) {
        CGFloat offset = [_table contentOffset].y;
        if (offset <= 0.0f && offset < -[_pullToRefreshView fixedHeight]) {
            UIEdgeInsets insets = UIEdgeInsetsMake([_pullToRefreshView fixedHeight], 0.0f, 0.0f, 0.0f);
            [UIView animateWithDuration:kAnimationDuration animations:^{
                [_table setContentInset:insets];
            }];
            if (!_bRefreshing) {
                [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateLoading withOffset:offset];
                _bRefreshing = YES;
                [_delegate pullToRefreshTriggered:self];
            }
        }
    }
}

/*
 * The reload of the table is completed
 */
- (void)tableViewReloadFinishedAnimated:(BOOL)animated {
    [UIView animateWithDuration:(animated ? kAnimationDuration : 0.0f) animations:^{
        [_table setContentInset:UIEdgeInsetsZero];
    } completion:^(BOOL finished) {
        NSLog(@"pull finish");
        _bRefreshing = NO;
        [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:CGFLOAT_MAX];
    }];
}

- (void)scrollViewReloadFinishedAnimated:(BOOL)animated {
    [UIView animateWithDuration:(animated ? kAnimationDuration : 0.0f) animations:^{
        [_scrollView setContentInset:UIEdgeInsetsZero];
    } completion:^(BOOL finished) {
        NSLog(@"pull finish");
        _bRefreshing = NO;
        [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:CGFLOAT_MAX];
    }];
}

#pragma mark -
#pragma mark Properties

/*
 * Sets the pull-to-refresh view visible or not. Visible by default
 */
- (void)setPullToRefreshViewVisible:(BOOL)visible {
    [_pullToRefreshView setHidden:!visible];
}

#pragma mark -
#pragma mark view scroll management

/*
 * Checks state of control depending on tableView scroll offset
 */
- (void)scrollViewScrolled {
    if (![_pullToRefreshView isHidden] ) {
        CGFloat offset = [_scrollView contentOffset].y;
        if (offset >= 0.0f) {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:offset];
        } else if (offset <= 0.0f && offset >= -[_pullToRefreshView fixedHeight]) {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStatePull withOffset:offset];
        } else {
            [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateRelease withOffset:offset];
        }
    }
}

/*
 * Checks releasing of the tableView
 */
- (void)scrollViewReleased {
    if (![_pullToRefreshView isHidden]) {
        CGFloat offset = [_scrollView contentOffset].y;
        if (offset <= 0.0f && offset < -[_pullToRefreshView fixedHeight]) {
            UIEdgeInsets insets = UIEdgeInsetsMake([_pullToRefreshView fixedHeight], 0.0f, 0.0f, 0.0f);
            [UIView animateWithDuration:kAnimationDuration animations:^{
                [_scrollView setContentInset:insets];
            }];
            if (!_bRefreshing) {
                [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateLoading withOffset:offset];
                _bRefreshing = YES;
                [_delegate pullToRefreshTriggered:self];
            }
        }
    }
}

/*
 * The reload of the table is completed
 */
- (void)ViewReloadFinishedAnimated:(BOOL)animated {
    [UIView animateWithDuration:(animated ? kAnimationDuration : 0.0f) animations:^{
        [_scrollView setContentInset:UIEdgeInsetsZero];
    } completion:^(BOOL finished) {
        NSLog(@"pull finish");
        _bRefreshing = NO;
        [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:CGFLOAT_MAX];
    }];
}

- (void)ReloadFinishedAnimated:(BOOL)animated {
    [UIView animateWithDuration:(animated ? kAnimationDuration : 0.0f) animations:^{
        [_scrollView setContentInset:UIEdgeInsetsZero];
    } completion:^(BOOL finished) {
        NSLog(@"pull finish");
        _bRefreshing = NO;
        [_pullToRefreshView changeStateOfControl:PullToRefreshViewStateIdle withOffset:CGFLOAT_MAX];
    }];
}
@end
