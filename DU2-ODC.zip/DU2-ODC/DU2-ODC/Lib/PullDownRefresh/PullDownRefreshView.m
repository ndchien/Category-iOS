//
//  PullDownRefreshView.m
//  DemoPullDownRefresh
//
//  Created by CMC iOS Dev on 19/04/2015.
//  Copyright (c) 2015 CMC iOS Dev. All rights reserved.
//

#import "PullDownRefreshView.h"

@implementation PullDownRefreshView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (id)initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        
        [self setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin];
        [self setBackgroundColor:[UIColor whiteColor]];
        
        _containerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, CGRectGetWidth(frame), CGRectGetHeight(frame))];
        
        [_containerView setBackgroundColor:[UIColor clearColor]];
        [_containerView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin];
        
        [self addSubview:_containerView];
        
        
        UIImage *iconImage = [UIImage imageNamed:@"icon_refresh.png"];
        
        _iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake((CGRectGetWidth(frame)-iconImage.size.width)/2, (CGRectGetHeight(frame)-iconImage.size.height)/2, iconImage.size.width, iconImage.size.height)];
        [_iconImageView setContentMode:UIViewContentModeCenter];
        [_iconImageView setImage:iconImage];
        [_iconImageView setAutoresizingMask:UIViewAutoresizingFlexibleRightMargin];
        
        [_containerView addSubview:_iconImageView];
        
        _loadingActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        [_loadingActivityIndicator setCenter:_iconImageView.center];
        [_loadingActivityIndicator setHidesWhenStopped:YES];
        [_loadingActivityIndicator setAutoresizingMask:UIViewAutoresizingFlexibleRightMargin];
        
        [_containerView addSubview:_loadingActivityIndicator];
        
        
        _fixedHeight = CGRectGetHeight(frame);
        _rotateIconWhileBecomingVisible = YES;
        
        [self changeStateOfControl:PullToRefreshViewStateIdle withOffset:CGFLOAT_MAX];
    }
    
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
    
    [self setFrame];
}

- (void)setFrame{
//    CGRect frame = self.frame;
    CGRect frame = [_containerView frame];
    frame.size.width = CGRectGetWidth(self.frame);
    [_containerView setFrame:frame];
    
//    _containerView.frame = CGRectMake(0.0f, 0.0f, CGRectGetWidth(frame), CGRectGetHeight(frame));
    
    frame = _iconImageView.frame;
    frame.origin.x = (CGRectGetWidth(_containerView.frame)-CGRectGetWidth(frame))/2;
    frame.origin.y = (CGRectGetHeight(_containerView.frame)-CGRectGetHeight(frame))/2;
    _iconImageView.frame = frame;
    
    [_loadingActivityIndicator setCenter:_iconImageView.center];
    
    frame = _loadingActivityIndicator.frame;
    frame.origin.x = (CGRectGetWidth(_containerView.frame)-CGRectGetWidth(frame))/2;
    frame.origin.y = (CGRectGetHeight(_containerView.frame)-CGRectGetHeight(frame))/2;
    _loadingActivityIndicator.frame = frame;
    
    //NSLog(@"FramePullView: %@", NSStringFromCGRect(_loadingActivityIndicator.frame));
    
    
    
    [_containerView setCenter:CGPointMake([_containerView center].x, [_containerView center].y)];
}

- (void)changeStateOfControl:(PullToRefreshViewState)state withOffset:(CGFloat)offset {
    
    _state = state;
    
    CGFloat height = _fixedHeight;
    CGFloat yOrigin = -_fixedHeight;
    
    switch (_state) {
            
        case PullToRefreshViewStateIdle: {
            [_iconImageView setTransform:CGAffineTransformIdentity];
            [_iconImageView setHidden:NO];
            [_loadingActivityIndicator stopAnimating];
            
            break;
            
        } case PullToRefreshViewStatePull: {
            if (_rotateIconWhileBecomingVisible) {
                
                CGFloat angle = (-offset * M_PI) / CGRectGetHeight([self frame]);
                
                [_iconImageView setTransform:CGAffineTransformRotate(CGAffineTransformIdentity, angle)];
                
            } else {
                _iconImageView.hidden = NO;
                [_iconImageView setTransform:CGAffineTransformIdentity];
                [_loadingActivityIndicator stopAnimating];
            }
            
            
            break;
            
        } case PullToRefreshViewStateRelease: {
            _iconImageView.transform = CGAffineTransformMakeRotation(M_PI);
            [_iconImageView setHidden:YES];
            [_loadingActivityIndicator startAnimating];
            height = -offset;
            yOrigin = offset;
            
            break;
            
        } case PullToRefreshViewStateLoading: {
            NSLog(@"============Loading....");
            [_iconImageView setHidden:YES];
            [_loadingActivityIndicator startAnimating];
            height = -offset;
            yOrigin = offset;
            
            
            break;
            
        } default:
            break;
    }
    
    CGRect frame = [self frame];
    frame.size.height = height;
    frame.origin.y = yOrigin;
    
    //NSLog(@"FramePullView: %@", NSStringFromCGRect(frame));
    
    [self setFrame:frame];
    [self layoutIfNeeded];
    [self setNeedsLayout];
}

#pragma mark -
#pragma mark Properties

/*
 * Returns state of activity indicator
 */
- (BOOL)isLoading {
    
    return [_loadingActivityIndicator isAnimating];
}

@end
