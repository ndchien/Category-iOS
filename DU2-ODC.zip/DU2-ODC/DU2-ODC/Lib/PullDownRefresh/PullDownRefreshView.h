//
//  PullDownRefreshView.h
//  DemoPullDownRefresh
//
//  Created by CMC iOS Dev on 19/04/2015.
//  Copyright (c) 2015 CMC iOS Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    
    PullToRefreshViewStateIdle = 0, //<! The control is invisible right after being created or after a reloading was completed
    PullToRefreshViewStatePull, //<! The control is becoming visible and shows "pull to refresh" message
    PullToRefreshViewStateRelease, //<! The control is whole visible and shows "release to load" message
    PullToRefreshViewStateLoading //<! The control is loading and shows activity indicator
    
} PullToRefreshViewState;


@interface PullDownRefreshView : UIView
@property (nonatomic, readonly) BOOL isLoading;
@property (nonatomic, readonly) CGFloat fixedHeight;

@property (nonatomic, readwrite, strong) UIView *containerView;

@property (nonatomic, readwrite, strong) UIActivityIndicatorView *loadingActivityIndicator;

@property (nonatomic, readwrite, strong) UILabel *topLabel;

@property (nonatomic, readwrite, assign) PullToRefreshViewState state;

@property (nonatomic, readwrite, strong) UIImageView *iconImageView;

@property (nonatomic, readwrite, assign) BOOL rotateIconWhileBecomingVisible;

- (void)changeStateOfControl:(PullToRefreshViewState)state withOffset:(CGFloat)offset;
@end
