//
//  PullDownRefreshManager.h
//  DemoPullDownRefresh
//
//  Created by CMC iOS Dev on 19/04/2015.
//  Copyright (c) 2015 CMC iOS Dev. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PullDownRefreshView.h"

@class PullDownRefreshManager;

@protocol PullDownRefreshManagerDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;

- (void)pullToRefreshTriggered:(PullDownRefreshManager *)manager;

@end

@interface PullDownRefreshManager : NSObject
@property (nonatomic, readwrite, strong) PullDownRefreshView *pullToRefreshView;
@property (nonatomic, readwrite, weak) UIScrollView *table;
@property (nonatomic, readwrite, weak) UIScrollView *scrollView;
@property (nonatomic, readwrite, weak) id<PullDownRefreshManagerDelegate> delegate;
@property (nonatomic, assign) BOOL bRefreshing;

- (id)initWithPullToRefreshViewHeight:(CGFloat)height tableView:(UIScrollView *)table withDelegate:(id<PullDownRefreshManagerDelegate>)delegate;

- (instancetype)initWithPullToRefreshViewHeight:(CGFloat)height View:(UIView *)view withDelegate:(id<PullDownRefreshManagerDelegate>)delegate;

- (void)setPullToRefreshViewVisible:(BOOL)visible; // Sets the pull-to-refresh view visible or not. Visible by default.

- (void)tableViewScrolled; // Checks the state of the pull to refresh view depending on the table's offset

- (void)tableViewReleased; // Checks releasing of the table to trigger refreshing.

- (void)tableViewReloadFinishedAnimated:(BOOL)animated; //Indicates that the reload of the table is completed.

- (void)ViewScrolled; // Checks the state of the pull to refresh view depending on the table's offset

- (void)ViewReleased; // Checks releasing of the table to trigger refreshing.

- (void)ViewReloadFinishedAnimated:(BOOL)animated; //Indicates that the reload of the table is completed
@end
