//
//  KeyboardImageViewCell.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 26/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "KeyboardImageViewCell.h"

@implementation KeyboardImageViewCell

- (void)awakeFromNib{
    [super awakeFromNib];
    _imgView.layer.masksToBounds = YES;
    _imgView.layer.borderWidth = .4;
    _imgView.layer.borderColor = [[UIColor colorWithRed:203/255. green:203/255. blue:203/255. alpha:1.]CGColor];
    
}

- (void)setItemStatus:(BOOL)status{
    self.bSelected = status;
    _imgCheck.image = [UIImage imageNamed:(self.bSelected)?@"icon_checkbox":@"icon_uncheckbox"];
    _viewAlpha.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:(self.bSelected)?.4:0];
}

- (void)defaultValue{
    self.bSelected = NO;
    _imgCheck.image = nil;
    _viewAlpha.backgroundColor = [UIColor clearColor];
}


@end
