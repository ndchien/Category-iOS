//
//  KeyboardImages.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 26/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OSDEmoticonsKeyboard.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "KeyboardImageViewCell.h"

@protocol KeyboardImagesDelegate <NSObject>

@optional
- (void)keyboardImageSelectImage:(UIImage*)image ALAsset:(ALAsset*)alAsset Index:(NSInteger)index;
- (void)keyboardImageDeselectImage:(UIImage*)image ALAsset:(ALAsset*)alAsset Index:(NSInteger)index;
- (void)imageFromCamera:(UIImage *)image;

@end

@interface KeyboardImages : OSDEmoticonsKeyboard <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    ALAssetsLibrary *library;
    NSArray *imageArray;
    NSMutableArray *mutableArray;
    BOOL nibMyCellloaded;
    BOOL nibCameraCellLoaded;
}
@property (strong, nonatomic) UIViewController *parrentVC;
@property (assign, nonatomic) id<KeyboardImagesDelegate>delegate;
@property (strong, nonatomic) UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UICollectionView *collView;
@property (strong, nonatomic) NSMutableArray *arrIndexSelected;

- (void)setLayoutItem;
@end
