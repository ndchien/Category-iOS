//
//  ImageFlowLayout.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 27/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageFlowLayout : UICollectionViewLayout

@property (nonatomic) CGSize        itemSize;
@property (nonatomic) CGFloat       lineSpacing;
@property (nonatomic) CGFloat       itemSpacing;

@end
