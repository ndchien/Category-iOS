//
//  KeyboardImageViewCell.h
//  DU2-ODC
//
//  Created by CMC iOS Dev on 26/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyboardImageViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UIImageView *imgCheck;
@property (assign, nonatomic) BOOL bSelected;
@property (weak, nonatomic) IBOutlet UIView *viewAlpha;

- (void)setItemStatus:(BOOL)status;
- (void)defaultValue;
@end
