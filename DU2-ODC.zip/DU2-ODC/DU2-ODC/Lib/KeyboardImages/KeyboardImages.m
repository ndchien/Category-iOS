//
//  KeyboardImages.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 26/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "KeyboardImages.h"
#import "OSDEmoticonsKeyboard.h"
#import "KeyboardImageViewCell.h"
#import "KeyboardCameraViewCell.h"
#import "ImageFlowLayout.h"
#import "UIResponder+WriteableInputView.h"
#import "JSQPhotoMediaItem.h"
#import "JSQMessage.h"


@interface KeyboardImages ()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>
@property (nonatomic,weak,readwrite) UIResponder<UITextInput>     *textInput;
@property (nonatomic, strong) ALAssetsLibrary *assetsLibrary;
@property (nonatomic, strong) NSMutableArray *groups;
@property (nonatomic, strong) NSMutableArray *assets;
@property (nonatomic, strong) ALAssetsGroup *assetsGroup;


@end

@implementation KeyboardImages
@synthesize collectionView, arrIndexSelected;
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (id)init {
    return [self initWithFrame:(CGRect){CGPointZero,OSDEmoticonsKeyboardDefaultSize}];
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupImagesKeyboard];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setupImagesKeyboard];
}


- (void)setupImagesKeyboard{
    // list image
//    [self getAllPictures];
    [self getAllPhotoCameraroll];
    nibMyCellloaded = NO;
    NSLog(@"Frame: %@", NSStringFromCGRect(self.frame));
    ImageFlowLayout *imageLayout = [[ImageFlowLayout alloc] init];
    float width = (CGRectGetWidth(self.frame)-8)/3;
    imageLayout.itemSize = CGSizeMake(width, (width*75)/104);
    imageLayout.itemSpacing = ITEM_SPACE;
    imageLayout.lineSpacing = LINE_SPACE_IMAGE;
    collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), 219) collectionViewLayout:imageLayout];
//    collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    collectionView.delegate = self;
    collectionView.dataSource = self;
    
    collectionView.backgroundColor = [UIColor whiteColor];
    collectionView.showsHorizontalScrollIndicator = NO;
    collectionView.showsVerticalScrollIndicator = NO;
    [self addSubview:collectionView];
    
    arrIndexSelected = [[NSMutableArray alloc] init];
}

- (void)setLayoutItem{
    ImageFlowLayout *imageLayout = [[ImageFlowLayout alloc] init];
    float width = (CGRectGetWidth(self.frame)-8)/3;
    imageLayout.itemSize = CGSizeMake(width, (width*HEIGHT_ITEM_IMAGE)/WIDTH_ITEM_IMAGE);
    imageLayout.itemSpacing = 4;
    imageLayout.lineSpacing = 4;
    [collectionView setCollectionViewLayout:imageLayout];
    [collectionView reloadData];
}

- (void)getAllPhotoCameraroll{
    if (self.assetsLibrary == nil) {
        _assetsLibrary = [[ALAssetsLibrary alloc] init];
    }
    if (self.groups == nil) {
        _groups = [[NSMutableArray alloc] init];
    } else {
        [self.groups removeAllObjects];
    }
    
    // setup our failure view controller in case enumerateGroupsWithTypes fails
    ALAssetsLibraryAccessFailureBlock failureBlock = ^(NSError *error) {
        NSString *errorMessage = nil;
        switch ([error code]) {
            case ALAssetsLibraryAccessUserDeniedError:
            case ALAssetsLibraryAccessGloballyDeniedError:
                errorMessage = @"The user has declined access to it.";
                break;
            default:
                errorMessage = @"Reason unknown.";
                break;
        }

    };
    
    // emumerate through our groups and only add groups that contain photos
    ALAssetsLibraryGroupsEnumerationResultsBlock listGroupBlock = ^(ALAssetsGroup *group, BOOL *stop) {
        
        ALAssetsFilter *onlyPhotosFilter = [ALAssetsFilter allPhotos];
        [group setAssetsFilter:onlyPhotosFilter];
        if ([group numberOfAssets] > 0)
        {
            [self.groups addObject:group];
        }
        else
        {
            // load data in first groups
            if (self.groups.count > 0) {
                ALAssetsGroup *groupFirstCell = self.groups[0];
                if (!self.assets) {
                    _assets = [[NSMutableArray alloc] init];
                } else {
                    [self.assets removeAllObjects];
                }
                
                ALAssetsGroupEnumerationResultsBlock assetsEnumerationBlock = ^(ALAsset *result, NSUInteger index, BOOL *stop) {
                    
                    if (result) {
                        [self.assets addObject:result];
                    }
                };
                
                ALAssetsFilter *onlyPhotosFilter = [ALAssetsFilter allPhotos];
                [groupFirstCell setAssetsFilter:onlyPhotosFilter];
                [groupFirstCell enumerateAssetsUsingBlock:assetsEnumerationBlock];
                
                [self.collectionView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
            }
            
        }
    };
    
    // enumerate only photos
    NSUInteger groupTypes = ALAssetsGroupAlbum | ALAssetsGroupEvent | ALAssetsGroupFaces | ALAssetsGroupSavedPhotos;
    [self.assetsLibrary enumerateGroupsWithTypes:groupTypes usingBlock:listGroupBlock failureBlock:failureBlock];
}


- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.assets.count+1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        NSString *identifierCamera = [NSString stringWithFormat:@"KeyboardCameraViewCell"];
        if(!nibCameraCellLoaded)
        {
            UINib *nib = [UINib nibWithNibName:@"KeyboardCameraViewCell" bundle: nil];
            [self.collectionView registerNib:nib forCellWithReuseIdentifier:identifierCamera];
            nibCameraCellLoaded = YES;
        }
        
        KeyboardCameraViewCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:identifierCamera forIndexPath:indexPath];
        
        return cell;
    }
    
    NSString *identifier = [NSString stringWithFormat:@"KeyboardImageViewCell"];
    
    if(!nibMyCellloaded)
    {
        UINib *nib = [UINib nibWithNibName:@"KeyboardImageViewCell" bundle: nil];
        [self.collectionView registerNib:nib forCellWithReuseIdentifier:identifier];
        nibMyCellloaded = YES;
    }
    
    KeyboardImageViewCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    if (![arrIndexSelected containsObject:indexPath]) {
        [cell setItemStatus:NO];
    }else{
        [cell setItemStatus:YES];
    }
    if (indexPath.row < self.assets.count+1) {
        // load the asset for this cell
        ALAsset *asset = self.assets[indexPath.row-1];
        CGImageRef thumbnailImageRef = [asset aspectRatioThumbnail];
        UIImage *thumbnail = [UIImage imageWithCGImage:thumbnailImageRef];
        
//        ALAssetRepresentation *assetRepresentation = [asset defaultRepresentation];
//        
//        UIImage *thumbnail = [UIImage imageWithCGImage:[assetRepresentation fullScreenImage]
//                                                       scale:[assetRepresentation scale]
//                                                 orientation:UIImageOrientationUp];
        
        // apply the image to the cell
        cell.imgView.image = thumbnail;
        [cell.imgView setContentMode:UIViewContentModeScaleAspectFill];
    }
    NSLog(@"Frame Item: %@", NSStringFromCGRect(cell.frame));
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        
        [self.collectionView deselectItemAtIndexPath:indexPath animated:YES];
        if (indexPath.row == 0) {
            // open camera
            [self openCameraSelect];
//            return;
        }else{
            KeyboardImageViewCell *item = (KeyboardImageViewCell *)[self.collectionView cellForItemAtIndexPath:indexPath];
            item.bSelected = !item.bSelected;
            if (item.bSelected) {
                [arrIndexSelected addObject:indexPath];
                
                [item setItemStatus:YES];
                if ([self.delegate respondsToSelector:@selector(keyboardImageSelectImage: ALAsset:Index:)]) {
                    [self.delegate keyboardImageSelectImage:item.imgView.image ALAsset:[self.assets objectAtIndex:indexPath.row-1] Index:indexPath.row];
                }
            }else{
                [arrIndexSelected removeObject:indexPath];
                [item setItemStatus:NO];
                if ([self.delegate respondsToSelector:@selector(keyboardImageDeselectImage:ALAsset:Index:)]) {
                    [self.delegate keyboardImageDeselectImage:item.imgView.image ALAsset:[self.assets objectAtIndex:indexPath.row-1] Index:indexPath.row];
                }
            }
        }
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"NSException:%@",exception.description);
    }
}

- (void)openCameraSelect{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.modalPresentationStyle = UIModalPresentationCurrentContext;
        imagePicker.allowsEditing = YES;
        
        [self.parrentVC presentViewController:imagePicker animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Camera Unavailable"
                                                       message:@"Unable to find a camera on your device."
                                                      delegate:nil
                                             cancelButtonTitle:@"OK"
                                             otherButtonTitles:nil, nil];
        [alert show];
        alert = nil;
    }
    
//    UIImagePickerControllerSourceType source = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera] ? UIImagePickerControllerSourceTypeCamera : UIImagePickerControllerSourceTypeSavedPhotosAlbum;
//    UIImagePickerController *cameraController = [[UIImagePickerController alloc] init];
//    cameraController.delegate = self;
//    cameraController.sourceType = source;
//    cameraController.allowsEditing = YES;
//    [self.parrentVC presentViewController:cameraController animated:YES completion:^{
//        if (source == UIImagePickerControllerSourceTypeCamera) {
//            [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
//        }
//    }];
}

#pragma mark - UIImagePickerDelegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //This creates a filepath with the current date/time as the name to save the image
    UIImage *image = nil;
    //This checks to see if the image was edited, if it was it saves the edited version as a .png
    if ([info objectForKey:UIImagePickerControllerEditedImage]) {
        //save the edited image
        image = [info objectForKey:UIImagePickerControllerEditedImage];
    }else{
        //save the original image
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
        
    }
    if ([_delegate respondsToSelector:@selector(imageFromCamera:)]) {
        [_delegate imageFromCamera:image];
    }
//    JSQPhotoMediaItem *photoItem = [[JSQPhotoMediaItem alloc] initWithImage:[UIImage imageNamed:@"goldengate"]];
//    JSQMessage *photoMessage = [JSQMessage messageWithSenderId:
//                                                   displayName:kJSQDemoAvatarDisplayNameSquires
//                                                         media:photoItem];

    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
