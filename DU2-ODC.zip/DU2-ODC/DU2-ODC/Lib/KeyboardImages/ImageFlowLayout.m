//
//  ImageFlowLayout.m
//  DU2-ODC
//
//  Created by CMC iOS Dev on 27/10/2015.
//  Copyright (c) 2015 CMC iOS Dev Luannv. All rights reserved.
//

#import "ImageFlowLayout.h"

@interface ImageFlowLayout ()

@property (nonatomic,readonly) NSInteger     numberOfItems;
@property (nonatomic,readonly) NSInteger     numberOfItemsPerRow;
@end

@implementation ImageFlowLayout

- (NSInteger)numberOfItems {
    //We only allow 1 section in this kind of layout.
    NSInteger section = 0;
    NSInteger numberOfItems = [self.collectionView.dataSource collectionView:self.collectionView numberOfItemsInSection:section];
    
    return numberOfItems;
}

- (NSInteger)numberOfItemsPerRow {
    CGRect frame = self.collectionView.frame;
    NSInteger widthMain = CGRectGetWidth(frame) + self.itemSpacing;
    NSInteger widthItem = self.itemSize.width + self.itemSpacing;
    NSInteger nRow = widthMain/widthItem;
    return nRow;
}

- (void)prepareLayout{
    
}

- (CGSize)collectionViewContentSize{
    CGRect frame = self.collectionView.frame;
    CGFloat height = ceil((float)self.numberOfItems/self.numberOfItemsPerRow) * self.itemSize.height + ((float)self.numberOfItems/self.numberOfItemsPerRow)*self.lineSpacing;
    CGFloat width = CGRectGetWidth(frame);
    return CGSizeMake(width, height);
}


- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger index = indexPath.row;
    NSInteger n     = index % self.numberOfItemsPerRow;
    NSInteger row   = floor(index/self.numberOfItemsPerRow);
    CGRect frame    = (CGRect){
        {n*(self.itemSize.width + self.itemSpacing),
            row*(self.itemSize.height + self.lineSpacing)},
        self.itemSize
    };
    
    UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    attributes.frame = frame;
    return attributes;
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect{
    NSMutableArray *array = [NSMutableArray array];
    for (int i=0; i<self.numberOfItems; i++){
        UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        if (CGRectIntersectsRect(rect, attributes.frame)) {
            [array addObject:attributes];
        }
    }
    return [array copy];
}



@end
