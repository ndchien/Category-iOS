//
//  AppDelegate.h
//  HiLife
//
//  Created by mac on 3/11/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) HomeViewController * homeViewController;
@property (nonatomic, strong) UINavigationController *navigationController;


- (void)goOutToLoginView;
@end

