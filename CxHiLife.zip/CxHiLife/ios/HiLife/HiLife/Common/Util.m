//
//  Util.m
//  ZindioApp
//
//  Created by nguyen on 7/27/14.
//  Copyright (c) 2014 DungIOS. All rights reserved.
//

#import "Util.h"
#import "NBPhoneNumberUtil.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import "LibraryAPI.h"
#import "StandContact.h"

@implementation Util

static UIView * currentProcessView ;

+ (NSString *)stripTags:(NSString *)str
{
    NSMutableString *html = [NSMutableString stringWithCapacity:[str length]];
    
    NSScanner *scanner = [NSScanner scannerWithString:str];
    scanner.charactersToBeSkipped = NULL;
    NSString *tempText = nil;
    
    while (![scanner isAtEnd])
    {
        [scanner scanUpToString:@"<" intoString:&tempText];
        
        if (tempText != nil)
            [html appendString:tempText];
        
        [scanner scanUpToString:@">" intoString:NULL];
        
        if (![scanner isAtEnd])
            [scanner setScanLocation:[scanner scanLocation] + 1];
        
        tempText = nil;
    }
    
    return html;
}

#pragma mark - Login - Register - Contact Number

+ (NSString *)checkAndNormalizeSingaporeRegionWithData:(NSString*)input {
    UserDataManager *userManager = [[LibraryAPI shareInstance] getUserManager];
    
    NSString *ISOcountryCode = [userManager getISOCountryCode]; // get country code, e.g. ES (Spain), FR (France), etc.
    
    if (ISOcountryCode) {
        NBPhoneNumberUtil *phoneUtil = [[NBPhoneNumberUtil alloc] init];
        NSError *anError = nil;
        NBPhoneNumber *myNumber = [phoneUtil parse:input
                                     defaultRegion:ISOcountryCode
                                             error:&anError];
        if (anError == nil) {
            NSString *contact = [phoneUtil  format:myNumber numberFormat:NBEPhoneNumberFormatINTERNATIONAL error:&anError];
            contact = [contact stringByReplacingOccurrencesOfString:@" " withString:@""];
            return contact;
        }
        return input;
    }
    else{
        NSString *contact = [StandContact removeNonPhoneCharacter:input];
        return contact;
    }
}

+ (NSString *)normalizeContactNumber:(NSString*)input {
    NBPhoneNumberUtil *phoneUtil = [[NBPhoneNumberUtil alloc] init];
    
    NSString *nationalNumber = nil;
    NSNumber *countryCode = [phoneUtil extractCountryCode:input nationalNumber:&nationalNumber];
    
    NSString *output = [NSString stringWithFormat:@"+%@-%@",countryCode,nationalNumber];
    return output;
}

+ (NSString *)convertFormatPhone:(NSString *)phone{
    if (phone.length > 0) {
        NSMutableString *result = [[NSMutableString alloc] initWithString:phone];
        NSRange range = [result rangeOfString:@"+"];
        if (range.location == NSNotFound)
        {
            [result insertString:@"+" atIndex:0];
        }
        if (result.length > 3) {
            [result insertString:@" " atIndex:3];
        }
        if (result.length > 8) {
            [result insertString:@" " atIndex:8];
        }
        return result;
    }
    return @"";
}

+ (NSString*) decodeString:(NSString*) string
{
    const char *c = [string cStringUsingEncoding:NSISOLatin1StringEncoding];
    NSString *newString = [[NSString alloc]initWithCString:c encoding:NSUTF8StringEncoding];
    NSLog(@"%@",newString);
    return newString;
}

+ (BOOL) isMatchPass:(NSString*)txtPass ConfirmPass:(NSString*)confirmPass {
    BOOL isMatch = false;
    if ([txtPass isEqualToString:confirmPass])
    {
        if ((txtPass.length > 0) && (confirmPass.length >0)) {
            isMatch = true;
        }
    }
    return isMatch;
    
}

+ (BOOL) isValidPassword:(NSString*) txtPass {
    BOOL isValid = false;
    
    if (txtPass.length >= 7 && [txtPass rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet]].location != NSNotFound) {
        // this matches the criteria
        isValid = true;
    }
    
    return isValid;
}

+(BOOL) IsValidEmail:(NSString *)checkString {
    //NSString *pattern = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
    NSString *pattern = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    return [self validateWithString:checkString withPattern:pattern];
}

+ (BOOL) IsValidPhoneNumber:(NSString *)checkString {
    NSString *pattern = @"^[0-9\-\+]{9,15}$";
    return [self validateWithString:checkString withPattern:pattern];
}

+ (BOOL) IsValidPhoneNumberByNSDataDetector:(NSString *)checkString {
    NSError *error = NULL;
    NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypePhoneNumber error:&error];
    
    NSRange inputRange = NSMakeRange(0, [checkString length]);
    NSArray *matches = [detector matchesInString:checkString options:0 range:inputRange];
    
    // no match at all
    if ([matches count] == 0) {
        return NO;
    }
    
    // found match but we need to check if it matched the whole string
    NSTextCheckingResult *result = (NSTextCheckingResult *)[matches objectAtIndex:0];
    
    if ([result resultType] == NSTextCheckingTypePhoneNumber && result.range.location == inputRange.location && result.range.length == inputRange.length && checkString.length < 13) {
        // it matched the whole string
        return YES;
    }
    else {
        // it only matched partial string
        return NO;
    }
}

+ (BOOL)validateWithString:(NSString *)string withPattern:(NSString *)pattern {
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
    
    NSAssert(regex, @"Unable to create regular expression");
    
    NSRange textRange = NSMakeRange(0, string.length);
    NSRange matchRange = [regex rangeOfFirstMatchInString:string options:NSMatchingReportProgress range:textRange];
    
    BOOL didValidate = NO;
    
    // Did we find a matching range
    if (matchRange.location != NSNotFound)
        didValidate = YES;
    
    return didValidate;
}



+ (CGRect)takeSystemFrameFromSubView:(UIView*)subView supperView:(UIView*)supperView{
    if (!subView ) {
        return CGRectZero;
    }
    CGRect viewFrame = subView.frame;
    UIView *tempView = subView;
    
    while (![tempView isEqual:supperView]) {
        CGRect viewSuperFrame = tempView.superview.frame;
        viewFrame = CGRectMake( viewSuperFrame.origin.x + viewFrame.origin.x , viewSuperFrame.origin.y + viewFrame.origin.y, viewFrame.size.width, viewFrame.size.height);
        tempView = tempView.superview;
        
    }
    NSLog(@"frame active: (%f %f) (%f %f) ",viewFrame.origin.x,viewFrame.origin.y,viewFrame.size.width,viewFrame.size.height);
    return viewFrame;
}

+ (CGRect)takeFrameFromSubView:(UIView*)subView supperView:(UIView*)supperView{
    if (!subView ) {
        return CGRectZero;
    }
    CGRect viewFrame = subView.frame;
    UIView *tempView = subView;
    
    while (![tempView.superview isEqual:supperView]) {
        CGRect viewSuperFrame = tempView.superview.frame;
        viewFrame = CGRectMake( viewSuperFrame.origin.x + viewFrame.origin.x , viewSuperFrame.origin.y + viewFrame.origin.y, viewFrame.size.width, viewFrame.size.height);
        tempView = tempView.superview;
        
    }
    NSLog(@"frame active: (%f %f) (%f %f) ",viewFrame.origin.x,viewFrame.origin.y,viewFrame.size.width,viewFrame.size.height);
    return viewFrame;
}

+ (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url controller:(UIViewController *) control {
    NSMutableArray *sharingItems = [NSMutableArray new];
    
    if (text) {
        [sharingItems addObject:text];
    }
    if (image) {
        [sharingItems addObject:image];
    }
    if (url) {
        [sharingItems addObject:url];
    }
    
    UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:sharingItems
                                                                                     applicationActivities:nil];
    //    activityController.excludedActivityTypes = @[UIActivityTypePostToFacebook,
    //                                                 UIActivityTypePostToTwitter,
    //                                                 UIActivityTypePostToFlickr,
    //                                                 UIActivityTypePostToVimeo,
    //                                                 UIActivityTypeMessage,
    //                                                 UIActivityTypeMail];
    
    [control presentViewController:activityController animated:YES completion:nil];
}

+ (NSString *) getAbsoluteImageURLWith:(NSString *) url {
    if ([url hasPrefix:PREFIX_IMAGE_UPLOAD]) {
        return [NSString stringWithFormat:@"%@%@", FILE_SERVER,url];
    } else {
        return url;
    }
    return url;
}


+ (void)getInstanceFromServerSesponse:(NSDictionary *)dic withInstance:(id)instance {
    NSArray *allKeys = [dic allKeys];
    for (NSString *key in allKeys)
    {
        NSString *setterStr = [NSString stringWithFormat:@"set%@%@:", [[key substringToIndex:1] capitalizedString], [key substringFromIndex:1]];
        if ([key isEqualToString:@"description"]) {
            setterStr = @"setDescriptions:";
        }
        if ([instance respondsToSelector:NSSelectorFromString(setterStr)]) {
            id value = dic[key];
            if ([value isKindOfClass:[NSNumber class]]) {
                value = [(NSNumber *)value stringValue];
                continue;
            }
            if ([value isKindOfClass:[NSDictionary class]]) {
                continue;
            }
            if ([key isEqualToString:@"image"]) {
                [instance setValue:[Util getAbsoluteImageURLWith:value] forKey:@"image"];
                continue;
            }
            if ([key isEqualToString:@"thumb_video"]) {
                [instance setValue:[Util getAbsoluteImageURLWith:value] forKey:@"thumb_video"];
                continue;
            }
            if ([key isEqualToString:@"description"]) {
                [instance setValue:value forKey:@"descriptions"];
                continue;
            }
            if ([value isKindOfClass:[NSNull class]]){
                [instance setValue:@"" forKey:@"descriptions"];
                continue;
            }
            [instance setValue:value forKey:key];
        }
    }
}

+ (NSString *) getDateStringWithFormat:(NSString *)format DateString:(NSString *) datestring {
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    NSLocale *enUSPOSIXLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [formater setLocale:enUSPOSIXLocale];
    [formater setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSCalendar* calendar = [NSCalendar currentCalendar];
    unsigned int flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit;
    NSDate *date = [formater dateFromString:datestring];
    NSDateComponents* components = [calendar components:flags fromDate:date];
    NSArray *months = @[@"Jan", @"Feb", @"Mar", @"Apr", @"May", @"Jun", @"Jul", @"Aug", @"Sep", @"Oct", @"Nov", @"Dec"];
    NSString *dateString = [NSString stringWithFormat:format, components.day, months[components.month - 1], components.year];
    return dateString;
}

+ (NSDate*)dateTimeWithFormat:(NSString*)format dateString:(NSString*)dateString {
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:format];
    NSDate *date = [formater dateFromString:dateString];
    return date;
}

+ (NSString *)daySuffixForDate:(NSDate *)date {
    //not support ios 7.1
    //    NSCalendar *calendar = [NSCalendar currentCalendar];
    //    NSInteger dayOfMonth = [calendar component:NSDayCalendarUnit fromDate:date];
    
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"d"];
    NSInteger day = [[dateFormat stringFromDate:date] intValue];
    
    switch (day) {
        case 1: return @"st";
        case 21: return @"st";
        case 31: return @"st";
        case 2: return @"nd";
        case 22: return @"nd";
        case 3: return @"rd";
        case 23: return @"rd";
        default: return @"th";
    }
}

+ (void) webViewDidFinishLoad:(UIWebView *)webView {
    CGRect oldBounds = [webView bounds];
    CGFloat height = [[webView stringByEvaluatingJavaScriptFromString:@"document.height"] floatValue];
    NSLog(@"NEW HEIGHT %f", height);
    [webView setBounds:CGRectMake(oldBounds.origin.x, oldBounds.origin.y, oldBounds.size.width, height)];
}

+ (CGSize)dynamicSizeWithText:(NSString*)text font:(UIFont*)font width:(CGFloat)width{
    //Compatible for both ios6 and ios7.
    CGSize constrainedSize = CGSizeMake(width, 9999);
    
    NSDictionary *attributesDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                          font, NSFontAttributeName,
                                          nil];
    
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:text attributes:attributesDictionary];
    
    CGRect requiredHeight = [string boundingRectWithSize:constrainedSize options:NSStringDrawingUsesLineFragmentOrigin context:nil];
    
    if (requiredHeight.size.width > width) {
        requiredHeight = CGRectMake(0,0, width, requiredHeight.size.height);
    }
    return CGSizeMake(width, requiredHeight.size.height);
}

#pragma mark - TakeYoutubeVideoID
+ (NSString *) getYoutubeVideoIDFromUrl:(NSString *) url {
    NSString *regexString = @"((?<=(v|V)/)|(?<=be/)|(?<=(\\?|\\&)v=)|(?<=embed/))([\\w-]++)";
    NSRegularExpression *regExp = [NSRegularExpression regularExpressionWithPattern:regexString
                                                                            options:NSRegularExpressionCaseInsensitive
                                                                              error:nil];
    
    NSArray *array = [regExp matchesInString:url options:0 range:NSMakeRange(0,url.length)];
    if (array.count > 0) {
        NSTextCheckingResult *result = array.firstObject;
        return [url substringWithRange:result.range];
    }
    return nil;
    
}
+ (NSString *) getThumbnailsFromYoutubeURL:(NSString *) url {
    return [NSString stringWithFormat:@"http://img.youtube.com/vi/%@/1.jpg",[self getYoutubeVideoIDFromUrl:url]];
}

+ (UIImage *)convertOriginalImageToBWImage:(UIImage *)originalImage {
    UIImage *newImage;
    
    CGColorSpaceRef colorSapce = CGColorSpaceCreateDeviceGray();
    CGContextRef context = CGBitmapContextCreate(nil, originalImage.size.width * originalImage.scale, originalImage.size.height * originalImage.scale, 8, originalImage.size.width * originalImage.scale, colorSapce, kCGImageAlphaNone);
    CGContextSetInterpolationQuality(context, kCGInterpolationHigh);
    CGContextSetShouldAntialias(context, NO);
    CGContextDrawImage(context, CGRectMake(0, 0, originalImage.size.width, originalImage.size.height), [originalImage CGImage]);
    
    CGImageRef bwImage = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSapce);
    
    UIImage *resultImage = [UIImage imageWithCGImage:bwImage];
    CGImageRelease(bwImage);
    
    UIGraphicsBeginImageContextWithOptions(originalImage.size, NO, originalImage.scale);
    [resultImage drawInRect:CGRectMake(0.0, 0.0, originalImage.size.width, originalImage.size.height)];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+ (NSString*) convertDate:(NSString*)dateString formatFrom:(NSString*)fromFormat toFormat:(NSString*)toFormat
{
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    NSLocale *indianLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [formatter setLocale:indianLocale];
    [formatter setDateFormat:fromFormat];
    NSDate* date = [formatter dateFromString:dateString];
    [formatter setDateFormat:toFormat];
    return [formatter stringFromDate:date];
}

+ (void) sendMailWithContent:(NSString *)mailcontent To:(NSArray *) to ViewControllerDelegate:(UIViewController<MFMailComposeViewControllerDelegate> *)controller {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
        mailer.mailComposeDelegate = controller;
        //NSArray *toRecipients = [NSArray arrayWithObjects:(company != nil ? company.email: @""), nil];
        [mailer setToRecipients:(to!=nil ? to : [NSArray arrayWithObject:@""])];
        [mailer setMessageBody:mailcontent isHTML:NO];
        if ([self respondsToSelector:@selector(presentViewController:animated:completion:)]){
            [controller presentViewController:mailer animated:YES completion:nil];
        } else {
            [controller presentViewController:mailer animated:YES completion:nil];
        }
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure"
                                                        message:@"Your device doesn't support the composer sheet"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
    }
}

+ (BOOL)isANumber:(NSString *)string{
    NSPredicate *numberPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES '^[0-9]+$'"];
    return [numberPredicate evaluateWithObject:string];
}

+ (BOOL) isTokenTimeOut:(NSNumber *) time {
    NSTimeInterval timeStampCurrent = [[NSDate date] timeIntervalSince1970] ;
    NSNumber *doubleValue = [NSNumber numberWithDouble:timeStampCurrent];
    NSComparisonResult compareResult = [doubleValue compare:time];
    NSLog(@"Current time: %@, ComapareTime: %@, result compare: %ld", doubleValue, time, compareResult);
    return compareResult == NSOrderedDescending;
}

+ (void) callToPhoneNumber:(NSString *)number {
    number =[number stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",number]];
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    } else {
        NSLog(@"Call facility is not available");
    }
}

+ (void) fitHeightUITextView:(UITextView *)textview {
    CGFloat fixedWidth = textview.frame.size.width;
    CGSize newSize = [textview sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
    CGRect newFrame = textview.frame;
    newFrame.size = CGSizeMake(fmaxf(newSize.width, fixedWidth), newSize.height);
    textview.frame = newFrame;
}

+ (BOOL) popToViewControllerWith:(UINavigationController *) naviagation ToControllerClass:(Class) controllerClass {
    for (UIViewController *vc in naviagation.childViewControllers) {
        if ([vc isKindOfClass:controllerClass]) {
            [naviagation popToViewController:vc animated:YES];
            return YES;
        }
    }
    return NO;
}

#pragma mark For Event

+ (NSDate*) takeDateTimeFromServiceWithData:(NSString*)data {
    NSDateFormatter* utcDf = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [utcDf setTimeZone:timeZone];
    [utcDf setDateFormat:kSERVER_DATE_FORMAT];
    NSDate* utcDate = [utcDf dateFromString:data];
    NSLog(@"utcDate %@",utcDate);
    
    NSDateFormatter* localDf = [[NSDateFormatter alloc] init];
    [localDf setTimeZone:[NSTimeZone localTimeZone]];
    [localDf setDateFormat:kSERVER_DATE_FORMAT];
    NSDate *localDate = [localDf dateFromString:[utcDf stringFromDate:utcDate]]; // you can also use str
    NSLog(@"localDate %@",localDate);
    
    return localDate;
}

+ (NSString*)takeDateTimeByDesignWithData:(NSString*)data {
    NSDate *date = [Util takeDateTimeFromServiceWithData:data];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
    
    //Take Day String
    NSString *daysuffixForDate = [Util daySuffixForDate:date];
    [format setDateFormat:@"dd"];
    NSString *dayStr = [format stringFromDate:date];
    dayStr = [dayStr stringByAppendingString:daysuffixForDate];
    
    //Take Month String
    [format setDateFormat:@"MMM"];
    NSString *monthStr = [format stringFromDate:date];
    
    return [NSString stringWithFormat:@"%@ %@",dayStr,monthStr];
}

+ (NSString *) getStringCurrencyFormatWithPrice:(NSString *) price andCode:(NSString *)code{
    NSString *newprice = [price stringByReplacingOccurrencesOfString:@"\\s"
                                                          withString:@""
                                                             options:NSRegularExpressionSearch
                                                               range:NSMakeRange(0, [price length])];
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
    [formatter setCurrencySymbol:code];
    [formatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    formatter.generatesDecimalNumbers = NO;
    [formatter setMaximumFractionDigits:2];
    NSNumber *number = [NSNumber numberWithFloat:newprice.floatValue];
    NSString *res = [formatter stringFromNumber:number];
    //    res = [res substringFromIndex:1];
        if ([res hasSuffix:@".00"]) {
            res = [res substringToIndex:(res.length - 3)];
        }
    return res;
}

+ (UIImage *)imageFromView:(UIView *)view{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

//Convert from 24h format to 12h format (original return null if device set time format is 24h)
+ (NSString *) formatTime:(NSString *)timeToBeFormatted {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    //ADDED//
    NSLocale *enUSPOSIXLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormat setLocale:enUSPOSIXLocale];
    
    [dateFormat  setDateFormat:@"HH"];
    NSDate *date = [[NSDate alloc] init];
    date = [dateFormat dateFromString:timeToBeFormatted];
    
    //ADDED//
    NSLocale *defualtLocale = [NSLocale currentLocale];
    [dateFormat setLocale:defualtLocale];
    
    [dateFormat setTimeStyle:NSDateFormatterShortStyle];
    timeToBeFormatted = [dateFormat stringFromDate:date];
    
    return timeToBeFormatted;
}

+ (void) sizeToFitViewPriceWithBGOldPrice:(UIImageView *)bgoldprice
                               BGNewPrice:(UIImageView *)bgnewprice
                            LabelOldPrice:(UILabel *)lbloldprice
                            LabelNewPrice:(UILabel *)lblnewprice{
    [lbloldprice sizeToFit];
    [lblnewprice sizeToFit];
    
    [bgoldprice setTranslatesAutoresizingMaskIntoConstraints:YES];
    [bgnewprice setTranslatesAutoresizingMaskIntoConstraints:YES];
    [lbloldprice setTranslatesAutoresizingMaskIntoConstraints:YES];
    [lblnewprice setTranslatesAutoresizingMaskIntoConstraints:YES];
    
    CGRect frameBGOldPrice, frameBGNewPrice, framelblOldPrice, framelblNewPrice;
    frameBGNewPrice = bgnewprice.frame;
    frameBGOldPrice = bgoldprice.frame;
    framelblOldPrice = lbloldprice.frame;
    framelblNewPrice = lblnewprice.frame;//new price
    
    frameBGOldPrice.size.width = framelblOldPrice.size.width + 16;
    framelblOldPrice.origin.x = frameBGOldPrice.origin.x + 8;
    frameBGNewPrice.origin.x = CGRectGetMaxX(frameBGOldPrice);
    frameBGNewPrice.size.width = framelblNewPrice.size.width + 16;
    framelblNewPrice.origin.x = frameBGNewPrice.origin.x + 8;
    
    [bgoldprice setFrame:frameBGOldPrice];
    [lbloldprice setFrame:framelblOldPrice];
    [bgnewprice setFrame:frameBGNewPrice];
    [lblnewprice setFrame:framelblNewPrice];
}

+ (double) getPriceDiscountWith:(double) price DiscountPercent:(double) discount {
    double res;
    res = price - discount; // discount gia tri tuyet doi
    //res = price - price * discount/100.0f;
    return res;
}

+ (NSArray *)sortFromNewDateToOldDateWithArray:(NSArray *)array withKey:(NSString *)key {
    
    NSMutableArray *keyArray = [[NSMutableArray alloc] init];
    NSString *kMainObject = @"Object";
    NSString *kMatching = @"Key";
    
    for (id instance in array) {
        NSString *setterStr = [NSString stringWithFormat:@"set%@%@:", [[key substringToIndex:1] capitalizedString], [key substringFromIndex:1]];
        if ([key isEqualToString:@"description"]) {
            setterStr = @"setDescriptions:";
        }
        if ([instance respondsToSelector:NSSelectorFromString(setterStr)]) {
            id value = [instance valueForKey:key];
            NSDate *convertedDate = [self takeDateTimeFromServiceWithData:value];
            [keyArray addObject:convertedDate];
        }
    }
    
    NSMutableArray *matchingArray = [NSMutableArray array];
    for (int idx = 0;idx<[array count];idx++) {
        NSDictionary *dict = @{kMainObject: array[idx],kMatching:keyArray[idx]};
        [matchingArray addObject:dict];
    }
    
    NSSortDescriptor *descriptor = [NSSortDescriptor sortDescriptorWithKey:@"Key" ascending:NO];
    
    NSArray *sortedArray = [matchingArray sortedArrayUsingDescriptors:@[descriptor]];
    
    NSMutableArray *result = [[NSMutableArray alloc] init];
    
    for (int idx = 0;idx<[sortedArray count];idx++) {
        id element = sortedArray[idx][kMainObject];
        [result addObject:element];
    }
    return [result copy];
}


#pragma mark - Progress while getting data from service
+ (void) showProgressGettingDataWithView:(UIView *) view ShowStatus:(BOOL) show {
    
    if (show == YES) {
        [MBProgressHUD showHUDAddedTo:view animated:YES];
    } else {
        [MBProgressHUD hideHUDForView:view animated:YES];
    }
    
    //chiennd : lưu lại view hiện tại để có thể fix lỗi khi có cuộc gọi đến , thì indicator không tắt , sẽ được tắt trong phần appdelegate -> DidBecomeActive
    
    currentProcessView =view;
}

#pragma mark - Fix lỗi khi có cuộc gọi đến , thì indicator không tắt , sẽ được tắt trong phần appdelegate -> DidBecomeActive
+(void)hideProgressFromAnyView{
    if(currentProcessView){
       [MBProgressHUD hideHUDForView:currentProcessView animated:YES];
    }
}

+ (BOOL) isContainString:(NSString *) sourcestring CompareString:(NSString *) stringcompare {
    return [sourcestring rangeOfString:stringcompare options:NSCaseInsensitiveSearch].location != NSNotFound;
}

//ChienND
#pragma mark - Lấy đường dẫn src Youtube trong đoạn html bất kì
+(NSString *)getSourceURL:(NSString *)htmlString {
    
    NSString *urlYouTube =@"";
    NSRange textRange;
    textRange =[htmlString rangeOfString:@"<iframe"];
    
    if(textRange.location != NSNotFound)
    {
        
        //<iframe width="560" height="315" src="https://www.youtube.com/embed/YXUMkatJ600" frameborder="0" allowfullscreen></iframe>
        
        //Does contain the substring
        NSArray * array =[htmlString componentsSeparatedByString:@"<iframe src=\""];
        
        if(array.count ==1){
            array =[htmlString componentsSeparatedByString:@"<iframe width=\"560\" height=\"315\" src=\""];
        }
        
        if(array && array.count >=2){
           urlYouTube = [array objectAtIndex:1];
           urlYouTube = [[urlYouTube componentsSeparatedByString:@"\""] objectAtIndex:0];
        }
    }
    
    return urlYouTube;
}

//chiennd
#pragma mark - return string html ma webview co the mo embed code youtube
+(NSString *)getHtmlAvailableOpenYoutube:(NSString *)htmlString{
    //Lấy đường dẫn YouTube
    NSString * urlYouTube= [self getSourceURL:htmlString];
    
    // <iframe id='playerId' type='text/html' width='%d' height='%d' src='http://www.youtube.com/embed/%@?enablejsapi=1&rel=0&playsinline=1&autoplay=1' frameborder='0'>\
    
    //Gán thuộc tính cho phép chạy javascript
    NSString * urlYouTubeExt =[NSString stringWithFormat:@"%@?enablejsapi=1&rel=0&playsinline=1&autoplay=0",urlYouTube];
    
    
    NSString* embedJavaScript = @"\
    <script type='text/javascript' src='http://www.youtube.com/iframe_api'></script>\
    <script type='text/javascript'>\
    function onYouTubeIframeAPIReady()\
    {\
    ytplayer=new YT.Player('playerId',{events:{onReady:onPlayerReady}})\
    }\
    function onPlayerReady(a)\
    { \
    a.target.playVideo(); \
    }\
    </script>";
    
    
    //Tao Id cho iFrame
    NSString * embedHTML =[htmlString stringByReplacingOccurrencesOfString:@"<iframe " withString:@"<iframe id='playerId' "];
    
    //thay lai duong dan Youtube
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:urlYouTube withString:urlYouTubeExt];
    
    //<iframe width="560" height="315" src="https://www.youtube.com/embed/oe2M_j-25M0" frameborder="0" allowfullscreen></iframe>
    
    //Xoa bo size mac dinh
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:@"width=\"560\"" withString:@""];
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:@"height=\"315\"" withString:@""];
    
    //Tong hop lai string gom javaScript + html da chinh sua
    embedHTML =[NSString stringWithFormat:@"%@ %@",embedJavaScript,embedHTML];
    
    //Chinh sưa đường dẫn ảnh trên server
    //<img src="../../../upload/file_upload/12991333-download-17.jpg" alt="" />
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:@"../../../" withString:FILE_SERVER];
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:@"../../" withString:FILE_SERVER];
    embedHTML =[embedHTML stringByReplacingOccurrencesOfString:@"../" withString:FILE_SERVER];
    
    //Chinh sua anh full width
    embedHTML = [embedHTML stringByReplacingOccurrencesOfString:@"<img" withString:@"<img width='100%' "];
    
    return embedHTML;
}

+ (float)getWebViewContentHeightWith:(UIWebView *) wv {
    return [[wv stringByEvaluatingJavaScriptFromString:@"document.body.scrollHeight;"] floatValue];
}

+ (void)showAlertViewWithTitle:(NSString *) title {
    
    BuyViewSuccess *alertSave = [[[NSBundle mainBundle] loadNibNamed:@"BuyViewSuccess" owner:self options:nil] firstObject];
    [alertSave setShowTransactionOrShowSaved:YES
                                       saved:YES withDescIfTran:nil
                          withDescBoldIfTran:nil withTitleIfSaved:title
                                    iConName:@"icon_fail"];
    [alertSave showCustomAlertView];
}

+ (void) checkPermission {
    Global *g = [Global getGlobal];
    if ([g.svcLogin.type integerValue] == VISITOR || [g.svcLogin.owner_pending intValue] == PENDING) {
        [Util showAlertViewWithTitle:MSG_VERIFY_PERMISSION];
        return;
    }
}

+ (BOOL) isOwnerOK {
    Global *g = [Global getGlobal];
    if ([g.svcLogin.type integerValue] == VISITOR || [g.svcLogin.owner_pending intValue] == PENDING) {
        [Util showAlertViewWithTitle:MSG_VERIFY_PERMISSION];
        return NO;
    }
    return YES;
}

+(NSString *)changeColorTextWebView :(NSString *)htmlString{
      return  [NSString stringWithFormat:@"<div style=\"color:%@\">%@</div>",DEFAULT_WEBVIEW_TEXT_COLOR,htmlString];
}

+(NSString *)changeFontTextWebView:(NSString *)htmlString FontName:(NSString *)fontName FontSize:(NSString *)fontSize{
    // fix hardcode
    fontName = @"Helvetica";
    fontSize = @"15px";
    
    if (htmlString.length > 0) {
        
        // change color
        NSMutableArray *arrResults = [self stringsBetweenString:htmlString Start:@"color:" endString:@";"];
        if (arrResults.count == 0) {
            return [NSString stringWithFormat:@"<div style=\"color:%@; font-family:'%@'; font-size:%@\">%@</div>", DEFAULT_WEBVIEW_TEXT_COLOR, fontName, fontSize, htmlString];
        }
        for (NSString *string in arrResults) {
            htmlString = [htmlString stringByReplacingOccurrencesOfString:string withString:DEFAULT_WEBVIEW_TEXT_COLOR];
        }
        // change font name
//        if (fontName.length > 0) {
            arrResults = [self stringsBetweenString:htmlString Start:@"font-family:" endString:@";"];
            for (NSString *string in arrResults) {
                htmlString = [htmlString stringByReplacingOccurrencesOfString:string withString:fontName];
            }
//        }
        
        // font size
//        if (fontSize.length > 0) {
            if (![fontSize hasSuffix:@"px"]) {
                fontSize = [fontSize stringByAppendingString:@"px"];
            }
            arrResults = [self stringsBetweenString:htmlString Start:@"font-size:" endString:@";"];
            for (NSString *string in arrResults) {
                htmlString = [htmlString stringByReplacingOccurrencesOfString:string withString:fontSize];
            }
//        }
        
        if ([htmlString rangeOfString:@"<body"].location == NSNotFound) {
            htmlString = [NSString stringWithFormat:@"<div style=\"color:%@; font-family:'%@'; font-size:%@\">%@</div>", DEFAULT_WEBVIEW_TEXT_COLOR, fontName, fontSize, htmlString];
        }
        return htmlString;
    }
    return @"";
}
+(NSMutableArray*)stringsBetweenString:(NSString *)string Start:(NSString*)start endString:(NSString*)end
{
    
    NSMutableArray* strings = [NSMutableArray arrayWithCapacity:0];
    NSRange startRange = [string rangeOfString:start];
    
    while (YES) {
        if (startRange.location != NSNotFound)
        {
            NSRange targetRange;
            targetRange.location = startRange.location + startRange.length;
            targetRange.length = [string length] - targetRange.location;
            
            NSRange endRange = [string rangeOfString:end options:0 range:targetRange];
            
            if (endRange.location != NSNotFound)
            {
                targetRange.length = endRange.location - targetRange.location;
                [strings addObject:[string substringWithRange:targetRange]];
                
                NSRange restOfString;
                restOfString.location = endRange.location + endRange.length;
                restOfString.length = [string length] - restOfString.location;
                
                startRange = [string rangeOfString:start options:0 range:restOfString];
                
            }
            else
                break;
        }
        else
            break;
    }
    return strings;
}

+(NSString *)formatterStringDecimalStyle :(NSString *)inputString {
    NSNumberFormatter * numberformat = [[NSNumberFormatter alloc] init];
    numberformat.numberStyle = NSNumberFormatterDecimalStyle;
    [numberformat setNegativeFormat:@"(0,00)"];

    NSString * amountformat = [numberformat stringFromNumber: [NSNumber numberWithFloat: [inputString floatValue]]];
    return amountformat;
}

@end
