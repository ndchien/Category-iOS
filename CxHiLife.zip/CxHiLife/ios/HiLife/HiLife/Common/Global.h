
#import <Foundation/Foundation.h>
#import "CommonModel.h"

#define USERNAME_DEMO @"admin@admin.com"
#define PASSWORD_DEMO @"123456"
#define DEFAULT_TOCKEN @"503680c500b2963fdad4ddbfb70769a2"
#define DEFAULT_USER_ID @"2"
#define LOGINED @"LOGINED"
#define DATE_FORMAT @"yyyy-MM-dd"
#define DATE_FORMAT_HOME @"%.2d %@ %.4d"
#define DATE_FORMAT_EVENT @"%.2d %@"
#define EVENT_DATE_FORMAT @"dddd MMM"
#define DEFAULT_IMAGE [UIImage imageNamed:@"no-image.png"]

#define BORDER_GREEN [UIColor colorWithRed:58.0/255.0 green:184.0/254.0 blue:160.0/254.0 alpha:1]

//thông số database & API  call Webservice
#define DATA_MODEL_STORE_NAME @"HiLife.sqlite"

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)

// web service urls
#define PREFIX_IMAGE_UPLOAD @"upload"

//Server CMC
//#define  API_SERVER @"http://101.99.13.183:8666/cms/service"
//#define  FILE_SERVER    @"http://101.99.13.183:8666/cms/"

//Server RML Upload AppStore
//#define DOMAIN_SERVER @"http://hilife2.rainmaker-labs.com"

//Server RML phase2
#define DOMAIN_SERVER @"http://staginghilife2.rainmaker-labs.com"
#define API_SERVER [NSString stringWithFormat:@"%@/service",DOMAIN_SERVER]
#define  FILE_SERVER [NSString stringWithFormat:@"%@/",DOMAIN_SERVER]

#define  SVC_COMMON_CONFIG  [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcCommonConfig"]
#define  URL_LOGIN  [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcLogin"]
#define URL_REGISTER [NSString stringWithFormat:@"%@%@", API_SERVER, @"/abtract/svcRegister"]
#define URL_FORGOT_PASSWORD [NSString stringWithFormat:@"%@%@", API_SERVER, @"/abtract/svcForgotPassword"]
#define URL_GET_LIST_STORE [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_store/svcGetStore"]
#define URL_GET_SPECIFIC_STORE [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_store/svcSpecificStore"]
#define URL_GET_LIST_INBOX [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_user/svcGetInbox"]
#define URL_GET_SPECIFIC_INBOX [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_user/svcSpecificInbox"]
#define URL_COUNT_NEW_INBOX [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_inbox/svcCountNewInbox"]
#define URL_UPDATE_INBOX_READER [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_inbox/svcUpdateReaderInbox"]
#define URL_DELETE_INBOX [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_inbox/svcDeleteInbox"]
#define URL_GET_DISTANCE [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_deals/svcGetFilterDistance"]
#define SVC_LOGIN [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcLogin"]
#define SVC_REGISTER [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcRegister"]
#define SVC_UP_TIMEZONE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcUpTimeZone"]
#define SVC_VERYFICATION [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcVerification"]
#define SVC_RESENDSMS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcReSendSms"]
#define SVC_FORGOT_PASSWORD [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcForgotPassword"]
#define SVC_ADD_PROPERTIES_LIVE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcAddPropertiesLive"]
#define SVC_GET_PROPERTIES_PAGE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcGetPropertiesLive"]
#define SVC_ADD_DEPENDENT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcAddDependent"]
#define SVC_GET_DEPENDENT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcGetDependent"]
#define SVC_GET_CATEGORIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/service_abtract/svcGetCategories"]
#define SVC_GET_FACILITIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/service_abtract/svcGetFacilities"]
#define SVC_GET_ABOUT_US [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcAboutYou"]
#define SVC_HOME_CONTENT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/service_abtract/svcHomeContent"]
#define SVC_ACTIVITIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_activities/svcActivities"]
#define SVC_SPECIAL_ACTIVITIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_activities/svcSpecificActivities"]
#define SVC_GET_DEALS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_deals/svcGetDeals"]
#define SVC_SAVE_DEALS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_deals/svcSaveDeals"]
#define SVC_BUY_BY_HICREDIT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcBuyByHiCredit"]
#define SVC_UPDATE_POCKET [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_pocket/svcUpdatePocket"]
#define SVC_GET_STORE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_store/svcGetStore"]
#define SVC_SPECIAL_STORE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_store/svcSpecificStore"]
#define SVC_SPECIAL_DEALS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_deals/svcSpecificDeals"]
#define SVC_SAVE_DEALS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_deals/svcSaveDeals"]
#define SVC_CHECK_QUANTITY_DEALS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_deals/svcCheckDealQuantity"]
#define SVC_GET_INBOX [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcGetInbox"]
#define SVC_SPECIFIC_INBOX [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcSpecificInbox"]
#define SVC_EVENTS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_events/svcEvents"]
#define SVC_SPECIFIX_EVENTS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_events/svcSpecificEvents"]
#define SVC_GET_LIST_DETAIL_FORM_EVENT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_events/svcGetListDetailFormEvent"]
#define SVC_SAVE_FROM_DATA_EVENT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_events/svcSaveFormDataEvent"]
#define SVC_GET_LIST_DETAIL_FORM_ACTIVITIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_activities/svcGetListDetailFormActivities"]
#define SVC_SAVE_FROM_DATA_ACTIVITIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_activities/svcSaveFormDataActivities"]

#define SVC_GET_QUESTION [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_feedback/svcGetQuestion"]
#define SVC_GET_COMPANY_SERVICE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcCommonConfig"]
#define SVC_SPECIFIX_COMPANY [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_feedback/svcSpecificCompany"]
#define SVC_SAVE_FEED_BACK [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_feedback/svcSaveFeedback"]
#define SVC_HOME_SERVICE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_home_service/svcHomeService"]
#define SVC_SPECIFIX_HOME_SERVICE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_home_service/svcSpecificHomeService"]
#define SVC_NEW_HOME [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcNewHome"]
#define SVC_SPECIFIX_NEW_HOME [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcSpecificNewHome"]
#define SVC_GET_CUSTOMISE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcGetCustomise"]
#define SVC_GET_CUSTOMISE_ISO [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcGetCustomiseiOS"]
#define SVC_UPDATE_TOTAL_PRICE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcUpdateTotalPrice"]
#define SVC_LIST_ITEM_BY_ROOM [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcListItemsByRoom"]
#define SVC_SAVE_BOOKING [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_new_home/svcSaveBooking"]
#define SVC_NEWS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_news/svcNews"]
#define SVC_SPECIFIX_NEWS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_news/svcSpecificNews"]
#define SVC_POCKET [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_pocket/svcPocket"]
#define SVC_CREDIT [NSString stringWithFormat:@"%@%@",API_SERVER,@"/service_abtract/svcPackageCredit"]
#define SVC_SPECIFIX_POCKET [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_pocket/svcSpecificPocket"]
#define SVC_DELETE_POCKET   [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_pocket/svcDeletePocket"]
#define SVC_PROPERTIES [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_properties/svcProperties"]
#define SVC_PROPERTIES_ITEMS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_properties/svcPropertiesItems"]
#define SVC_PROPERTIES_ITEM_DETAIL [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_properties/svcPropertiesItemsDetail"]
#define SVC_RACE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcRace"]
#define SVC_PROPERTIES_LIVE [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcGetAllPropertiesLive"]
#define SVC_CHECK_TRANSACTION [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcCheckTransaction"]
#define SVC_CHANGE_PASS [NSString stringWithFormat:@"%@%@",API_SERVER,@"/api_user/svcChangePass"]
#define SVC_GET_TOKEN [NSString stringWithFormat:@"%@%@",API_SERVER,@"/abtract/svcGetToken"]
#define SVC_UPDATE_PROFILE [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_user/svcUpdateProfile"]
#define SVC_GET_USER_INFO [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_user/svcGetUserInfo"]
#define SVC_JJTIPS [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_tips/svcTips"]
#define SVC_DETAIL_JJTIPS [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_tips/svcSpecificTips"]
#define SVC_BUY_WITH_PAYPAL [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_user/svcBuyWithPaypal"]

#define SVC_UPLOADFILE_AT_EVENT [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_events/svcUpload"]
#define SVC_UPLOADFILE_AT_ACTIVITIES [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_activities/svcUpload"]

#define SVC_CHECK_USER_JOINED_EVENT [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_events/check_user_joined_form"]
#define SVC_CHECK_USER_JOINED_ATIVITY [NSString stringWithFormat:@"%@%@", API_SERVER, @"/api_activities/check_user_joined_form"]
// google api start
// google place autocomplate api
#define PLACE_AUTOCOMPLETE_API(keyword) [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=%@", keyword, GOOGLE_PLACE_API_BROWSWER]
// google api end

//UserModel
#define MEMBER_ID @"member_id"
#define MEMBER_FULL_NAME @"member_fullname"
#define MEMBER_EMAIL @"member_email"
#define MEMBER_CONTACT_NUMBER @"member_contactNumber"
#define MEMBER_GENDER @"member_gender"
#define MEMBER_ADDRESS @"member_address"
#define MEMBER_PASSPORT @"member_passport"
#define MEMBER_SALT @"member_salt"
#define MEMBER_NATION_ID @"member_nationID"
#define MEMBER_DOD @"member_DOD"
#define MEMBER_PHOTO @"member_PHOTO"
#define MEMBER_NOTE @"member_NOTE"
#define MEMBER_USER_TOKEN @"member_USER_TOKEN"
#define MEMBER_OS_TYPE @"member_OS_TYPE"
#define MEMBER_MACHINE_CODE @"member_MACHINE_CODE"

// user
#define CREDIT_NOT_ENOUGH   @"You do not have sufficient credits to buy this deal."
#define QUANTITY_DEAL_NOT_ENOUGH   @"The quantity of deal expired or deal has expired"
#define MSG_DEDUCTED_CREDIT @"%@ HiCredits have been deducted from your account. "

//thư mục lưu image cache
#define IMAGES_CACHE_PATH            [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/images"]
#define AUDIOS_CACHE_PATH            [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/audios"]
#define DOCUMENT_CACHE_PATH          [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/documents"]

//Cấu hình thông báo hiển thị mất mạng
#define TOAST_IMAGE @"warning.png"
#define TOAST_TEXT @"Mất mạng"
#define TOAST_SUBTITLE @"Vui lòng kiểm tra lại kết nối 3G hoặc wifi"

//Khoảng cách màn hình chính cách bên phải , khi mà left menu được hiển thị
#define MENU_SLIDE_OFFSET 70

//Khai báo tên notify khi Menu bên trái được chọn
#define NOTIFICATION_MENU_SELECT @"NOTIFICATION_MENU_SELECT"

//Khai báo tên notify logout trên menu trái
#define NOTIFICATION_LOGOUT @"NOTIFICATION_LOGOUT"

// LUANNV Define ==================== START

// define height
#define HEIGHT_Tbl_Filter           170
#define HEIGHT_CELL_Filter          35

// define type filter
#define FILTER_ALL                  0
#define FILTER_Category             1

#define GMAPS_KEY_API               @"AIzaSyD-m3ASlb_3Uyit3OuzF3CfTR6DoVFv8Kg"
#define GOOGLE_PLACE_API_BROWSWER   @"AIzaSyAdiStlwixc1AQk-ZWCO4GMQsaxPHLd5rk"

// define for update profile
#define LIMIT_NEW_ADDRESS           5
#define TAG_VIEW_SHOW_IMAGE         10

#define ROW_CARS                    5
#define ROW_PETS                    6
#define ROW_DEPENDENTS              7


#define TYPE_DATA_ADDRESS           10
#define TYPE_DATA_MARITAL           11
#define TYPE_DATA_DAY               12
#define TYPE_DATA_MONTH             13
#define TYPE_DATA_YEAR              14
#define TYPE_DATA_RACE              15
#define TYPE_DATA_RADIO             16

#define TYPE_EVENT_BOOK             @"0"
#define TYPE_DEAL_PURCHASED         @"1"
#define TYPE_DEAL_SAVE              @"2"

#define LIMIT_YEAR                  90

#define MUNITE_REQUEST_NEW_INBOX    5

#define FORCUS_INPUT_BORDER_COLOR   [[UIColor colorWithRed:78/255.f green:220/255.f blue:255/255.f alpha:1.0f]CGColor]
#define DEFAULT_BORDER_COLOR        [[UIColor colorWithRed:219.f/255.f green:219.f/255.f blue:219.f/255.f alpha:1.0f]CGColor];

//Chiennd
#define DEFAULT_WEBVIEW_TEXT_COLOR @"#929292"

#define SYSTEM_VERSION                              ([[UIDevice currentDevice] systemVersion])
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([SYSTEM_VERSION compare:v options:NSNumericSearch] != NSOrderedAscending)
#define IS_IOS8_OR_ABOVE                            (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0"))

// LUANNV Define ==================== END
#define APP_SCREEN_HEIGHT [[UIScreen mainScreen] applicationFrame].size.height

#define TOPBAR_HEIGHT 76
#define REFRESH_VIEW_HEIGHT 60

#pragma mark - Constant at Event Page
#define kDefaultTableViewPadding 12.0
#define kSERVER_DATE_FORMAT @"yyyy-MM-dd HH:mm:ss"
#define kEXRIRE_DATE_FORMAT @"dd LLL yyyy"
#define kCornerRadiousForDetailForm 8.0f

#define ConstrainPlaceHolderImage [UIImage imageNamed:@"no-image"]

typedef NS_ENUM(NSInteger, ErrorCodes) {
    ErrorCodesNotAuthorized        = 2,
    ErrorCodesTokenExpire          = -1,
    ErrorCodesServerResponseUnknow = 1,
    ErrorCodesOk                   = 0,
    ErrorCodesRequestFault         = 3,
    ErrorCodesNothingDownload      = 4,
    ErrorCodesUnknow               = 5
};

typedef NS_ENUM(NSInteger, UserType) {
    VISITOR     = 1,
    OWNER       = 2,
};

typedef NS_ENUM(NSInteger, UserStatus) {
    PENDING     = 0,
    VERIFYED    = 1,
};

// Networking
typedef void (^AuthenticationCallback)(BOOL success, id result);
typedef void (^BooleanCallback)(BOOL success);
typedef void (^BoolAndValueCallback)(BOOL success, id result);
typedef void (^completionHandler)(ErrorCodes code, id result);

@interface Global : NSObject

@property (nonatomic, strong) SVCLogin *svcLogin;

//Return instance object
+ (instancetype)getGlobal;
-(NSString*)getExistenceToken;
- (void)downloadCategory;

//Convert ngay thang theo dinh dang 
+(NSString *)convertDateTime:(NSDate *) date;
+ (NSString *)convertDateTime:(NSString *)strTime andFormat:(NSString *)strFormat;
+(NSString *)getToken;
+(NSString *)getUserId;



#define    BUY_DEAL             @"0"
#define    BUY_HI_CREDIT        @"1"
#define    BUY_HOME_SERVICE @"2"

#pragma mark - contact number 
#define REGION_SYMBOL @"SG"
#define kISOCountryCode @"kISOCountryCode"
#define kJustEnteredContactNumber @"kJustEnteredContactNumber"

#pragma mark - Detail Form
#define kHeightForEachRowRadioButton 40.0f
#define kColumnForRadioButton   2
#define commonFormColor [[UIColor alloc] initWithRed:146.0f/255.0f green:146.0f/255.0f blue:146.0f/255.0f alpha:0.8f]

#pragma mark - Network manager
#define kTimeoutWithNormalConnection 70.0f
#define kTimeoutWithUploadConnection 200.0f

#pragma mark - Home Style
#define kMaximumCharacter 300

#define FACILITY_BOOKING_WEBSITE_URL @"http://qingjian.onezineapps.com/"
#define NOTIF_GALLERY_CONTROLLER_DID_HIDE @"GalleryControllerDidHide"

#define JOIN_NOW_TEXT_COLOR [[UIColor alloc] initWithRed:146.0f/255.0f green:146.0f/255.0f blue:146.0f/255.0f alpha:1.0f]

@end