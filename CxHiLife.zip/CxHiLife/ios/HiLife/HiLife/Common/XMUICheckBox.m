//
//  XMUICheckBox.m
//  eReport
//
//  Created by Hung Do Manh on 5/18/13.
//  Copyright (c) 2013 Hung Do Manh. All rights reserved.
//

#import "XMUICheckBox.h"
@interface XMUICheckBox()
-(void) onTouched:(id)sender;
@end
@implementation XMUICheckBox
@synthesize isSelected;
@synthesize delegate;

static UIImage* imgMarked = nil;
static UIImage* imgUnmarked = nil;
static BOOL haveImage;

/*
 
 * Initialize image for checked and unchecked states
 */
+ (void) setImage:(NSString*) checkedImage andUncheckedImage:(NSString*) uncheckedImage{
    if( imgMarked == nil) imgMarked = [UIImage imageNamed:checkedImage];
    if( imgUnmarked == nil) imgUnmarked = [UIImage imageNamed: uncheckedImage];
    
    if (imgMarked && imgUnmarked)
        haveImage = YES;
}

/*
 * check if image is set
 */
+ (BOOL) haveImage{
    return haveImage;
}
-(id) initWithCoder:(NSCoder *)aDecoder{

    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        //set the image for on and off
        if( imgMarked == nil) {
            NSLog(@"[XMUICheckBox] checked_image was not set. Please setImage before allocate instance.");
            return nil;
        };
        if( imgUnmarked == nil){
            NSLog(@"[XMUICheckBox] unchecked_image was not set. Please setImage before allocate instance.");
            return nil;

        }


        [self setImage:imgUnmarked forState:UIControlStateNormal];
        [self addTarget: self action:@selector(onTouched:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return self;

}


-(void) onTouched:(id)sender{
    isSelected = !isSelected;
    
    [self setImage:isSelected?imgMarked:imgUnmarked forState:UIControlStateNormal];
    //we callback
    if(delegate && [delegate respondsToSelector:@selector(checkBoxChangeState:checkbox:)]){
        [delegate checkBoxChangeState:isSelected checkbox:self];
    }
}
@end
