//
//  XMUICheckBox.h
//  eReport
//
//  Created by Hung Do Manh on 5/18/13.
//  Copyright (c) 2013 Hung Do Manh. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMUICheckBox;


#define CHECKBOX_CHECKED_IMG [UIImage imageNamed:@"pill_checkbox_checked_28x28.png"]
#define CHECKBOX_UNCHECKED_IMG [UIImage imageNamed:@"pill_checkbox_unchecked_28x28.png"]

@protocol XMUICheckBoxDelegate<NSObject>
-(void) checkBoxChangeState:(BOOL) selected checkbox:(XMUICheckBox*) sender;
@end

@interface XMUICheckBox : UIButton{
    BOOL isSelected;
}
//callback delegate
@property(assign , nonatomic) id<XMUICheckBoxDelegate> delegate;
@property BOOL isSelected;

+ (void) setImage:(NSString*) checkedImage andUncheckedImage:(NSString*) uncheckedImage;
+ (BOOL) haveImage;

@end
