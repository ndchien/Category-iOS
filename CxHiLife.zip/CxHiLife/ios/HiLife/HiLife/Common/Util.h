//
//  Util.h
//  ZindioApp
//
//  Created by nguyen on 7/27/14.
//  Copyright (c) 2014 DungIOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "MBProgressHUD.h"

@interface Util : NSObject

+ (NSString *)stripTags:(NSString *)str;
+ (NSString*) decodeString:(NSString*) string;
+ (BOOL) isMatchPass:(NSString*)txtPass ConfirmPass:(NSString*)confirmPass;
+ (BOOL) isValidPassword:(NSString*) txtPass;

+ (BOOL) IsValidEmail:(NSString *)checkString;

+ (BOOL) IsValidPhoneNumber:(NSString *)checkString;

+ (BOOL) IsValidPhoneNumberByNSDataDetector:(NSString *)checkString;

+ (BOOL)validateWithString:(NSString *)string withPattern:(NSString *)pattern;
+ (CGRect)takeSystemFrameFromSubView:(UIView*)subView supperView:(UIView*)supperView;
+ (CGRect)takeFrameFromSubView:(UIView*)subView supperView:(UIView*)supperView;
+ (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url controller:(UIViewController *) control;
+ (NSString *) getAbsoluteImageURLWith:(NSString *) url;
+ (void)getInstanceFromServerSesponse:(NSDictionary *)dic withInstance:(id)instance;
+ (NSString *) getDateStringWithFormat:(NSString *)format DateString:(NSString *) datestring;
+ (void) webViewDidFinishLoad:(UIWebView *)webView;
+ (CGSize)dynamicSizeWithText:(NSString*)text font:(UIFont*)font width:(CGFloat)width;

+ (NSString *) getYoutubeVideoIDFromUrl:(NSString *) url;
+ (NSString *) getThumbnailsFromYoutubeURL:(NSString *) url;

+ (BOOL)isANumber:(NSString *)string;
+ (NSString *)convertFormatPhone:(NSString *)phone;
+ (UIImage *)convertOriginalImageToBWImage:(UIImage *)originalImage;
+ (NSString*) convertDate:(NSString*)dateString formatFrom:(NSString*)fromFormat toFormat:(NSString*)toFormat;

+ (void) sendMailWithContent:(NSString *)mailcontent To:(NSArray *) to ViewControllerDelegate:(UIViewController<MFMailComposeViewControllerDelegate> *)controller;
+ (BOOL) isTokenTimeOut:(NSNumber *) time;

+ (void) callToPhoneNumber:(NSString *) number;

+ (NSDate*)dateTimeWithFormat:(NSString*)format dateString:(NSString*)dateString;

+ (NSString *)daySuffixForDate:(NSDate *)date ;
+ (void) fitHeightUITextView:(UITextView *) textview;
+ (BOOL) popToViewControllerWith:(UINavigationController *) naviagation ToControllerClass:(Class) controllerClass;

+ (UIImage *)imageFromView:(UIView *)view;

#pragma mark - Login - Register - Contact Number

+ (NSString *) checkAndNormalizeSingaporeRegionWithData:(NSString*)input ;

+ (NSString *)normalizeContactNumber:(NSString*)input ;


#pragma mark For Event
+ (NSDate*) takeDateTimeFromServiceWithData:(NSString*)data ;

+ (NSString*)takeDateTimeByDesignWithData:(NSString*)data ;

+ (NSString *) getStringCurrencyFormatWithPrice:(NSString *) price andCode:(NSString *)code;

//Convert from 24h format to 12h format (original return null if device set time format is 24h)
+ (NSString *) formatTime:(NSString *)timeToBeFormatted;

+ (void) sizeToFitViewPriceWithBGOldPrice:(UIImageView *)bgoldprice
                               BGNewPrice:(UIImageView *)bgnewprice
                            LabelOldPrice:(UILabel *)lbloldprice
                            LabelNewPrice:(UILabel *)lblnewprice;

+ (double) getPriceDiscountWith:(double) price DiscountPercent:(double) discount;

+ (NSArray *)sortFromNewDateToOldDateWithArray:(NSArray *)dateArray withKey:(NSString *)key;

#pragma mark - Progress while getting data from service
+ (void) showProgressGettingDataWithView:(UIView *) view ShowStatus:(BOOL) show;

#pragma mark - Fix lỗi khi có cuộc gọi đến , thì indicator không tắt , sẽ được tắt trong phần appdelegate -> DidBecomeActive
+(void)hideProgressFromAnyView;

+ (BOOL) isContainString:(NSString *) sourcestring CompareString:(NSString *) stringcompare;

//ChienND
#pragma mark - Lấy đường dẫn src Youtube trong đoạn html bất kì
+(NSString *)getSourceURL:(NSString *)htmlString;

//chiennd
#pragma mark - return string html ma webview co the mo embed code youtube
+(NSString *)getHtmlAvailableOpenYoutube:(NSString *)htmlString;
+ (float)getWebViewContentHeightWith:(UIWebView *) wv;
+ (void)showAlertViewWithTitle:(NSString *) title;

#pragma mark - Đổi màu mặc định text của webview
+(NSString *)changeColorTextWebView :(NSString *)htmlString;
+(NSString *)changeFontTextWebView:(NSString *)htmlString FontName:(NSString *)fontName FontSize:(NSString *)fontSize;

+ (void) checkPermission;
+ (BOOL) isOwnerOK;

// convert number to decimal
+(NSString *)formatterStringDecimalStyle :(NSString *)inputString;

@end
