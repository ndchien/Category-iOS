//
//  Messages.h
//  HiLife
//
//  Created by Tran Ba Dang on 4/15/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#ifndef HiLife_Messages_h
#define HiLife_Messages_h

#define MSG_CHECK_INTERNET_CONNECTION @"No connectivity. Please check your \r\n internet connection."

#define MSG_NEW_HOME_BOOK_SUCCESS @"Congratulations, your booking is successful. We will contact you shortly."
#define MSG_NEW_HOME_BOOK_FAIL_ROOMS_EMPTY @"You can not book this home because it not have any room!"
#define MSG_NEW_HOME_BOOK_FAIL @"Book not success!"


// luannv define message alert start
#define MSG_MAP_GET_LOCATION_FAIL   @"We have failed to get your location."        // get my location fail

#define MSG_STARTED_LOAD_VIDEO_FAIL @"Sorry, we couldn’t find the video, you may wish to try again."         // load video by link company config

#define MSG_INBOX_DELETE_FAIL       @"Delete message unsuccessfully."           // delete inbox fail


#define MSG_POCKET_DELETE_CONFIRM    @"Do you want to delete this pocket?"    // confirm delete pocket

#define MSG_INBOX_DELETE_CONFIRM    @"Do you want to delete this message?"    // confirm delete inbox

#define MSG_UPDATE_PROFILE_SUCCESS  @"Your profile have been updated."            // update profile success

#define MSG_UPDATE_PROFILE_FAIL     @"Sorry we have failed to update your profile, please try again."      // update profile fail

#define MSG_VALID_PASSWORD_EMPTY          @"The minimum password length is 6 characters."      // password input empty

#define MSG_VALID_OLD_PASSWORD_EMPTY          @"Please key in your old password."      // old password input empty

#define MSG_VALID_CONFIRM_PASSWORD_INCORRECT  @"Passwords do not match."      // confirm password incorrect

#define MSG_CHANGE_PASSWORD_SUCCESS @"Your password has been successfully changed."       // change password success

#define MSG_CHANGE_PASSWORD_FAIL    @"Sorry, we have failed to change your password, please try again."          // change password fail

#define TITLE_VERIFY_CHANGE_PASSWORD @"We will verify your information."

#define MSG_VERIFY_CHANGE_PASSWORD  @"Thank you for registering with us. We will notify you via email after verification. If there is any issue, please contact +65-64221621."

// luannv define message alert end

#pragma mark - login 

#define MSG_NEED_READ_TERM_CONDITIONS @"In order to use this app, you must agree to the Terms and Condition!"

#define MSG_NEED_ENTER_EMAIL @"Please enter your registered email or phone number!"

#define MSG_NEED_ENTER_PASSWORD @"Please enter your password!"

#define MSG_WRONG_EMAIL_OR_PHONE_AT_LOGIN @"You have entered an invalid email/phone number, please try again."

#define MSG_ACCOUNT_NOT_EXIST @"The account does not exist."

#pragma mark - register

#define MSG_NEED_FILL_INFOR  @"Please fill in all the fields."

#define MSG_WRONG_NUMBER_AT_REGISTER     @"Please provide a valid contact number!"

#define MSG_WRONG_EMAIL_AT_REGISTER     @"Please provide a valid email address!"

#pragma mark - FORGOT PASSWORD

#define MSG_NEED_ENTER_EMAIL_AT_FORGOT_PASSWORD @"Please enter your email!"

#define MSG_WRONG_EMAIL_AT_FORGOT_PASSWORD @"You have entered an invalid email, please try again."

#define MSG_CUSTOMIZE_PACKAGE_SAVE_CLICK @"Save successfully!"

#define MSG_CUSTOMIZE_PACKAGE_SAVE_CLICK_NO_ROOM @"Save not success, no room to save!"

#define MSG_VERIFICATION_CODE_INCORRECT @"The verification code is incorrect."

#define MSG_NEED_ENTER_VERIFICATION_CODE @"Please enter verification code."

#pragma mark - buy
#define MSG_BUY_WITH_HICREDIT @"You will be using %@ HiCredits\n in this transaction\n\nContinue?"

#pragma mark - Alert relate to network

#define MSG_ERROR_CODE_REQUEST_FAIL @"Hasn't the token."

//#define MSG_ERROR_CODE_NOTHING_DOWNLOAD @"The network could not be reached."

//#define MSG_ERROR_CODE_UNKNOWN @"The network could not be reached."

#define MSG_VERIFY_PERMISSION @"You need to be a verified HiLife member to use the feature."

#define MSG_BUY_HICREDIT @"You do not have sufficient credits to buy this deal."

#define MSG_REDEEM_SUCCESS @"Deals has been redeemed!"

#define MSG_REDEEM_CODE_FAIL @"This redeem code is not valid."

#define MSG_REDEEM_CODE_REENTER @"Please enter the code to redeem."

#define MSG_NOT_AUTHORIZED  @"Your account is logged in with another device."
#define MSG_TOKEN_EXPIRED  @"Your token is expired, please login again."

#pragma mark - Detail Form 

#define MSG_SAVE_FORM_SUCCESS @"We have received your request successfully."

#define MSG_SAVE_FORM_FAIL @"Join fail."

#endif
