
//  Created by ChienND on 03/11/15.
//  Copyright (c) 2015 Nguyen Duc Chien. All rights reserved.
//

#import "Global.h"
#import "LibraryAPI.h"

@implementation Global
@synthesize svcLogin;

static Global *pGlobal;

#pragma mark - Return instance object
+ (instancetype) getGlobal {
    if (!pGlobal) {
        pGlobal = [[Global alloc] init];
    }
    return pGlobal;
}

- (NSString*)getExistenceToken{
    if (!svcLogin) {
        svcLogin = [[SVCLogin MR_findAll] lastObject];
    }
    return svcLogin.token;
}

+ (NSString *)convertDateTime:(NSDate *) date{
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init] ;
    [dateFormatter setDateFormat:@"dd/MM/yyyy HH:mm"] ;
    return  [dateFormatter stringFromDate:date] ;
}

+ (NSString *)convertDateTime:(NSString *)strTime andFormat:(NSString *)strFormat{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setAMSymbol:@"am"];
    [dateFormatter setPMSymbol:@"pm"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    NSLocale *indianLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:indianLocale];
    [dateFormatter setDateFormat:kSERVER_DATE_FORMAT];
    NSDate *date = [dateFormatter dateFromString:strTime];
    [dateFormatter setDateFormat:strFormat];
    return [dateFormatter stringFromDate:date];
}

- (void)downloadCategory{
    // luannv implement start
    ModelManager *modelMng = [[ModelManager alloc] init];
    
    // download list categories
    [[LibraryAPI shareInstance] saveListCategoryWithCallback:^(BOOL success, id result) {
        if (success) {
            NSLog(@"Download categories company succuss");
        }else{
            NSLog(@"Download categories company fail");
        }
    }];
    
    // get distance and home service

    [[LibraryAPI shareInstance] saveListDistanceWithType:@"2" Callback:^(BOOL success, id result) {
        if (success) {
            
            [modelMng saveListDistanceWithData:result andType:@"2"];
        }
    }];
    
    
    // get list Race
    [[LibraryAPI shareInstance] getListRaceWithCallback:^(BOOL success, id result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (success) {
                [modelMng saveListRaceWithData:result];
            }
        });
    }];
    
    // getlist All Property live
    [[LibraryAPI shareInstance] getAllPropertyLive:^(BOOL success, id result) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (success) {
                [modelMng saveListAllPropertyLiveWithData:result];
            }
        });
    }];
    
    // luannv implements end
}
+ (NSString *)getToken {return @"";}
+ (NSString *)getUserId { return @"";}
@end
