//
//  AvatarView.h
//  TestAvatar
//
//  Created by Toan Hoang Duc on 11/7/13.
//  Copyright (c) 2013 Toan Hoang Duc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    kStatusIndicatorSideRight,
    kStatusIndicatorSideLeft
} StatusIndicatorSide;

//Custom views
@class jSImageView;

@interface AvatarView : UIView {
    
}
@property (nonatomic, strong) UIImage     *image;
@property (nonatomic, strong) NSString    *imageURL;
@property (nonatomic, strong) jSImageView *imageView;

- (void)cancel;
- (UIImage *)image;

@end
