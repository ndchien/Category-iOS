//
//  jSDownloader.h
//  OneNight
//
//  Created by Toan Hoang Duc on 10/7/13.
//  Copyright (c) 2013 Son. All rights reserved.
//

#import <Foundation/Foundation.h>

//Protocols
#import "jSDownloaderDelegate.h"

@interface jSDownloader : NSObject <NSURLConnectionDataDelegate> {
    
    
}
@property (nonatomic, weak) id<jSDownloaderDelegate> subDelegate;

@property (nonatomic, strong) NSString *link;
@property (nonatomic, strong) NSURLConnection *connection;
@property (nonatomic) BOOL isDownloading;

@property (nonatomic, strong) NSMutableData *data;

- (id)initWithLink:(NSString *)link;

- (void)startDownLoad;
- (void)cancelDownLoad;

@end
