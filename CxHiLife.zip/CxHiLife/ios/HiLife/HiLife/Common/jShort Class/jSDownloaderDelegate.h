//
//  jSDownloaderDelegate.h
//  OneNight
//
//  Created by Toan Hoang Duc on 10/7/13.
//  Copyright (c) 2013 Son. All rights reserved.
//

#import <Foundation/Foundation.h>

@class jSDownloader;

@protocol jSDownloaderDelegate <NSObject>

@optional
- (void)downloaderDidFail:(jSDownloader *)downloader withError:(NSError *)error;
- (void)downloader:(jSDownloader *)downloader didFinishWithResultData:(NSData *)data;

@end
