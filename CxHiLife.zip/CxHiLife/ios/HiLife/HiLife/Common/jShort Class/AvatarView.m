//
//  AvatarView.m
//  TestAvatar
//
//  Created by Toan Hoang Duc on 11/7/13.
//  Copyright (c) 2013 Toan Hoang Duc. All rights reserved.
//

#define MASK_IMAGE    @"avatar-mask.png"

#import "AvatarView.h"

//Custom views
#import "jSImageView.h"

@implementation AvatarView

@synthesize imageURL  =_imageURL;
@synthesize imageView =_imageView;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self =[super initWithCoder:aDecoder]) {
        [self setDefaults];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setDefaults];
    }
    return self;
}

- (void)setDefaults
{
    [self setBackgroundColor:[UIColor lightGrayColor]];
    _imageView =[[jSImageView alloc] initWithFrame:self.bounds];
    [self addSubview:_imageView];
    
    UIImage *imgMask = [UIImage imageNamed:MASK_IMAGE];
    CALayer *imgMaskLayer = [CALayer layer];
    imgMaskLayer.contents = (id)[imgMask CGImage];
    imgMaskLayer.frame = self.bounds;
    self.layer.mask = imgMaskLayer;
    self.layer.masksToBounds = YES;
}

- (void)cancel
{
    [_imageView cancel];
}

- (UIImage *)image
{ 
    return _imageView.image;
}

- (void)setImage:(UIImage *)image
{
    [_imageView setImage:image];
}

- (void)setImageURL:(NSString *)imageURL
{
    [self cancel];
    _imageURL =imageURL;
    [_imageView setImageURL:_imageURL];
}

@end
