//
//  jSImageView.m
//  TestAvatar
//
//  Created by Toan Hoang Duc on 11/7/13.
//  Copyright (c) 2013 Toan Hoang Duc. All rights reserved.
//

#define DEFAULT_IMAGE @"no-image.png"

#import "jSImageView.h"

//Downloader
#import "jSDownloader.h"

//Categories
#import "NSString+Ex.h"

@implementation jSImageView
@synthesize showDefaultImage =_showDefaultImage;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self =[super initWithCoder:aDecoder]) {
        [self setDefaults];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setDefaults];
    }
    return self;
}

- (void)setDefaults
{
    _showDefaultImage =YES;
    
    [self setBackgroundColor:[UIColor lightGrayColor]];
    [self setContentMode:UIViewContentModeScaleAspectFill];
    [self setImage:[UIImage imageNamed:DEFAULT_IMAGE]];
    [self setClipsToBounds:YES];
    
//    UIButton *button =[UIButton buttonWithType:UIButtonTypeCustom];
//    [button setFrame:self.bounds];
    //[button setShowsTouchWhenHighlighted:YES];
    //[button addTarget:self action:@selector(touchOnImage:) forControlEvents:UIControlEventTouchUpInside];
//    [self addSubview:button];
    
    [self setUserInteractionEnabled:YES];
}


//- (void)setDefaults
//{
//
//    _showDefaultImage =YES;
//    
//    //Chiennd edit thay ảnh mặc định bằng màu của category tương ứng
//    
//    [self setBackgroundColor:[Global getGlobal].cateColor];
//    [self setContentMode:UIViewContentModeScaleAspectFill];
//    
//    [self setImage:nil];
//    [self setClipsToBounds:YES];
//    
//    
//    UIButton *button =[UIButton buttonWithType:UIButtonTypeCustom];
//    [button setFrame:self.bounds];
//    [button setShowsTouchWhenHighlighted:YES];
//    [button addTarget:self action:@selector(touchOnImage:) forControlEvents:UIControlEventTouchUpInside];
//    [self addSubview:button];
//    
//    [self setUserInteractionEnabled:YES];
//}

- (void)cancel
{
    [_downloader cancelDownLoad];
    [_downloader setSubDelegate:nil];
}

- (void)setImageURL:(NSString *)imageURL
{
    [self cancel];
    _imageURL =imageURL;
    
    [self setImage:[UIImage imageNamed:DEFAULT_IMAGE]];
//    if(_showDefaultImage) [self setImage:[UIImage imageNamed:DEFAULT_IMAGE]];
//    else [self setImage:nil];
    
    
    NSString *imagePath =[NSString stringWithFormat:@"%@/%@", IMAGES_CACHE_PATH, [imageURL stringToMD5]];
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    
    if([fileManager fileExistsAtPath:imagePath]) {
        self.image =[UIImage imageWithContentsOfFile:imagePath];
    }
    else {
        _downloader =[[jSDownloader alloc] initWithLink:_imageURL];
        [_downloader setSubDelegate:self];
        [_downloader startDownLoad];
    }
    
    
}

- (void)touchOnImage:(UIButton *)button
{
    
    //chưa có image thì không cho bấm vào
//    if(!self.image) return;
//    
//    if(self.subDelegate && [self.subDelegate respondsToSelector:@selector(imageView:needViewFull:)]) {
//        [self.subDelegate imageView:self needViewFull:YES];
//    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark -
#pragma mark jSDownloader Delegate

- (void)downloader:(jSDownloader *)downloader didFinishWithResultData:(NSData *)data
{
    //save data ảnh vừa download xong vào cache
    NSString *imagePath =[NSString stringWithFormat:@"%@/%@",IMAGES_CACHE_PATH, [downloader.link stringToMD5]];
    [data writeToFile:imagePath atomically:YES];
   
    
    /* effect for display */
    [self.layer removeAllAnimations];
    [self setImage:[UIImage imageWithData:data]];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.15f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionFade;
    [self.layer addAnimation:transition forKey:nil];
    /* --------------------------------------------------- */
}

- (void)downloaderDidFail:(jSDownloader *)downloader withError:(NSError *)error
{
    
}

@end
