//
//  NSDate+StringTime.h
//  jShort
//
//  Created by Kevin on 9/30/13.
//  Copyright (c) 2013 Son. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (StringTime)

+ (NSString *)stringWithUnixTime:(NSDate *)unixTime;

@end
