
//  Created by Mr Toan on 7/21/12.
//  Copyright (c) 2012 VietNam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(Ex)
- (NSString *)stringToMD5;
- (NSString *)filterXMLReservedCharacters;

- (NSString *)stringByDecodingURLFormat;

//Chiennd : Ham convert ki tu Unicode thanh string binh thuong
-(NSString *)convertToUnicode;

@end
