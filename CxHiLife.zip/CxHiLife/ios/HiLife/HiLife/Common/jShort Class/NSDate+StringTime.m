//
//  NSDate+StringTime.m
//  jShort
//
//  Created by Kevin on 9/30/13.
//  Copyright (c) 2013 Son. All rights reserved.
//

#import "NSDate+StringTime.h"

@implementation NSDate (StringTime)

+ (NSString *)stringWithUnixTime:(NSDate *)unixTime
{
    NSString *resultString;
    int delta = [[NSDate date] timeIntervalSince1970] - [unixTime timeIntervalSince1970];
    
    if (delta < 60) {
        resultString =@"vài giây trước";
    } else if (delta < 120) {
        resultString =@"một phút trước";
    } else if (delta < (60 * 60)) {
        resultString =[[NSString stringWithFormat:@"%u",(delta / 60)] stringByAppendingString:@" phút trước"];
    } else if (delta < (120 * 60)) {
        resultString = @"một giờ trước";
    } else if (delta < (24 * 60 * 60)) {
        resultString =[[NSString stringWithFormat:@"%u",((delta / 3600) - 1)] stringByAppendingString:@" giờ trước"];
    } else if (delta < (48 * 60 * 60)) {
        resultString =@"hôm qua";
    }
//    else if (delta < (30 * 48 * 60 * 60)) {
//        resultString =[[NSString stringWithFormat:@"%u",(delta / 86400)] stringByAppendingString:@" ngày trước"];
//    }
    else {
        NSDateFormatter *dateFormatter =[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"h:mm, d MMM"];
        return [dateFormatter stringFromDate:unixTime];
    }
    
    return resultString;
}

@end
