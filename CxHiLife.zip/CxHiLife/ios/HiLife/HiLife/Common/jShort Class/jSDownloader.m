//
//  jSDownloader.m
//  OneNight
//
//  Created by Toan Hoang Duc on 10/7/13.
//  Copyright (c) 2013 Son. All rights reserved.
//

#import "jSDownloader.h"

@implementation jSDownloader
@synthesize link          =_link;
@synthesize connection    =_connection;
@synthesize isDownloading =_isDownloading;

- (id)initWithLink:(NSString *)link
{
    if(self =[super init]) {
        _link =link;
    }
    
    return self;
}

- (void)startDownLoad
{
    [self cancelDownLoad];
    
    if(_link && ![_link isEqual:[NSNull null]]) { //nếu có link thực sự
        _connection =[[NSURLConnection alloc] initWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_link]] delegate:self];
    }
    else  {
        if(_subDelegate && [_subDelegate respondsToSelector:@selector(downloaderDidFail:withError:)]) {
            [_subDelegate downloaderDidFail:self withError:nil];
        }
        else {
            // do nothing
        }
        _isDownloading =NO;
    }
}

- (void)cancelDownLoad
{
    [_connection cancel];
    [_connection setDelegateQueue:nil];
    
    _isDownloading =NO;
}

- (void)dealloc
{
    [_connection cancel];
    [_connection setDelegateQueue:nil];
}

#pragma mark -
#pragma mark NSURLConnection Delegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    _isDownloading =YES;
    _data =[[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_data appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    if(_subDelegate && [_subDelegate respondsToSelector:@selector(downloaderDidFail:withError:)]) {
        [_subDelegate downloaderDidFail:self withError:error];
    }
    else {
        // do nothing
    }
    _isDownloading =NO;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    if(_subDelegate && [_subDelegate respondsToSelector:@selector(downloader:didFinishWithResultData:)]) {
        [_subDelegate downloader:self didFinishWithResultData:[NSData dataWithData:_data]];
    }
    else {
        // do nothing
    }
    _isDownloading =NO;
}

@end
