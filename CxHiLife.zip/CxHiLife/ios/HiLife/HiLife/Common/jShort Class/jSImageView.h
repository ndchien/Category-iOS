//
//  jSImageView.h
//  TestAvatar
//
//  Created by Toan Hoang Duc on 11/7/13.
//  Copyright (c) 2013 Toan Hoang Duc. All rights reserved.
//

#import <UIKit/UIKit.h>

//Protocols
#import "jSDownloaderDelegate.h"

//Downloader
@class jSDownloader;

@protocol jSImageViewDelegate <NSObject>

@optional
- (void)imageView:(id)imageView needViewFull:(BOOL)viewFull;

@end

@interface jSImageView : UIImageView <jSDownloaderDelegate>{
    
}
@property (nonatomic, weak) id<jSImageViewDelegate> subDelegate;

@property (nonatomic, strong) NSString     *imageURL;
@property (nonatomic, strong) jSDownloader *downloader;

@property (nonatomic) BOOL showDefaultImage;

- (void)cancel;

@end
