//
//  LoadingView.h
//  AnUong
//
//  Created by Toan Hoang Duc on 4/25/14.
//  Copyright (c) 2014 Toan Hoang Duc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingView : UIView {
    
}
@property (nonatomic, unsafe_unretained) IBOutlet UIImageView *loadingImageView;

@end


// đây là loading view cần được xử dụng khi các kết nối internet đang hoạt đông.