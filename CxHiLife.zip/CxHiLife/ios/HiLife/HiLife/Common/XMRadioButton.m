//
//  RadioButton.m
//  RadioButton
//
//  Created by ohkawa on 11/03/23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XMRadioButton.h"

@interface XMRadioButton()
//-(void)defaultInit;
-(void)otherButtonSelected:(id)sender;
-(void)handleButtonTap:(id)sender;
-(UIButton*) getButton;
@end

@implementation XMRadioButton


@synthesize groupId=_groupId;
@synthesize index=_index;

static const NSString* DFLT_IMAGE_UNCHECKED = @"RadioButton-Unselected.png";
static const NSString* DFLT_IMAGE_CHECKED =  @"RadioButton-Selected.png";
static const NSString* IMAGE_BACKGROUND =  @"";

static UIImage* dfltImgUnChecked = nil; // init in initdefault
static UIImage* dfltImgChecked = nil;
static UIImage* imgBackground = nil;

static const NSUInteger kRadioButtonWidth=28;
static const NSUInteger kRadioButtonHeight=28;

static NSMutableArray *rb_instances=nil;
static NSMutableDictionary *rb_observers=nil;

//HungDM support get selectedButton by groupId
static NSMutableDictionary *selectedButtons=nil;
static NSMutableDictionary *imageCheckedLibrary=nil;
static NSMutableDictionary *imageUnCheckedLibrary=nil;
#pragma mark - Observer


#pragma mark - Manage Instances

+(void)addObserverForGroupId:(NSString*)groupId observer:(id<XMRadioButtonDelegate>)observer{
    if(!rb_observers){
        rb_observers = [[NSMutableDictionary alloc] init];
    }
    
    if ([groupId length] > 0 && observer) {
        [rb_observers setObject:observer forKey:groupId];
        // Make it weak reference
    }
}

+(void)registerInstance:(XMRadioButton*)radioButton{
    if(!rb_instances){
        rb_instances = [[NSMutableArray alloc] init];
    }
    
    [rb_instances addObject:radioButton];
}

#pragma mark - Class level handler

+(void)buttonSelected:(XMRadioButton*)radioButton{
    
    //HungDM tracing selected button with groupID
    if(!selectedButtons){
        selectedButtons = [[NSMutableDictionary alloc] init];
    }
    //only one selected button in one group
    [selectedButtons setObject: radioButton forKey: radioButton.groupId];
    
    // Notify observers
    if (rb_observers) {
        id observer= [rb_observers objectForKey:radioButton.groupId];
        
        if(observer && [observer respondsToSelector:@selector(radioButtonSelectedAtIndex:inGroup:)]){
            [observer radioButtonSelectedAtIndex:radioButton.index inGroup:radioButton.groupId];
        }
    }
    
    // Unselect the other radio buttons
    if (rb_instances) {
        for (int i = 0; i < [rb_instances count]; i++) {
            XMRadioButton *button = [rb_instances objectAtIndex:i];
            if (![button isEqual:radioButton] && [button.groupId isEqualToString:radioButton.groupId]) {
                [button otherButtonSelected:radioButton];
            }
        }
    }
}

#pragma mark - Object Lifecycle
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder: aDecoder];
    if (self) {
        [self defaultInit:nil];
    }
    return self;

}

-(void)initWithGroupId:(NSString*)groupId index:(NSUInteger)index{
//    self = [self init];
//    if (self) {
//        _groupId = groupId;
//        _index = index;
//        [self defaultInit:groupId];
//    }
    _groupId = groupId;
    _index = index;
    [self defaultInit:groupId];
    
    if(index==0)
    {
     [_button setSelected:YES];
    }
    
}

//- (id)init{
//    self = [super init];
//    if (self) {
//        [self defaultInit];
//    }
//    return self;
//}

#pragma mark - Tap handling

-(void)handleButtonTap:(id)sender{
    [_button setSelected:YES];
    [XMRadioButton buttonSelected:self];
}

-(void)otherButtonSelected:(id)sender{
    // Called when other radio button instance got selected
    if(_button.selected){
        [_button setSelected:NO];        
    }
}
-(UIButton*) getButton{
    return _button;
}
#pragma mark - RadioButton init

-(void)defaultInit:(NSString*) groupId{
    if(!dfltImgUnChecked)
        dfltImgUnChecked = [UIImage imageNamed: DFLT_IMAGE_UNCHECKED];
    if( !dfltImgChecked)
        dfltImgChecked = [UIImage imageNamed: DFLT_IMAGE_CHECKED];

    // Setup container view
    //TODO: uncommentit
    if(( self.frame.size.width < kRadioButtonWidth) ||
       (self.frame.size.height < kRadioButtonHeight)){
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, kRadioButtonWidth, kRadioButtonHeight);
    }
    
    // Customize UIButton
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    //HungDM: centralize the view
//    _button.frame = CGRectMake(0, 0,kRadioButtonWidth, kRadioButtonHeight);
    _button.frame = CGRectMake(0 + (self.frame.size.width - kRadioButtonWidth)/2,
                               0 + (self.frame.size.height - kRadioButtonHeight)/2,
                               kRadioButtonWidth, kRadioButtonHeight);
    _button.adjustsImageWhenHighlighted = NO;
    
    UIImage* unchecked = [imageUnCheckedLibrary objectForKey:groupId];
    if( !unchecked)
        [_button setImage: dfltImgUnChecked forState:UIControlStateNormal];
    else
        [_button setImage: unchecked forState:UIControlStateNormal];
    
    UIImage* checked = [imageCheckedLibrary objectForKey:groupId];
    if( !checked)
        [_button setImage: dfltImgChecked forState:UIControlStateSelected];
    else
        [_button setImage: checked forState:UIControlStateSelected];
    
    
    [_button addTarget:self action:@selector(handleButtonTap:) forControlEvents:UIControlEventTouchUpInside];
    
    [self addSubview:_button];
    
    [XMRadioButton registerInstance:self];
}

+ (void) setImageBackground:(NSString*) imageName  forGroupId:(NSString*)groupId{
    if(imageName){
        IMAGE_BACKGROUND = imageName;
        imgBackground = [UIImage imageNamed: IMAGE_BACKGROUND];
        if (rb_instances) {
            for (int i = 0; i < [rb_instances count]; i++) {
                XMRadioButton *button = [rb_instances objectAtIndex:i];
                if (button && [button.groupId isEqualToString: groupId]) {
//                    [[button getButton] setBackgroundImage: imgBackground forState:UIControlStateNormal];
                    [button setBackgroundColor:[UIColor colorWithPatternImage: imgBackground]];
                }
            }
        }
        
        
    }
}

+ (void) setBackgroundColor:(UIColor*) color forGroupId:(NSString*)groupId{
    if( color){
        if (rb_instances) {
            for (int i = 0; i < [rb_instances count]; i++) {
                XMRadioButton *button = [rb_instances objectAtIndex:i];
                if (button && [button.groupId isEqualToString: groupId]) {
//                    [[button getButton] setBackgroundColor:color];
                    [button setBackgroundColor: color];
                }
            }
        }

    }
}

+(void) setImageChecked:(NSString* ) imageName forGroupId:(NSString*)groupId{
    if( !imageCheckedLibrary){
        imageCheckedLibrary = [[NSMutableDictionary alloc] init];
    }
    UIImage* img = [UIImage imageNamed: imageName];
    if( !img){
        NSLog(@"Invalid image:%@ for Radiobutton group:%@", imageName, groupId);
        return;
    }
    [imageCheckedLibrary setObject:img forKey:groupId];

    if (rb_instances) {
        for (int i = 0; i < [rb_instances count]; i++) {
            XMRadioButton *button = [rb_instances objectAtIndex:i];
            if (button && [button.groupId isEqualToString: groupId]) {
                [[button getButton] setImage:[imageCheckedLibrary objectForKey:groupId] forState:UIControlStateNormal];
            }
        }
    }

}

+(void) setImageUnChecked:(NSString* ) imageName forGroupId:(NSString*)groupId{
    if( !imageUnCheckedLibrary){
        imageUnCheckedLibrary = [[NSMutableDictionary alloc] init];
    }
    UIImage* img = [UIImage imageNamed: imageName];
    if( !img){
        NSLog(@"Invalid image:%@ for Radiobutton group:%@", imageName, groupId);
        return;
    }

    [imageUnCheckedLibrary setObject:img forKey:groupId];
    if (rb_instances) {
        for (int i = 0; i < [rb_instances count]; i++) {
            XMRadioButton *button = [rb_instances objectAtIndex:i];
            if (button && [button.groupId isEqualToString: groupId]) {
                [[button getButton] setImage:[imageUnCheckedLibrary objectForKey:groupId] forState:UIControlStateSelected];
            }
        }
    }
    

}

/*
 * nil will be returned if no button was selected
 * or <code>groupId</code> is not valid.
 *
 */
+(XMRadioButton*) getSelectedButton:(NSString*) groupId{
    if(selectedButtons){
        return [selectedButtons objectForKey: groupId];
    }
    return nil;
}

@end
