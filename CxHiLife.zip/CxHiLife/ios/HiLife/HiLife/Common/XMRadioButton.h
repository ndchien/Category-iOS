//
//  RadioButton.h
//  RadioButton
//
//  Created by ohkawa on 11/03/23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol XMRadioButtonDelegate <NSObject>

-(void)radioButtonSelectedAtIndex:(NSUInteger)index inGroup:(NSString*)groupId;
@end

@interface XMRadioButton : UIView {
    NSString *_groupId;
    NSUInteger _index;
    UIButton *_button;
}
@property(nonatomic,retain)NSString *groupId;
@property(nonatomic,assign)NSUInteger index;

-(void)initWithGroupId:(NSString*)groupId index:(NSUInteger)index;

////////////////public function
+(void)addObserverForGroupId:(NSString*)groupId observer:(id<XMRadioButtonDelegate>)observer;
+ (void) setImageBackground:(NSString*) imageName forGroupId:(NSString*)groupId;
+ (void) setBackgroundColor:(UIColor*) color forGroupId:(NSString*)groupId;
+(void) setImageChecked:(NSString* ) imageName forGroupId:(NSString*)groupId;
+(void) setImageUnChecked:(NSString* ) imageName forGroupId:(NSString*)groupId;
+(XMRadioButton*) getSelectedButton:(NSString*) groupId;
+(void)buttonSelected:(XMRadioButton*)radioButton;

-(UIButton*) getButton;
@end
