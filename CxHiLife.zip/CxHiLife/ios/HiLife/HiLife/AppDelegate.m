
#import "AppDelegate.h"
#import "SlideNavigationController.h"
#import "LeftMenuViewController.h"
#import "SlideNavigationContorllerAnimatorFade.h"
#import <GoogleMaps/GoogleMaps.h>
#import "SVCCommonConfig.h"
#import "LibraryAPI.h"
#import "CommonVC.h"
#import "XMUICheckBox.h"

#import "Util.h"

@interface AppDelegate ()
@end

@implementation AppDelegate
@synthesize navigationController;

#pragma mark - AppDelegate methods

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [GMSServices provideAPIKey:GMAPS_KEY_API];
    [self setDefaults];
   // [self setRootViewController];
    
    
//    [[LibraryAPI shareInstance]  loginProgressWithUserName:USERNAME_DEMO password:PASSWORD_DEMO andCallBack:^(BOOL success, id result) {
//        NSLog(@"loginProgressWithUserName %@",result);
//    }];
    sleep(1); // delay page splash 1s
    return YES;
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationWillEnterForegroundNotification object:nil];
}

#pragma mark - Khi nào người dùng mở lại ứng dụng thì lấy lại ID quảng cáo
- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:nil];
     [Util hideProgressFromAnyView];
}

#pragma mark - Inits

- (void)setDefaults
{
    //Hien thi thanh status bar màu trắng
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    //Khai bao lưu image caches
    [self makeCacheStores];
    
    //Tạo database & load dữ liệu từ server về
    [self createDatabase];
    
    //Tạo menu bên trái
//    [self createLeftMenu];
    
    [self getCommonConfig];
    
      [XMUICheckBox setImage:@"pill_checkbox_checked_28x28.png" andUncheckedImage:@"pill_checkbox_unchecked_28x28.png"];
    
}

#pragma mark -Create Database
- (void)createDatabase
{
    //Khoi tao Database
    [MagicalRecord setupCoreDataStackWithAutoMigratingSqliteStoreNamed:DATA_MODEL_STORE_NAME];
}

#pragma mark - Tạo menu bên trái
-(void)createLeftMenu{
    
//    LeftMenuViewController *leftMenu = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"LeftMenuViewController"];
//    
//    [SlideNavigationController sharedInstance].leftMenu = leftMenu;
    
    //Config
    //[SlideNavigationController sharedInstance].enableSwipeGesture =YES;
    [SlideNavigationController sharedInstance].enableSwipeGesture =NO;
    [SlideNavigationController sharedInstance].portraitSlideOffset = MENU_SLIDE_OFFSET;
    
    //Kieu hien thi
    id <SlideNavigationContorllerAnimator> revealAnimator= [[SlideNavigationContorllerAnimatorFade alloc] init];
    [[SlideNavigationController sharedInstance] closeMenuWithCompletion:^{
        [SlideNavigationController sharedInstance].menuRevealAnimator = revealAnimator;
    }];
    
}
#pragma mark - thông tin chung của app
-(void)getCommonConfig{
    [[LibraryAPI shareInstance] getCommonConfig:^(BOOL success, id result) {
        //[SVCCommonConfig initWithDictionaryFormat:result];
        if (success) {
            SVCCommonConfig *commonConfig = [[SVCCommonConfig MR_findAll] lastObject];
            if (commonConfig && commonConfig.paypalApplicationId) {
                
                if([commonConfig.paypalType isEqualToString:@"sandbox"]){
                    [PayPal initializeWithAppID:@"APP-80W284485P519543T" forEnvironment:ENV_SANDBOX];
                    
                    NSLog(@"PayPal is running on mode SANBOX");
                    
                }else{
                    [PayPal initializeWithAppID:commonConfig.paypalApplicationId forEnvironment:ENV_LIVE];
                     NSLog(@"PayPal is running on mode LIVE");
                }
                
            }
        }
        
    }];
    
    //    [[Global getGlobal] downloadCategory];
}


#pragma mark - Tạo thư mục mặc định lưu trữ ảnh, audio, document
- (void)makeCacheStores
{
    NSFileManager *fileManager =[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:IMAGES_CACHE_PATH]) [fileManager createDirectoryAtPath:IMAGES_CACHE_PATH withIntermediateDirectories:YES attributes:nil error:nil];
    
    if(![fileManager fileExistsAtPath:AUDIOS_CACHE_PATH]) [fileManager createDirectoryAtPath:AUDIOS_CACHE_PATH withIntermediateDirectories:YES attributes:nil error:nil];
    
    if(![fileManager fileExistsAtPath:DOCUMENT_CACHE_PATH]) [fileManager createDirectoryAtPath:DOCUMENT_CACHE_PATH withIntermediateDirectories:YES attributes:nil error:nil];
    
}

- (void)removeCaches {
    NSFileManager *fileManager =[NSFileManager defaultManager];
    
    if([fileManager fileExistsAtPath:IMAGES_CACHE_PATH])   [fileManager removeItemAtPath:IMAGES_CACHE_PATH error:nil];
    if([fileManager fileExistsAtPath:AUDIOS_CACHE_PATH])   [fileManager removeItemAtPath:AUDIOS_CACHE_PATH error:nil];
    if([fileManager fileExistsAtPath:DOCUMENT_CACHE_PATH]) [fileManager removeItemAtPath:DOCUMENT_CACHE_PATH error:nil];
}

#pragma mark -
#pragma mark UI Methods

- (void)setRootViewController
{
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    self.homeViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"HomeViewController"];
   
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:self.homeViewController];
    
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];
    
}

- (void)goOutToLoginView {
    [SVCLogin truncateAll];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];

    NSArray *childViewControllers = self.navigationController.childViewControllers;
    for (UIViewController *vc in childViewControllers) {
        if ([vc isKindOfClass:[LoginVC class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}
@end

