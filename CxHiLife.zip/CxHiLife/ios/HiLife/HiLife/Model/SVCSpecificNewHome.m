//
//  SVCSpecificNewHome.m
//  HiLife
//
//  Created by CMC on 3/30/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificNewHome.h"


@implementation SVCSpecificNewHome

@dynamic create_by;
@dynamic create_time;
@dynamic descriptions;
@dynamic id;
@dynamic image;
@dynamic name;
@dynamic package_id;
@dynamic price;
@dynamic price_m2;
@dynamic size;
@dynamic update_by;
@dynamic update_time;
@dynamic valid;
@dynamic currency;
@dynamic room_type;

@end
