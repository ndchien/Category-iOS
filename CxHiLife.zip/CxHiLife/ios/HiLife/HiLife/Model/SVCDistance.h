//
//  SVCDistance.h
//  HiLife
//
//  Created by CMC iOS Dev on 09/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCDistance : NSManagedObject

@property (nonatomic, retain) NSString * filter_id;
@property (nonatomic, retain) NSString * filter_name;
@property (nonatomic, retain) NSString * filter_type;
@end
