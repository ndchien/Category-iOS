//
//  SVCPocket.h
//  HiLife
//
//  Created by S0nK3o on 4/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCPocket : NSManagedObject
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * banner;
@property (nonatomic, retain) NSString * dealName;
@property (nonatomic, retain) NSString * dealId;
@property (nonatomic, retain) NSString * dealHicredit;
@property (nonatomic, retain) NSString * storeName;
@property (nonatomic, retain) NSString * expiryDate;
@property (nonatomic, retain) NSString * price;
@property (nonatomic, retain) NSString * discount;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSString * expiry_date_string;
@property (nonatomic, retain) NSString * descriptionDeal;
@property (nonatomic, retain) NSString * deal_redeem_code;
@property (nonatomic, retain) NSString * deal_dialog_title;

@end
