//
//  SVCGetCustomize.m
//  HiLife
//
//  Created by Tran Ba Dang on 4/23/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCGetCustomize.h"

@implementation SVCGetCustomize
@synthesize id;
@synthesize name;
@synthesize arrRoom;
@end
