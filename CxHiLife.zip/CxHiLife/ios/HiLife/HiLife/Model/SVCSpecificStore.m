//
//  SVCSpecificStore.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificStore.h"


@implementation SVCSpecificStore

@dynamic id;
@dynamic category_id;
@dynamic user_id;
@dynamic name;
@dynamic descriptions;
@dynamic contact_number;
@dynamic address;
@dynamic image;
@dynamic hlong;
@dynamic hlat;
@dynamic show_home;
@dynamic publish;
@dynamic update_time;
@dynamic update_by;
@dynamic create_by;
@dynamic create_time;
@dynamic valid;
@dynamic category_name;

@synthesize openHours;
@synthesize strHours;
@synthesize listWorking;
@synthesize gallery;
@end
