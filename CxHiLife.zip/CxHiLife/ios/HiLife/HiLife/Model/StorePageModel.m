//
//  StorePageModel.m
//  HiLife
//
//  Created by CMC iOS Dev on 16/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "StorePageModel.h"

@implementation StorePageModel
@synthesize storeId;
@synthesize storeName;
@synthesize storeContactNumber;
@end
