//
//  NewsCategory.h
//  HiLife
//
//  Created by mac on 3/11/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface NewsCategory : NSManagedObject

@property (nonatomic, retain) NSString * active;
@property (nonatomic, retain) NSString * cat_id;
@property (nonatomic, retain) NSString * cate_type;
@property (nonatomic, retain) NSString * icon_text;
@property (nonatomic, retain) NSNumber * index;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * page_index;
@property (nonatomic, retain) NSNumber * selected;
@property (nonatomic, retain) NSNumber * show;
@property (nonatomic, retain) NSString * url;

@end
