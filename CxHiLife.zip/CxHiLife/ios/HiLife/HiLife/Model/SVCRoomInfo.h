//
//  SVCRoomInfo.h
//  HiLife
//
//  Created by CMC on 4/1/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCRoomInfo : NSObject
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * package_id;
@property (nonatomic, retain) NSString * price;
@property (nonatomic, retain) NSString * price_m2;
@property (nonatomic, retain) NSString * size;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * currency;
@property (nonatomic, retain) NSString * room_type;
@property (nonatomic, retain) NSString * floorplan;
@property (nonatomic, retain) NSString * raw_design;
@property (nonatomic, retain) NSString * renovated;
@property (nonatomic, retain) NSArray  * room_items;
@property (nonatomic, retain) NSArray  * arrGallery;
@end
