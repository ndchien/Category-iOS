//
//  SVCInbox.m
//  HiLife
//
//  Created by CMC iOS Dev on 06/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCInbox.h"


@implementation SVCInbox

@dynamic bBookmark;
@dynamic bDelete;
@dynamic content;
@dynamic create_by;
@dynamic create_time;
@dynamic from;
@dynamic id;
@dynamic member_id;
@dynamic title;
@dynamic update_by;
@dynamic update_time;
@dynamic user_id;
@dynamic valid;
@dynamic isRead;
@dynamic full_name;

@end
