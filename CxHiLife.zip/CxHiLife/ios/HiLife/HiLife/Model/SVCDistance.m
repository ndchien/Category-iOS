//
//  SVCDistance.m
//  HiLife
//
//  Created by CMC iOS Dev on 09/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCDistance.h"


@implementation SVCDistance

@dynamic filter_id;
@dynamic filter_name;
@dynamic filter_type;
@end
