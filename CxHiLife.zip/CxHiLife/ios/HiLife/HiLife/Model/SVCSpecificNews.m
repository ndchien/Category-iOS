//
//  SVCSpecificNews.m
//  HiLife
//
//  Created by Thong Do Minh on 3/25/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificNews.h"


@implementation SVCSpecificNews

@dynamic id;
@dynamic name;
@dynamic category_id;
@dynamic publish_date;
@dynamic image;
@dynamic descriptions;
@dynamic content_image;
@dynamic html;

@end
