//
//  SVCHomePackage.m
//  HiLife
//
//  Created by CMC on 3/30/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCHomePackage.h"


@implementation SVCHomePackage

@dynamic create_by;
@dynamic create_time;
@dynamic descriptions;
@dynamic id;
@dynamic image;
@dynamic name;
@dynamic package_type_id;
@dynamic price_m2;
@dynamic price_m2_view;
@dynamic publish;
@dynamic show_home;
@dynamic title;
@dynamic total_price;
@dynamic total_size;
@dynamic update_by;
@dynamic update_time;
@dynamic user_id;
@dynamic valid;
@dynamic currency;
@dynamic package_type_name;
@dynamic is_customize;
@end
