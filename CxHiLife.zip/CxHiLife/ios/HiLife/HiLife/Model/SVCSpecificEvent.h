//
//  SVCSpecifyEvent.h
//  HiLife
//
//  Created by Chung BD on 3/24/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCSpecificEvent : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * category_id;
@property (nonatomic, retain) NSString * start_date;
@property (nonatomic, retain) NSString * end_date;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * video;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * show_home;
@property (nonatomic, retain) NSString * publish;
@property (nonatomic, retain) NSString * form_id;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * category_name;
@property (nonatomic, retain) NSString * form_name;

+(instancetype)initWithDictionary:(NSDictionary*)dic;
@end
