//
//  SVCCommonConfig.h
//  HiLife
//
//  Created by S0nK3o on 4/10/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCCommonConfig : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (strong, nonatomic) NSString *companyName;
@property (strong, nonatomic) NSString *companyAddress;
@property (strong, nonatomic) NSString *companyMobile;
@property (strong, nonatomic) NSString *companyWeb;
@property (strong, nonatomic) NSString *companyOpening;
@property (strong, nonatomic) NSString *companyEmail;
@property (strong, nonatomic) NSString *companyWechat;

@property (strong, nonatomic) NSString *confVideo;
@property (strong, nonatomic) NSString *paypalApplicationId;
@property (strong, nonatomic) NSString *paypalRecipient;
@property (strong, nonatomic) NSString *paypalCurrency;
@property (strong, nonatomic) NSString *paypalMerchantName;

@property (strong, nonatomic) NSString *paypalType;

@end
