//
//  UserDataManager.m
//  ZindioApp
//
//  Created by CMCer on 1/8/15.
//  Copyright (c) 2015 DungIOS. All rights reserved.
//

#import "UserDataManager.h"
#define kEmailOrPhoneNumber @"EmailOrPhoneNumber"


@implementation UserDataManager

-(instancetype)init{
    self = [super init];
    if (self) {
        _userDefault = [NSUserDefaults standardUserDefaults];
        
    }
    return self;
}

+ (UserDataManager *)shareInstance{
    static UserDataManager* shareInstance = nil;
    
    static dispatch_once_t onPredicate;
    
    dispatch_once(&onPredicate, ^{
        shareInstance = [[UserDataManager alloc] init];
    });
    
    return shareInstance;
}

- (void)saveEmailAndPhoneNumber:(NSString*)info {
    [_userDefault setObject:info forKey:kEmailOrPhoneNumber];
}

- (NSString*)getEmailAndPhoneNumber {
    NSString *output = [_userDefault objectForKey:kEmailOrPhoneNumber];
    return output;
}

- (void) setISOCountryCode:(NSString*)code {
    [_userDefault setObject:code forKey:kISOCountryCode];
}

- (NSString*) getISOCountryCode {
    return [_userDefault objectForKey:kISOCountryCode];
}

- (void)whenUserJustEnterSaveContactNumber:(NSString *)contactNumber {
    return [_userDefault setObject:contactNumber forKey:kJustEnteredContactNumber];
}

- (NSString *)getJustEnterSaveContactNumber {
    return [_userDefault objectForKey:kJustEnteredContactNumber];
}
@end
