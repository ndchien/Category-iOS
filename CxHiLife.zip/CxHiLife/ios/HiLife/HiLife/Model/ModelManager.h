//
//  ModelManager.h
//  SHSSC
//
//  Created by C4-Mac Mini on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommonModel.h"
#import "SVCSpecificNews.h"

@interface ModelManager : NSObject

@property(retain,readonly) SVCLogin *login;
@property(retain,readonly) SVCVerification *verification;
@property(retain,readonly) SVCCommonConfig *config;

- (NSArray*)getPropertiesLiveFromResponse:(id)response;
- (void)getCommonConfigFromResponse:(NSDictionary*)dic;
- (void)getLoginInfoFromResponse:(NSDictionary*)dic;
- (SVCLogin *)getUserInfoFromDictionary:(NSDictionary*)result;
- (void)getVerificationInfoFromResponse:(NSDictionary*)response;

- (NSArray*)getEventsFromResponse:(NSArray*)dic;
-(NSDictionary*)getSpecifyEventFromResponse:(NSDictionary*)dic;
- (SVCAboutObj *)getAboutUSWithData:(id)data;
- (NSMutableArray *)getListStoreFormService:(id)result;
- (SVCSpecificStore *)getStoreDetailWithResult:(id)result;
- (NSMutableArray *)getListInboxFormService:(id)result;
- (void)getListQuestionFeedbackWithData:(id)service;
- (void)saveListCompanyWithData:(id)service;
- (void)saveListDistanceWithData:(id)data andType:(NSString *)type;
- (void)saveListCategoryWithData:(id)service;
- (void)saveListRaceWithData:(id)data;
- (void)saveListAllPropertyLiveWithData:(id)data;
- (NSMutableArray *)getListDealsWithResult:(id)result;
- (SVCSpecificNews *)getQQNewsDetailWithData:(id)data;
- (void)setTokenUser:(NSString *)token;
@end

