//
//  SVCSpecificActivities.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificActivities.h"


@implementation SVCSpecificActivities

@dynamic id;
@dynamic name;
@dynamic category_id;
@dynamic date;
@dynamic image;
@dynamic descriptions;
@dynamic video;
@dynamic user_id;
@dynamic create_by;
@dynamic create_time;
@dynamic valid;
@dynamic update_by;
@dynamic update_time;
@dynamic show_home;
@dynamic publish;
@dynamic category_name;

@end
