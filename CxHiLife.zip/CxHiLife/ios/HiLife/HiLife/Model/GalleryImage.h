//
//  GalleryImage.h
//  HiLife
//
//  Created by CMC on 4/6/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GalleryImage : NSObject
@property (nonatomic, strong) NSString *desc;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *price;
@property (strong, nonatomic) NSString *pricespf;
@property (nonatomic, strong) NSString *size;
@property (nonatomic, strong) NSString *currency;
@property (nonatomic, strong) NSString *floorPlan;
@property (nonatomic, strong) NSString *basic;
@property (nonatomic, strong) NSString *renovated;
@end
