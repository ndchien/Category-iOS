//
//  SVCGetCategories.h
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCGetCategories : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * code;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * valid;

@end
