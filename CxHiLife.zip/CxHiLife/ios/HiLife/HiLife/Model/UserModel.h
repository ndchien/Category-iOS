//
//  UserModel.h
//  SHSSC
//
//  Created by RibboN Dinh on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "JSONModel.h"

@interface UserModel : JSONModel

@property (strong, nonatomic) NSString* server_id;
@property (strong, nonatomic) NSString* full_name;
@property (strong, nonatomic) NSString* email;
@property (strong, nonatomic) NSString* address;
@property (strong, nonatomic) NSString* contact_number;
@property (strong, nonatomic) NSString* gender;
@property (strong, nonatomic) NSString* nric_passport;
@property (strong, nonatomic) NSString* salt;
@property (strong, nonatomic) NSString* national_id;
@property (strong, nonatomic) NSString* dob;
@property (strong, nonatomic) NSString* photo;
@property (strong, nonatomic) NSString* note;
@property (strong, nonatomic) NSString* os_type;
@property (strong, nonatomic) NSString* machine_code;
@property (strong, nonatomic) NSString* user_token;

+(instancetype) initWithDictionary:(NSDictionary*)dic;
@end
