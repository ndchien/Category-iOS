//
//  SVCSpecificDeals.m
//  HiLife
//
//  Created by CMC on 4/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificDeals.h"


@implementation SVCSpecificDeals

@dynamic id;
@dynamic name;
@dynamic descriptions;
@dynamic category_id;
@dynamic banner;
@dynamic image;
@dynamic store_id;
@dynamic quantity;
@dynamic hicredit;
@dynamic price;
@dynamic currency;
@dynamic discount;
@dynamic expiry_date;
@dynamic show_home;
@dynamic publish;
@dynamic valid;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic category_name;
@dynamic store_name;
@dynamic final_price;
@end
