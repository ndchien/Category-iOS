//
//  SVCDeals.h
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCDeals : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * category_id;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * banner;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * store_id;
@property (nonatomic, retain) NSString * price;
@property (nonatomic, retain) NSString * discount;
@property (nonatomic, retain) NSString * expiry_date;
@property (nonatomic, retain) NSString * show_home;
@property (nonatomic, retain) NSString * publish;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * final_price;
@end
