//
//  SVCWorkingHour.m
//  HiLife
//
//  Created by CMC iOS Dev on 08/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCWorkingHour.h"


@implementation SVCWorkingHour

@dynamic code;
@dynamic create_by;
@dynamic create_time;
@dynamic from;
@dynamic to;
@dynamic id;
@dynamic store_id;
@dynamic update_by;
@dynamic update_time;
@dynamic valid;
@synthesize day;

@end
