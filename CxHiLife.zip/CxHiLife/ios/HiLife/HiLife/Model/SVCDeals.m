//
//  SVCDeals.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCDeals.h"


@implementation SVCDeals

@dynamic id;
@dynamic name;
@dynamic category_id;
@dynamic user_id;
@dynamic banner;
@dynamic image;
@dynamic store_id;
@dynamic price;
@dynamic discount;
@dynamic expiry_date;
@dynamic show_home;
@dynamic publish;
@dynamic valid;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic final_price;
@end
