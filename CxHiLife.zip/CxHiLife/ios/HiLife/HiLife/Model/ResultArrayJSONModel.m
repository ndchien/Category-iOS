//
//  LoginJSONModel.m
//  SHSSC
//
//  Created by RibboN Dinh on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "ResultArrayJSONModel.h"

@implementation ResultArrayJSONModel

@synthesize ok;
@synthesize message;
@synthesize error;
@synthesize result;

+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    if ([propertyName isEqualToString: @"ok"]) return YES;
    return NO;
}

@end
