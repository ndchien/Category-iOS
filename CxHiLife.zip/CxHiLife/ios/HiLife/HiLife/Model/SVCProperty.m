//
//  SVCProperty.m
//  HiLife
//
//  Created by C4-Mac Mini on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCProperty.h"
#import "Util.h"

@implementation SVCProperty
@synthesize  id;
@synthesize  name;
@synthesize  sub_title;
@synthesize  type;
@synthesize  link;
@synthesize  image;
@synthesize  number_of_unit;
@synthesize  unit_type;
@synthesize  contact_number;
@synthesize  contact_email;
@synthesize  sold_date;
@synthesize  show_home;
@synthesize  publish;
@synthesize  create_time;
@synthesize  create_by;
@synthesize  update_time;
@synthesize  update_by;
@synthesize  valid;

+(instancetype)initWithDictionary:(NSDictionary *)dic{
    SVCProperty *property = [SVCProperty MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:property];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return property;
}

+(NSArray*)initWithArray:(NSArray*)array{
//    [SVCProperty truncateAll];
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCProperty initWithDictionary:dic]];
    }
//    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];    
    return result;
}

@end
