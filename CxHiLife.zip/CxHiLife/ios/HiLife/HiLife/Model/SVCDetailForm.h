//
//  SVCDetailForm.h
//  HiLife
//
//  Created by C4-Mac Mini on 4/9/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCDetailForm : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * form_id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * label;
@property (nonatomic, retain) NSString * default_value;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * update_by;

@end
