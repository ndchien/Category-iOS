//
//  SVCGetCustomize.h
//  HiLife
//
//  Created by Tran Ba Dang on 4/23/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCGetCustomize : NSObject
@property (nonatomic, strong) NSString *id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSArray  *arrRoom;
@end
