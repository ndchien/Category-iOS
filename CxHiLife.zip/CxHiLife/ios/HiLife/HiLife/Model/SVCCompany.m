//
//  SVCCompany.m
//  HiLife
//
//  Created by CMC iOS Dev on 25/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCCompany.h"


@implementation SVCCompany

@dynamic id;
@dynamic name;
@dynamic email;
@dynamic wechat;
@dynamic mobile;
@dynamic opening_hours;
@dynamic create_by;
@dynamic create_time;
@dynamic up_by;
@dynamic up_time;
@dynamic valid;
@dynamic address;
@dynamic web;
@dynamic conf_video;
@end
