//
//  SVCVerification.m
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCVerification.h"
#import "Util.h"

@implementation SVCVerification

@dynamic first_name;
@dynamic id;
@dynamic last_name;
@dynamic email;
@dynamic contact;
@dynamic property_id;
@dynamic password;
@dynamic unit;
@dynamic type;
@dynamic sex;
@dynamic marital_status;
@dynamic birth;
@dynamic role_id;
@dynamic user_id;
@dynamic verification_code;
@dynamic pets;
@dynamic cars;
@dynamic language;
@dynamic force_password_reset;
@dynamic timezone;
@dynamic token;
@dynamic valid;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;

+(instancetype)initWithDictionary:(NSDictionary *)dic{
    SVCVerification *verification =[[SVCVerification MR_findByAttribute:@"id" withValue:dic[@"id"]] firstObject];

    if(!verification){
        verification=[SVCVerification MR_createEntity];
    }
    [Util getInstanceFromServerSesponse:dic withInstance:verification];
    
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return verification;
}
@end
