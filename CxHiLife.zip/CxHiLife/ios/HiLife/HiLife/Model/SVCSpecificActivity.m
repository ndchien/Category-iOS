//
//  SVCSpecificActivity.m
//  HiLife
//
//  Created by CMC on 4/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificActivity.h"


@implementation SVCSpecificActivity

@synthesize id;
@synthesize name;
@synthesize category_id;
@synthesize start_date;
@synthesize end_date;
@synthesize image;
@synthesize descriptions;
@synthesize video;
@synthesize create_by;
@synthesize create_time;
@synthesize valid;
@synthesize update_by;
@synthesize update_time;
@synthesize show_home;
@synthesize publish;
@synthesize category_name;
@synthesize gallery_image;
@synthesize gallery_video;
@synthesize form_id;
@synthesize form_name;
@end
