//
//  SVCAboutObj.m
//  HiLife
//
//  Created by CMC iOS Dev on 09/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCAboutObj.h"

@implementation SVCAboutObj

@synthesize events_booked;
@synthesize deal_purchased;
@synthesize deal_saved;

@end

@implementation ItemObject

@synthesize type;
@synthesize title;
@synthesize urlImg;
@synthesize idObj;
@synthesize name;
@synthesize price;
@end