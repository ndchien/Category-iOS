//
//  SVCHomeService.m
//  HiLife
//
//  Created by CMC on 4/2/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCHomeService.h"


@implementation SVCHomeService

@dynamic service_name;
@dynamic service_id;
@dynamic id;
@dynamic category_id;
@dynamic name;
@dynamic descriptions;
@dynamic contact_number;
@dynamic address;
@dynamic image;
@dynamic longitude;
@dynamic latitude;
@dynamic show_home;
@dynamic publish;
@dynamic update_time;
@dynamic update_by;
@dynamic create_by;
@dynamic create_time;
@dynamic valid;
@dynamic category_name;
@dynamic distance;
@dynamic store_id;

@end
