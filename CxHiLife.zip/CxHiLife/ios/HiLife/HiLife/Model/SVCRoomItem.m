//
//  SVCRoomItem.m
//  HiLife
//
//  Created by CMC on 4/1/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCRoomItem.h"


@implementation SVCRoomItem

@synthesize id;
@synthesize create_by;
@synthesize create_time;
@synthesize name;
@synthesize room_id;
@synthesize update_by;
@synthesize update_time;
@synthesize valid;

@end
