//
//  SVCAboutObj.h
//  HiLife
//
//  Created by CMC iOS Dev on 09/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCAboutObj : NSObject

@property (strong, nonatomic) NSMutableArray   * events_booked;
@property (strong, nonatomic) NSMutableArray   * deal_purchased;

@property (strong, nonatomic) NSMutableArray   * deal_saved;


@end


@interface ItemObject : NSObject

@property (strong, nonatomic) NSString *idObj;
@property (strong, nonatomic) NSString *type;
@property (strong, nonatomic) NSString *title;
@property (strong, nonatomic) NSString *urlImg;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *price;
@end