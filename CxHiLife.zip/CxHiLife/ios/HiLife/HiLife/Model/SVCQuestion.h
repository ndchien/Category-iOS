//
//  SVCQuestion.h
//  HiLife
//
//  Created by CMC iOS Dev on 25/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCQuestion : NSManagedObject

@property (nonatomic, retain) NSString * question_id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * up_by;
@property (nonatomic, retain) NSString * up_time;
@property (nonatomic, retain) NSString * valid;

@end
