//
//  SVCPackageCredit.m
//  HiLife
//
//  Created by S0nK3o on 4/6/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCPackageCredit.h"

@implementation SVCPackageCredit

@dynamic id;
@dynamic name;
@dynamic credit;
@dynamic price;
@dynamic image;

@end
