//
//  SVCHomeContentTop.m
//  HiLife
//
//  Created by CMC on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCHomeContentTop.h"


@implementation SVCHomeContentTop

@dynamic id;
@dynamic name;
@dynamic category_id;
@dynamic user_id;
@dynamic publish_date;
@dynamic image;
@dynamic descriptions;
@dynamic content_image;
@dynamic content_video;
@dynamic html;
@dynamic show_home;
@dynamic publish;
@dynamic valid;
@dynamic create_time;
@dynamic create_by;
@dynamic update_by;
@dynamic update_time;
@dynamic index;

@end
