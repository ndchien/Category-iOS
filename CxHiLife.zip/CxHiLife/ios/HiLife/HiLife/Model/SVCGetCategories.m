//
//  SVCGetCategories.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCGetCategories.h"


@implementation SVCGetCategories

@dynamic id;
@dynamic name;
@dynamic descriptions;
@dynamic code;
@dynamic type;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic valid;

@end
