//
//  NSManagedObject+InitialAndParseFromResponse.h
//  HiLife
//
//  Created by C4-Mac Mini on 4/9/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>
#import "Util.h"
@interface NSManagedObject (InitialAndParseFromResponse)
+(instancetype)initWithDictionaryFormat:(NSDictionary*)dic;
+(NSArray*)initArrayWithData:(NSArray*)array;
@end
