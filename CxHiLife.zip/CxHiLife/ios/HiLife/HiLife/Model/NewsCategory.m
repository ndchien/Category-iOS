//
//  NewsCategory.m
//  HiLife
//
//  Created by mac on 3/11/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "NewsCategory.h"


@implementation NewsCategory

@dynamic active;
@dynamic cat_id;
@dynamic cate_type;
@dynamic icon_text;
@dynamic index;
@dynamic name;
@dynamic page_index;
@dynamic selected;
@dynamic show;
@dynamic url;

@end
