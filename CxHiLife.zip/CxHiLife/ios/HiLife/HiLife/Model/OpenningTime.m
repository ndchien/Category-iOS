//
//  OpenningTime.m
//  HiLife
//
//  Created by CMC on 4/2/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "OpenningTime.h"

@implementation OpenningTime
@synthesize id;
@synthesize store_id;
@synthesize code;
@synthesize from;
@synthesize to;
@synthesize create_time;
@synthesize create_by;
@synthesize update_time;
@synthesize update_by;
@synthesize valid;
@end
