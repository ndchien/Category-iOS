//
//  SVCGetPropertiesLive.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCGetPropertiesLive.h"
#import "Util.h"

@implementation SVCGetPropertiesLive

@dynamic id;
@dynamic name;
@dynamic descriptions;
@dynamic unit;
@dynamic type;
@dynamic address;
@dynamic longitude;
@dynamic latitude;
@dynamic valid;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;


+(instancetype)initWithDictionary:(NSDictionary*)dic{
    SVCGetPropertiesLive *event = [SVCGetPropertiesLive MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:event];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];    
    return event;
}

+(NSArray*)initWithArray:(NSArray*)array{
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCGetPropertiesLive initWithDictionary:dic]];
    }
    return [result copy];
}



@end
