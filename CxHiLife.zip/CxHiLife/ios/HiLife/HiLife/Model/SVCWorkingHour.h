//
//  SVCWorkingHour.h
//  HiLife
//
//  Created by CMC iOS Dev on 08/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCWorkingHour : NSManagedObject

@property (nonatomic, retain) NSString * code;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * from;
@property (nonatomic, retain) NSString * to;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * store_id;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * day;

@end
