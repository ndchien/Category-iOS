//
//  LoginJSONModel.h
//  SHSSC
//
//  Created by RibboN Dinh on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "JSONModel.h"

@interface ResultArrayJSONModel : JSONModel

@property (assign, nonatomic) BOOL ok;
@property (strong, nonatomic) NSString* message;
@property (strong, nonatomic) NSString* error;
@property (strong, nonatomic) NSDictionary* result;

@end
