//
//  SVCGalleryVideo.m
//  HiLife
//
//  Created by C4-Mac Mini on 3/30/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCGalleryVideo.h"

@implementation SVCGalleryVideo
@synthesize video;
@synthesize descriptions;
@synthesize thumb_video;

+(instancetype)initWithDictionary:(NSDictionary *)dic{
    SVCGalleryVideo *property = [SVCGalleryVideo MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:property];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return property;
}

+(NSArray*)initWithArray:(NSArray*)array{
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCGalleryVideo initWithDictionary:dic]];
    }
    return result;
}
@end
