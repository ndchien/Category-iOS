//
//  SVCFacilities.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCFacilities.h"
#import "Util.h"

@implementation SVCFacilities

@dynamic id;
@dynamic url;
@dynamic descriptions;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic valid;
@dynamic user_id;

+(instancetype)initWithDictionary:(NSDictionary*)dic{
    SVCFacilities *facility = [SVCFacilities MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:facility];
    return facility;
}

//+(NSArray*)initWithArray:(NSArray*)array{
////    [SVCFacilities truncateAll];
//    
//    NSMutableArray *result = [NSMutableArray new];
//    for (NSDictionary *dic in array) {
//        [result addObject:];
//    }
////    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
//    return result;
//}
@end
