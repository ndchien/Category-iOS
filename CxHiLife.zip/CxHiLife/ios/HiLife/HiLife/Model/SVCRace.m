//
//  SVCRace.m
//  HiLife
//
//  Created by CMC iOS Dev on 06/04/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCRace.h"


@implementation SVCRace

@dynamic id;
@dynamic name;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic valid;

@end
