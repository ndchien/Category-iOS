//
//  SVCLogin.h
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCLogin : NSManagedObject

@property (nonatomic, retain) NSString * birth;
@property (nonatomic, retain) NSString * cars;
@property (nonatomic, retain) NSString * contact;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * first_name;
@property (nonatomic, retain) NSString * force_password_reset;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * language;
@property (nonatomic, retain) NSString * last_name;
@property (nonatomic, retain) NSString * race_id;
@property (nonatomic, retain) NSString *race_name;
@property (nonatomic, retain) NSString * marital_status;
@property (nonatomic, retain) NSString * password;
@property (nonatomic, retain) NSString * pets;
@property (nonatomic, retain) NSString *property_name;
@property (nonatomic, retain) NSString * property_id;
@property (nonatomic, retain) NSString * old_properties_live_id;
@property (nonatomic, retain) NSString * confirm_change_live;
@property (nonatomic, retain) NSString * role_id;
@property (nonatomic, retain) NSString * owner_pending;
@property (nonatomic, retain) NSString * sex;
@property (nonatomic, retain) NSString * timezone;
@property (nonatomic, retain) NSString * token;
@property (nonatomic, retain) NSString * token_expites;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * unit;
@property (nonatomic, retain) NSString * unit_no;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * verification_code;
@property (nonatomic, retain) NSString * credit;

@property (nonatomic, retain) NSString * other_property_id;
@property (nonatomic, retain) NSMutableArray *otherProperties;
@property (nonatomic, retain) NSMutableArray *dependents;

- (id)mutableCopyWithZone:(NSZone *)zone;
@end

@interface OtherProperties : NSObject
@property (nonatomic, retain) NSString * properties_id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * unit;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * longitude;
@property (nonatomic, retain) NSString * latitude;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
+(instancetype) initWithDictionary:(NSDictionary*)dic;
- (NSMutableDictionary*)toDictionary;
@end

@interface DependentObject : NSObject
@property (nonatomic, retain) NSString * dependent_id;
@property (nonatomic, retain) NSString * first_name;
@property (nonatomic, retain) NSString * last_name;
@property (nonatomic, retain) NSString * age;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
+(instancetype) initWithDictionary:(NSDictionary*)dic;
- (NSMutableDictionary*)toDictionary;
@end
