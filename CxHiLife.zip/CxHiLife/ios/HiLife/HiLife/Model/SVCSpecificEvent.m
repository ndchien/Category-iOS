//
//  SVCSpecifyEvent.m
//  HiLife
//
//  Created by Chung BD on 3/24/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "Util.h"
#import "CommonModel.h"

@implementation SVCSpecificEvent
@synthesize id;
@synthesize name;
@synthesize title;
@synthesize category_id;
@synthesize start_date;
@synthesize end_date;
@synthesize image;
@synthesize video;
@synthesize descriptions;
@synthesize show_home;
@synthesize publish;
@synthesize form_id;
@synthesize create_time;
@synthesize create_by;
@synthesize update_time;
@synthesize update_by;
@synthesize valid;
@synthesize category_name;
@synthesize form_name;

+(instancetype)initWithDictionary:(NSDictionary*)dic
{
    SVCSpecificEvent *event = [SVCSpecificEvent MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:event];
        
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return event;
}

@end
