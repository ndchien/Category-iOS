//
//  SVCSpecificNewHome.h
//  HiLife
//
//  Created by CMC on 3/30/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCSpecificNewHome : NSManagedObject

@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * package_id;
@property (nonatomic, retain) NSString * price;
@property (nonatomic, retain) NSString * price_m2;
@property (nonatomic, retain) NSString * size;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * currency;
@property (nonatomic, retain) NSString * room_type;

@end
