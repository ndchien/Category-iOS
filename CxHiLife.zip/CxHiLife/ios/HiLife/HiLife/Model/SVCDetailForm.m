//
//  SVCDetailForm.m
//  HiLife
//
//  Created by C4-Mac Mini on 4/9/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCDetailForm.h"


@implementation SVCDetailForm

@dynamic id;
@dynamic form_id;
@dynamic name;
@dynamic type;
@dynamic label;
@dynamic default_value;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic valid;
@dynamic update_by;

@end
