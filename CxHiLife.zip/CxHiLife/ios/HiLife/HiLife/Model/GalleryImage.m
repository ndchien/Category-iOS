//
//  GalleryImage.m
//  HiLife
//
//  Created by CMC on 4/6/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "GalleryImage.h"

@implementation GalleryImage
@synthesize desc;
@synthesize image;
@synthesize pricespf;
@synthesize price;
@synthesize size;
@synthesize currency;
@synthesize floorPlan;
@synthesize basic;
@synthesize renovated;
@end
