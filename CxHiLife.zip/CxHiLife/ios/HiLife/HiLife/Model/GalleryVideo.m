//
//  GalleryVideo.m
//  HiLife
//
//  Created by CMC on 4/6/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "GalleryVideo.h"

@implementation GalleryVideo
@synthesize desc;
@synthesize thumb_video;
@synthesize video;
@end
