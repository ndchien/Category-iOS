//
//  SVCPackageCredit.h
//  HiLife
//
//  Created by S0nK3o on 4/6/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCPackageCredit : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * credit;
@property (nonatomic, retain) NSString * price;
@property (nonatomic, retain) NSString * image;

@end
