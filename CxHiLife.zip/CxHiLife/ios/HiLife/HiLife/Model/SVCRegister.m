//
//  SVCRegister.m
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCRegister.h"


@implementation SVCRegister

@dynamic first_name;
@dynamic last_name;
@dynamic contact;
@dynamic property_id;
@dynamic email;
@dynamic password;
@dynamic unit;
@dynamic type;
@dynamic verification_code;
@dynamic token;
@dynamic create_time;
@dynamic update_time;
@dynamic timezone;

@end
