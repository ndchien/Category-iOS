//
//  SVCHomeEvents.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCHomeEvents.h"


@implementation SVCHomeEvents

@dynamic id;
@dynamic name;
@dynamic title;
@dynamic category_id;
@dynamic date;
@dynamic image;
@dynamic video;
@dynamic descriptions;
@dynamic show_home;
@dynamic publish;
@dynamic user_id;
@dynamic form_id;
@dynamic create_time;
@dynamic create_by;
@dynamic update_time;
@dynamic update_by;
@dynamic valid;
@dynamic start_date;
@dynamic end_date;

+(instancetype)initWithDictionary:(NSDictionary*)dic{
    SVCHomeEvents *event = [[SVCHomeEvents MR_findByAttribute:@"id" withValue:dic[@"id"]] firstObject];
    if (!event.id) {
        event = [SVCHomeEvents MR_createEntity];
    }
    [Util getInstanceFromServerSesponse:dic withInstance:event];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return event;
}

+(NSArray*)initWithArray:(NSArray*)array{
//    [SVCHomeEvents truncateAll];
    
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCHomeEvents initWithDictionary:dic]];
    }

    return result;
}
@end
