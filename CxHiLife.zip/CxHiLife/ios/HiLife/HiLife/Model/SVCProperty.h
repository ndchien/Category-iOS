//
//  SVCProperty.h
//  HiLife
//
//  Created by C4-Mac Mini on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCProperty : NSManagedObject
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * sub_title;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * link;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * number_of_unit;
@property (nonatomic, retain) NSString * unit_type;
@property (nonatomic, retain) NSString * contact_number;
@property (nonatomic, retain) NSString * contact_email;
@property (nonatomic, retain) NSString * sold_date;
@property (nonatomic, retain) NSString * show_home;
@property (nonatomic, retain) NSString * publish;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * valid;

+(instancetype)initWithDictionary:(NSDictionary*)dic;
+(NSArray*)initWithArray:(NSArray*)array;

@end
