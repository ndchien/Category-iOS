//
//  StorePageModel.h
//  HiLife
//
//  Created by CMC iOS Dev on 16/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorePageModel : NSObject
@property (nonatomic, strong) NSString *storeId;
@property (nonatomic, strong) NSString *storeName;
@property (nonatomic, strong) NSString *storeContactNumber;
@end
