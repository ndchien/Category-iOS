//
//  Deal.h
//  HiLife
//
//  Created by CMC on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Deal : NSManagedObject
@property (nonatomic, strong) NSString *dealid;
@property (nonatomic, strong) NSString *dealname;
@property (nonatomic, strong) NSString *dealcateid;
@property (nonatomic, strong) NSString *dealuserid;
@property (nonatomic, strong) NSString *dealbanner;
@property (nonatomic, strong) NSString *dealimage;
@property (nonatomic, strong) NSString *dealstoreid;
@property (nonatomic, strong) NSString *dealprice;
@property (nonatomic, strong) NSString *dealdiscount;
@property (nonatomic, strong) NSString *dealexpirydate;
@property (nonatomic, strong) NSString *dealshowhome;
@property (nonatomic, strong) NSString *dealpublish;
@property (nonatomic, strong) NSString *dealvalid;
@property (nonatomic, strong) NSString *dealcreatetime;
@property (nonatomic, strong) NSString *dealcreateby;
@property (nonatomic, strong) NSString *dealupdatetime;
@property (nonatomic, strong) NSString *dealupdateby;
@property (nonatomic, strong) NSString *dealcatename;
@property (nonatomic, strong) NSString *dealstorename;
@property (nonatomic, strong) NSString *dealdistance;
@end
