//
//  CommonModel.h
//  SHSSC
//
//  Created by RibboN Dinh on 3/5/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#ifndef CommonModel_h
#define CommonModel_h
#import "NSManagedObject+InitialAndParseFromResponse.h"
#import "SVCRegister.h"
#import "SVCLogin.h"
#import "SVCGetStore.h"
#import "SVCInbox.h"
#import "SVCGetStore.h"
#import "SVCHomeEvents.h"
#import "SVCSpecificEvent.h"
#import "SVCGetPropertiesLive.h"
#import "SVCVerification.h"
#import "SVCFacilities.h"
#import "SVCProperty.h"
#import "SVCPropertyItem.h"
#import "SVCPropertyItemDetail.h"
#import "SVCGalleryImage.h"
#import "SVCGalleryVideo.h"
#import "SVCTip.h"
#import "PageContentVC.h"
#import "SVCDetailForm.h"
#import "SVCSpecificStore.h"
#import "SVCWorkingHour.h"
#import "SVCDistance.h"
#import "SVCAboutObj.h"
#import "SVCCommonConfig.h"
#endif