//
//  SVCTip.m
//  HiLife
//
//  Created by C4-Mac Mini on 3/31/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCTip.h"

@implementation SVCTip
@synthesize id;
@synthesize category_id;
@synthesize name;
@synthesize banner;
@synthesize image;
@synthesize descriptions;
@synthesize html;
@synthesize show_home;
@synthesize publish;
@synthesize create_time;
@synthesize create_by;
@synthesize update_time;
@synthesize update_by;
@synthesize valid;
@synthesize category_name;

+(instancetype)initWithDictionary:(NSDictionary *)dic{
    SVCTip *tip = [[SVCTip MR_findByAttribute:@"id" withValue:dic[@"id"]] firstObject];
    if (!tip.id) {
        tip = [SVCTip MR_createEntity];
    }

    [Util getInstanceFromServerSesponse:dic withInstance:tip];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return tip;
}

+(NSArray*)initWithArray:(NSArray*)array{
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCTip initWithDictionary:dic]];
    }
    return result;
}

@end
