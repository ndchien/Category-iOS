//
//  SVCHomeContentBottom.h
//  HiLife
//
//  Created by CMC on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCHomeContentBottom : NSManagedObject

@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * category;

//Index dùng để hiển thị order by theo thứ tự server trả về
@property (nonatomic, retain) NSString * index;

@end
