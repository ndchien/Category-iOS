//
//  NSManagedObject+InitialAndParseFromResponse.m
//  HiLife
//
//  Created by C4-Mac Mini on 4/9/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "NSManagedObject+InitialAndParseFromResponse.h"

@implementation NSManagedObject (InitialAndParseFromResponse)
+(instancetype)initWithDictionaryFormat:(NSDictionary*)dic{
    id instance = [[self class] MR_createEntity] ;
    [Util getInstanceFromServerSesponse:dic withInstance:instance];
    return instance;
}

+(NSArray*)initArrayWithData:(NSArray*)array{
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[[self class] initWithDictionaryFormat:dic]];
    }
    
    return result;
}
@end
