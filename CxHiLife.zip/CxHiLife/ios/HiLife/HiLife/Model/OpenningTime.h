//
//  OpenningTime.h
//  HiLife
//
//  Created by CMC on 4/2/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OpenningTime : NSObject
@property (nonatomic, strong) NSString *id;
@property (nonatomic, strong) NSString *store_id;
@property (nonatomic, strong) NSString *code;
@property (nonatomic, strong) NSString *from;
@property (nonatomic, strong) NSString *to;
@property (nonatomic, strong) NSString *create_time;
@property (nonatomic, strong) NSString *create_by;
@property (nonatomic, strong) NSString *update_time;
@property (nonatomic, strong) NSString *update_by;
@property (nonatomic, strong) NSString *valid;
@end
