//
//  UserDataManager.h
//  ZindioApp
//
//  Created by CMCer on 1/8/15.
//  Copyright (c) 2015 DungIOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommonModel.h"
#import "UserModel.h"

@interface UserDataManager : NSObject
{
    NSUserDefaults *_userDefault;
}

+ (UserDataManager *)shareInstance;
- (void)saveEmailAndPhoneNumber:(NSString*)info;
- (NSString*)getEmailAndPhoneNumber;
- (void) setISOCountryCode:(NSString*)code;
- (NSString*) getISOCountryCode;
- (void)whenUserJustEnterSaveContactNumber:(NSString *)contactNumber;
- (NSString *)getJustEnterSaveContactNumber;
@end
