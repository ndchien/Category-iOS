//
//  SVCGalleryImage.h
//  HiLife
//
//  Created by C4-Mac Mini on 3/30/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCGalleryImage : NSManagedObject

@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * descriptions;

+(instancetype)initWithDictionary:(NSDictionary*)dic;
+(NSArray*)initWithArray:(NSArray*)array;

@end
