//
//  ModelManager.m
//  SHSSC
//
//  Created by C4-Mac Mini on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "ModelManager.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "SVCQuestion.h"
#import "SVCCompany.h"
#import "SVCGetCategories.h"
#import "SVCGetDeals.h"
#import "SVCRace.h"
#import "SVCGetDeals.h"
#import "SVCHomeEvents.h"
#import "SVCSpecificDeals.h"

@implementation ModelManager
-(instancetype)init{
    self = [super init];
    if (self) {
        SVCLogin *login =[[SVCLogin MR_findAll] firstObject];
        SVCVerification *verification = [[SVCVerification MR_findAll] firstObject];
        SVCCommonConfig *config = [[SVCCommonConfig MR_findAll] firstObject];
        _verification = verification;
        if (config) {
            _config = config;
        }
        if (login) {
            _login = login;
            NSLog(@"Existence Login token: %@",_login.token);
            NSLog(@"Existence Login");
        }
        else
            NSLog(@"Not Existence Login");
    }
    return self;
}

- (NSArray*)getPropertiesLiveFromResponse:(id)response{
    return [SVCGetPropertiesLive initWithArray:response];
}

-(void)getCommonConfigFromResponse:(NSDictionary *)dic {
    
    if (dic && (dic[@"paypal_currency"] && ![dic[@"paypal_currency"] isEqual:[NSNull null]])) {
        [SVCCommonConfig MR_truncateAll];
        SVCCommonConfig *config = [SVCCommonConfig MR_createEntity];
        
        config.id = [NSString stringWithFormat:@"%@", dic[@"id"]];
        config.companyName = [NSString stringWithFormat:@"%@",dic[@"company_name"]];
        config.companyAddress = [NSString stringWithFormat:@"%@",dic[@"company_address"]];
        config.companyMobile = [NSString stringWithFormat:@"%@",dic[@"company_mobile"]];
        config.companyWeb = [NSString stringWithFormat:@"%@",dic[@"company_web"]];
        config.companyOpening = [NSString stringWithFormat:@"%@",dic[@"company_opening"]];
        
        //chiennd
        config.confVideo = [Util getAbsoluteImageURLWith:dic[@"conf_video"]];
        //config.confVideo = [NSString stringWithFormat:@"%@",dic[@"conf_video"]];
        
        config.companyEmail = [NSString stringWithFormat:@"%@",dic[@"company_email"]];
        config.companyWechat = [NSString stringWithFormat:@"%@",dic[@"company_wechat"]];
        config.paypalApplicationId = [NSString stringWithFormat:@"%@",dic[@"paypal_application_id"]];
        config.paypalRecipient = [NSString stringWithFormat:@"%@",dic[@"paypal_recipient"]];
        config.paypalCurrency = [NSString stringWithFormat:@"%@",dic[@"paypal_currency"]];
        config.paypalType =[NSString stringWithFormat:@"%@",dic[@"paypal_type"]];
        
        
        _config = config;
        [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];

    }
}

- (void)getLoginInfoFromResponse:(NSDictionary*)result{
    
//    SVCLogin *login =[[SVCLogin MR_findByAttribute:@"user_id" withValue:result[@"id"]] firstObject];
//    
//    if(!login){
//        login=[SVCLogin MR_createEntity];
//    }
    //Chiennd :
    [SVCLogin MR_truncateAll]; // Xoa het du lieu cu de dam bao co duy nhat 1 ban ghi user
    
    SVCLogin *login =[SVCLogin MR_createEntity];
    
    login.user_id = [NSString stringWithFormat:@"%@", result[@"id"]];
    login.first_name = [NSString stringWithFormat:@"%@", result[@"first_name"]];
    login.last_name = [NSString stringWithFormat:@"%@", result[@"last_name"]];
    login.email = [NSString stringWithFormat:@"%@", result[@"email"]];
    login.password = [NSString stringWithFormat:@"%@", result[@"password"]];
    login.contact = [NSString stringWithFormat:@"%@", result[@"contact"]];
    login.property_id = [NSString stringWithFormat:@"%@", result[@"property_id"]];
    login.race_id = [NSString stringWithFormat:@"%@", result[@"race_id"]];
    login.unit = [NSString stringWithFormat:@"%@", result[@"unit"]];
    login.type = [NSString stringWithFormat:@"%@", result[@"type"]];
    login.sex = [NSString stringWithFormat:@"%@", result[@"sex"]];
    login.marital_status = [NSString stringWithFormat:@"%@", result[@"marital_status"]];
    login.birth = [NSString stringWithFormat:@"%@", result[@"birth"]];
    login.role_id = [NSString stringWithFormat:@"%@", result[@"role_id"]];
    login.verification_code = [NSString stringWithFormat:@"%@", result[@"verification_code"]];
    login.pets = [NSString stringWithFormat:@"%@", result[@"pets"]];
    login.cars = [NSString stringWithFormat:@"%@", result[@"cars"]];
    login.language = [NSString stringWithFormat:@"%@", result[@"language"]];
    login.timezone = [NSString stringWithFormat:@"%@", result[@"timezone"]];
    login.token = [NSString stringWithFormat:@"%@", result[@"token"]];
    login.owner_pending = [NSString stringWithFormat:@"%@", result[@"owner_pending"]];
    NSLog(@"Token login: %@",login.token);
    login.valid = [NSString stringWithFormat:@"%@", result[@"valid"]];
    login.create_time = [NSString stringWithFormat:@"%@", result[@"create_time"]];
    login.create_by = [NSString stringWithFormat:@"%@", result[@"create_by"]];
    login.update_time = [NSString stringWithFormat:@"%@", result[@"update_time"]];
    login.update_by = [NSString stringWithFormat:@"%@", result[@"update_by"]];
    login.credit = [NSString stringWithFormat:@"%@", result[@"credit"]];
    login.property_name = [NSString stringWithFormat:@"%@", result[@"properties_name"]];
    login.race_name     = [NSString stringWithFormat:@"%@", result[@"race_name"]];
    _login = login;
    [Global getGlobal].svcLogin = login;
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
}

- (SVCLogin *)getUserInfoFromDictionary:(NSDictionary*)result{

    SVCLogin *login = [SVCLogin MR_createEntity];
    
    login.user_id       = [NSString stringWithFormat:@"%@", result[@"id"]];
    login.first_name    = [NSString stringWithFormat:@"%@", result[@"first_name"]];
    login.last_name     = [NSString stringWithFormat:@"%@", result[@"last_name"]];
    login.email         = [NSString stringWithFormat:@"%@", result[@"email"]];
    
    
    login.contact       = [NSString stringWithFormat:@"%@", result[@"contact"]];
    login.property_id   = [NSString stringWithFormat:@"%@", result[@"property_id"]];
    login.old_properties_live_id   = [NSString stringWithFormat:@"%@", result[@"old_properties_live_id"]];
    login.confirm_change_live   = [NSString stringWithFormat:@"%@", result[@"confirm_change_live"]];
    login.property_name = [NSString stringWithFormat:@"%@", ![result[@"properties_name"] isEqual:[NSNull null]]?result[@"properties_name"]:@""];
    
    
    login.race_id       = [NSString stringWithFormat:@"%@", result[@"race_id"]];
    login.race_name     = [NSString stringWithFormat:@"%@", ![result[@"race_name"] isEqual:[NSNull null]]?result[@"race_name"]:@""];
    login.unit          = [NSString stringWithFormat:@"%@", result[@"unit"]];
    login.unit_no          = [NSString stringWithFormat:@"%@", result[@"unit_no"]];
    login.type          = [NSString stringWithFormat:@"%@", result[@"type"]];
    login.sex           = [NSString stringWithFormat:@"%@", result[@"sex"]];
    login.marital_status= [NSString stringWithFormat:@"%@", result[@"marital_status"]];
    login.birth         = [NSString stringWithFormat:@"%@", result[@"birth"]];
    login.role_id       = [NSString stringWithFormat:@"%@", result[@"role_id"]];
    login.owner_pending = [NSString stringWithFormat:@"%@", result[@"owner_pending"]];
    login.verification_code = [NSString stringWithFormat:@"%@", result[@"verification_code"]];
    login.pets          = [NSString stringWithFormat:@"%@", result[@"pets"]];
    login.cars          = [NSString stringWithFormat:@"%@", result[@"cars"]];
    login.language      = [NSString stringWithFormat:@"%@", result[@"language"]];
    login.timezone      = [NSString stringWithFormat:@"%@", result[@"timezone"]];
    //login.credit = dic[@"credit"];
    login.token         = [NSString stringWithFormat:@"%@", result[@"token"]];
//    login.token_expites = [NSString stringWithFormat:@"%@", result[@"token_expites"]];
    login.valid         = [NSString stringWithFormat:@"%@", result[@"valid"]];
    login.create_time   = [NSString stringWithFormat:@"%@", result[@"create_time"]];
    login.create_by     = [NSString stringWithFormat:@"%@", result[@"create_by"]];
    login.update_time   = [NSString stringWithFormat:@"%@", result[@"update_time"]];
    login.update_by     = [NSString stringWithFormat:@"%@", result[@"update_by"]];
    login.credit        = [NSString stringWithFormat:@"%@", result[@"credit"]];
    
    login.other_property_id = @"1";
    NSArray *arrOtherProperties = result[@"other_properties"];
    NSMutableArray *listProperties = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in arrOtherProperties) {
        [listProperties addObject:[OtherProperties initWithDictionary:dic]];
    }
    login.otherProperties = listProperties;
    
    
    NSArray *arrDependents = result[@"dependents"];
    NSMutableArray *listDependents = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in arrDependents) {
        [listDependents addObject:[DependentObject initWithDictionary:dic]];
    }
    login.dependents = listDependents;
    [Global getGlobal].svcLogin = login;
    
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return login;
}

- (void)setTokenUser:(NSString *)token{
    _login.token = token;
}

- (void)getVerificationInfoFromResponse:(NSDictionary*)dic{
    SVCVerification *verification = [SVCVerification initWithDictionary:dic];
    _verification = verification;
}

- (NSMutableArray *)getListStoreFormService:(id)result{
    if (![result isKindOfClass:[NSArray class]]){
        return nil;
    }
    NSArray *arrStore = result;
    NSMutableArray *arrResults = [NSMutableArray array];
//    [SVCGetStore MR_truncateAll];
    for (NSDictionary *dicTmp in arrStore) {
        SVCGetStore *store;// = [[SVCGetStore MR_findByAttribute:@"id" withValue:[dicTmp objectForKey:@"id"]] firstObject];
        if (store == nil) {
            store = [SVCGetStore MR_createEntity];
        }
        if (![dicTmp[@"id"] isEqual:[NSNull null]]){
            [store setId:dicTmp[@"id"]];
        }else{
            [store setId:@""];
        }
        if (![dicTmp[@"category_id"] isEqual:[NSNull null]]){
            store.category_id = dicTmp[@"category_id"];
        }else{
            store.category_id = @"";
        }
        if (![dicTmp[@"user_id"] isEqual:[NSNull null]]){
            store.user_id = dicTmp[@"user_id"];
        }else{
            store.user_id = @"";
        }
        if (![dicTmp[@"name"] isEqual:[NSNull null]]){
            store.name = dicTmp[@"name"];
        }else{
            store.name = @"";
        }
        if (![dicTmp[@"description"] isEqual:[NSNull null]]){
            store.descriptions = dicTmp[@"description"];
        }else{
            store.descriptions = @"";
        }
        if (![dicTmp[@"contact_number"] isEqual:[NSNull null]]){
            store.contact_number = dicTmp[@"contact_number"];
        }else{
            store.contact_number = @"";
        }
        if (![dicTmp[@"address"] isEqual:[NSNull null]]){
            store.address = dicTmp[@"address"];
        }else{
            store.address = @"";
        }
        if (![dicTmp[@"image"] isEqual:[NSNull null]]){
            store.image = dicTmp[@"image"];
        }else{
            store.image = @"";
        }
        if (![dicTmp[@"longitude"] isEqual:[NSNull null]]){
            store.hlong = dicTmp[@"longitude"];
        }else{
            store.hlong = @"";
        }
        if (![dicTmp[@"latitude"] isEqual:[NSNull null]]){
            store.hlat = dicTmp[@"latitude"];
        }else{
            store.hlat = @"";
        }
        if (![dicTmp[@"show_home"] isEqual:[NSNull null]]){
            store.show_home = dicTmp[@"show_home"];
        }else{
            store.show_home = @"";
        }
        if (![dicTmp[@"publish"] isEqual:[NSNull null]]){
            store.publish = dicTmp[@"publish"];
        }else{
            store.publish = @"";
        }
        if (![dicTmp[@"update_time"] isEqual:[NSNull null]]){
            store.update_time = dicTmp[@"update_time"];
        }else{
            store.update_by = @"";
        }
        if (![dicTmp[@"update_by"] isEqual:[NSNull null]]){
            store.update_by = dicTmp[@"update_by"];
        }else{
            store.update_by = @"";
        }
        if (![dicTmp[@"create_by"] isEqual:[NSNull null]]){
            store.create_by = dicTmp[@"create_by"];
        }else{
            store.create_by = @"";
        }
        if (![dicTmp[@"create_time"] isEqual:[NSNull null]]){
            store.create_time = dicTmp[@"create_time"];
        }else{
            store.create_time = @"";
        }
        if (![dicTmp[@"valid"] isEqual:[NSNull null]]){
            store.valid = dicTmp[@"valid"];
        }else{
            store.valid = @"";
        }
        if (![dicTmp[@"category_name"] isEqual:[NSNull null]]){
            store.category_name = dicTmp[@"category_name"];
        }else{
            store.category_name = @"";
        }
        if (![dicTmp[@"distance"] isEqual:[NSNull null]]){
            store.distance = dicTmp[@"distance"];
        }else{
            store.distance = @"";
        }
        
        [arrResults addObject:store];
    }
//    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return arrResults;
}

- (SVCSpecificStore *)getStoreDetailWithResult:(id)result{
    NSDictionary *dic = result;
    if (![dic isKindOfClass:[NSDictionary class]]) {
        return nil;
    }
    SVCSpecificStore *storeDetail = [[SVCSpecificStore MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
    if (!storeDetail) {
        storeDetail = [SVCSpecificStore MR_createEntity];
    }
    
    if (![dic[@"id"] isEqual:[NSNull null]]){
        storeDetail.id = dic[@"id"];
    }else{
        storeDetail.id = @"";
    }
    if (![dic[@"category_id"] isEqual:[NSNull null]]){
        storeDetail.category_id = dic[@"category_id"];
    }else{
        storeDetail.category_id = @"";
    }
    if (![dic[@"user_id"] isEqual:[NSNull null]]){
        storeDetail.user_id = dic[@"user_id"];
    }else{
        storeDetail.user_id = @"";
    }
    if (![dic[@"name"] isEqual:[NSNull null]]){
        storeDetail.name = dic[@"name"];
    }else{
        storeDetail.name = @"";
    }
    if (![dic[@"description"] isEqual:[NSNull null]]){
        storeDetail.descriptions = dic[@"description"];
    }else{
        storeDetail.descriptions = @"";
    }
    if (![dic[@"contact_number"] isEqual:[NSNull null]]){
        storeDetail.contact_number = dic[@"contact_number"];
    }else{
        storeDetail.contact_number = @"";
    }
    if (![dic[@"address"] isEqual:[NSNull null]]){
        storeDetail.address = dic[@"address"];
    }else{
        storeDetail.address = @"";
    }
    if (![dic[@"image"] isEqual:[NSNull null]]){
        storeDetail.image = dic[@"image"];
    }else{
        storeDetail.image = @"";
    }
    if (![dic[@"longitude"] isEqual:[NSNull null]]){
        storeDetail.hlong = dic[@"longitude"];
    }else{
        storeDetail.hlong = @"";
    }
    if (![dic[@"latitude"] isEqual:[NSNull null]]){
        storeDetail.hlat = dic[@"latitude"];
    }else{
        storeDetail.hlat = @"";
    }
    if (![dic[@"show_home"] isEqual:[NSNull null]]){
        storeDetail.show_home = dic[@"show_home"];
    }else{
        storeDetail.show_home = @"";
    }
    if (![dic[@"publish"] isEqual:[NSNull null]]){
        storeDetail.publish = dic[@"publish"];
    }else{
        storeDetail.publish = @"";
    }
    if (![dic[@"update_time"] isEqual:[NSNull null]]){
        storeDetail.update_time = dic[@"update_time"];
    }else{
        storeDetail.update_by = @"";
    }
    if (![dic[@"update_by"] isEqual:[NSNull null]]){
        storeDetail.update_by = dic[@"update_by"];
    }else{
        storeDetail.update_by = @"";
    }
    if (![dic[@"create_by"] isEqual:[NSNull null]]){
        storeDetail.create_by = dic[@"create_by"];
    }else{
        storeDetail.create_by = @"";
    }
    if (![dic[@"create_time"] isEqual:[NSNull null]]){
        storeDetail.create_time = dic[@"create_time"];
    }else{
        storeDetail.create_time = @"";
    }
    if (![dic[@"valid"] isEqual:[NSNull null]]){
        storeDetail.valid = dic[@"valid"];
    }else{
        storeDetail.valid = @"";
    }
    if (![dic[@"category_name"] isEqual:[NSNull null]]){
        storeDetail.category_name = dic[@"category_name"];
    }else{
        storeDetail.category_name = @"";
    }
    
    // list gallery
    NSArray *arrTmp = dic[@"gallery"];
    NSMutableArray *listGallery = [[NSMutableArray alloc] init];
    if (arrTmp.count > 0) {
        for (NSDictionary *dicImg in arrTmp) {
            [listGallery addObject:dicImg[@"image"]];
        }
    }
    storeDetail.gallery = listGallery;
    
    // list Opening Hours
    arrTmp = dic[@"working_hours"];
    NSString *strHours = @"";
    NSMutableArray *listHours = [[NSMutableArray alloc] init];
    if (arrTmp.count > 0) {
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        NSMutableDictionary *dictHours = [[NSMutableDictionary alloc] init];
        
        for (NSDictionary *dic in arrTmp) {
            SVCWorkingHour *obj = [[SVCWorkingHour MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
            if (!obj){
                obj = [SVCWorkingHour MR_createEntity];
            }
            if (![dic[@"id"] isEqual:[NSNull null]]){
                obj.id = dic[@"id"];
            }else{
                obj.id = @"";
            }
            if (![dic[@"code"] isEqual:[NSNull null]]){
                obj.code = dic[@"code"];
            }else{
                obj.code = @"";
            }
            if (![dic[@"from"] isEqual:[NSNull null]]){
                obj.from = dic[@"from"];
            }else{
                obj.from = @"";
            }
            if (![dic[@"store_id"] isEqual:[NSNull null]]){
                obj.store_id = dic[@"store_id"];
            }else{
                obj.store_id = @"";
            }
            if (![dic[@"id"] isEqual:[NSNull null]]){
                obj.to = dic[@"to"];
            }else{
                obj.to = @"";
            }
            if (![dic[@"valid"] isEqual:[NSNull null]]){
                obj.valid = dic[@"valid"];
            }else{
                obj.valid = @"";
            }
            if (![dic[@"create_by"] isEqual:[NSNull null]]){
                obj.create_by = dic[@"create_by"];
            }else{
                obj.create_by = @"";
            }
            if (![dic[@"create_time"] isEqual:[NSNull null]]){
                obj.create_time = dic[@"create_time"];
            }else{
                obj.create_time = @"";
            }
            if (![dic[@"update_by"] isEqual:[NSNull null]]){
                obj.update_by = dic[@"update_by"];
            }else{
                obj.update_by = @"";
            }
            if (![dic[@"update_time"] isEqual:[NSNull null]]){
                obj.update_time = dic[@"update_time"];
            }else{
                obj.update_time = @"";
            }
        
            [format setDateFormat:@"EEEE"];
            NSDate *date = [format dateFromString:obj.code];
            [format setDateFormat:@"c"];
            obj.day = [format stringFromDate:date];
        
            [listHours addObject:obj];
            
            NSString *key = [NSString stringWithFormat:@"%@-%@", obj.from.lowercaseString, obj.to.lowercaseString];
            NSLog(@"Key: %@", key);
            NSMutableArray *arrTmp = [dictHours valueForKey:key];
            if (arrTmp) {
                [arrTmp addObject:obj];
            }else{
                arrTmp = [[NSMutableArray alloc] initWithObjects:obj, nil];
            }
            [dictHours setValue:arrTmp forKey:key];
            
        }
        
        if (listHours.count > 0) {
            SVCWorkingHour *obj = [listHours objectAtIndex:0];
            NSString *timeFrom = obj.from;
            NSString *timeTo    = obj.to;
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"HH:mm:ss"];
            
            for (int i = 0; i < listHours.count; i++) {
                SVCWorkingHour *objHour = [listHours objectAtIndex:i];
                
                NSDate *date1= [formatter dateFromString:timeFrom];
                NSDate *date2 = [formatter dateFromString:objHour.from];
                
                // compare time from
                NSComparisonResult result = [date1 compare:date2];
                if(result == NSOrderedDescending)
                {
                    NSLog(@"date1 is later than date2");
                }
                else if(result == NSOrderedAscending)
                {
                    NSLog(@"date2 is later than date1"); 
                }
                else
                {
                    NSLog(@"date1 is equal to date2");
                    timeFrom = objHour.from;
                }
                
                // compare time to
                date1= [formatter dateFromString:timeTo];
                date2 = [formatter dateFromString:objHour.to];
                result = [date1 compare:date2];
                if(result == NSOrderedDescending)
                {
                    NSLog(@"date1 is later than date2");
                    timeTo = objHour.to;
                }
                else if(result == NSOrderedAscending)
                {
                    NSLog(@"date2 is later than date1");
                }
                else
                {
                    NSLog(@"date1 is equal to date2");
                }
            }
            storeDetail.openHours = [NSString stringWithFormat:@"%@ - %@", timeFrom, timeTo].lowercaseString;
        }
        
        NSMutableArray *listKeys = [[NSMutableArray alloc] initWithArray:[[dictHours allKeys] sortedArrayUsingSelector:@selector(compare:)]];
        
        for (int i = 0 ; i < listKeys.count; i++) {
            NSString *key = [listKeys objectAtIndex:i];
            NSMutableArray *listObj = [dictHours valueForKey:key];
            
            NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"day"
                                                         ascending:YES];
            NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
            NSMutableArray *sortListObj = [NSMutableArray arrayWithArray:[listObj sortedArrayUsingDescriptors:sortDescriptors]];
//            [dictHours setValue:sortListObj forKey:key];
            
            strHours = [strHours stringByAppendingString:[NSString stringWithFormat:@"%@    ", key]];
            for (int j = 0; j < sortListObj.count; j++) {
                SVCWorkingHour *obj = [sortListObj objectAtIndex:j];
                strHours = [strHours stringByAppendingString:[NSString stringWithFormat:@"%@  ", obj.code]];
            }
            if (i < listKeys.count-1) {
                strHours = [strHours stringByAppendingString:@"\n"];
            }
        }
    }
    
    
    storeDetail.listWorking = listHours;
    storeDetail.strHours = [strHours stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];;
    NSLog(@"String Hours: %@", strHours);
    
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return storeDetail;
}

- (NSMutableArray *)getListInboxFormService:(id)result{
    if (![result isKindOfClass:[NSArray class]]){
        return nil;
    }
    NSMutableArray *listResults = [[NSMutableArray alloc] init];
    NSArray *arrList = result;
    for (NSDictionary *dic in arrList) {
        SVCInbox *obj = [[SVCInbox MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
        if (!obj) {
            obj = [SVCInbox MR_createEntity];
            obj.bBookmark = @"0";
            
        }
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.id = dic[@"id"];
        }else{
            obj.id = @"";
        }
        if (![dic[@"member_id"] isEqual:[NSNull null]]){
            obj.member_id = dic[@"member_id"];
        }else{
            obj.member_id = @"";
        }
        if (![dic[@"from"] isEqual:[NSNull null]]){
            obj.from = dic[@"from"];
        }else{
            obj.from = @"";
        }
        if (![dic[@"title"] isEqual:[NSNull null]]){
            obj.title = dic[@"title"];
        }else{
            obj.title = @"";
        }
        if (![dic[@"content"] isEqual:[NSNull null]]){
            obj.content = dic[@"content"];
        }else{
            obj.content = @"";
        }
        if (![dic[@"user_id"] isEqual:[NSNull null]]){
            obj.user_id = dic[@"user_id"];
        }else{
            obj.user_id = @"";
        }
        if (![dic[@"full_name"] isEqual:[NSNull null]]){
            obj.full_name = dic[@"full_name"];
        }else{
            obj.full_name = @"";
        }
        if (![dic[@"is_read"] isEqual:[NSNull null]]){
            obj.isRead = dic[@"is_read"];
        }else{
            obj.isRead = @"";
        }
        if (![dic[@"valid"] isEqual:[NSNull null]]){
            obj.valid = dic[@"valid"];
        }else{
            obj.valid = @"";
        }
        if (![dic[@"create_by"] isEqual:[NSNull null]]){
            obj.create_by = dic[@"create_by"];
        }else{
            obj.create_by = @"";
        }
        if (![dic[@"create_time"] isEqual:[NSNull null]]){
            obj.create_time = dic[@"create_time"];
        }else{
            obj.create_time = @"";
        }
        if (![dic[@"update_by"] isEqual:[NSNull null]]){
            obj.update_by = dic[@"update_by"];
        }else{
            obj.update_by = @"";
        }
        if (![dic[@"update_time"] isEqual:[NSNull null]]){
            obj.update_time = dic[@"update_time"];
        }else{
            obj.update_time = @"";
        }
        [listResults addObject:obj];
    }
    return listResults;
}

- (void)getListQuestionFeedbackWithData:(id)service{
    if (![service isKindOfClass:[NSArray class]]){
        return;
    }
    NSMutableArray *listResults = [[NSMutableArray alloc] init];
    NSArray *arrList = service;
    
//    dispatch_async(dispatch_get_main_queue(), ^{
        if (arrList.count > 0) {
            [SVCQuestion MR_truncateAll];
        }
        for (NSDictionary *dic in arrList) {
            SVCQuestion *obj = [[SVCQuestion MR_findByAttribute:@"question_id" withValue:[dic objectForKey:@"id"]] firstObject];
            if (!obj) {
                obj = [SVCQuestion MR_createEntity];
            }
            if (![dic[@"id"] isEqual:[NSNull null]]){
                obj.question_id = dic[@"id"];
            }else{
                obj.question_id = @"";
            }
            if (![dic[@"name"] isEqual:[NSNull null]]){
                obj.name = dic[@"name"];
            }else{
                obj.name = @"";
            }
            if (![dic[@"create_by"] isEqual:[NSNull null]]){
                obj.create_by = dic[@"create_by"];
            }else{
                obj.create_by = @"";
            }
            if (![dic[@"create_time"] isEqual:[NSNull null]]){
                obj.create_time = dic[@"create_time"];
            }else{
                obj.create_time = @"";
            }
            if (![dic[@"up_by"] isEqual:[NSNull null]]){
                obj.up_by = dic[@"up_by"];
            }else{
                obj.up_by = @"";
            }
            if (![dic[@"up_time"] isEqual:[NSNull null]]){
                obj.up_time = dic[@"up_time"];
            }else{
                obj.up_time = @"";
            }
            if (![dic[@"valid"] isEqual:[NSNull null]]){
                obj.valid = dic[@"valid"];
            }else{
                obj.valid = @"";
            }
        }
        [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
//    });
}

- (NSMutableArray *)getListDealsWithResult:(id)result{
    NSArray *deals = result[@"data"];
    NSMutableArray *resultList = [[NSMutableArray alloc] init];
    for (int i = 0; i < deals.count; i ++) {
        NSDictionary *dic = [deals objectAtIndex:i];
        NSString *dealid = [NSString stringWithFormat:@"%@",[dic objectForKey:@"id"]];
        SVCSpecificDeals *deal = [[SVCSpecificDeals MR_findByAttribute:@"id" withValue:dealid] firstObject];
        if (!deal) {
            deal = [SVCSpecificDeals MR_createEntity];
            deal.id = dealid;
        }
        deal.name = [NSString stringWithFormat:@"%@",[dic objectForKey:@"name"]];
        deal.category_id = [NSString stringWithFormat:@"%@",[dic objectForKey:@"category_id"]];
        deal.banner = [NSString stringWithFormat:@"%@",[dic objectForKey:@"banner"]];
        deal.image = [Util getAbsoluteImageURLWith:[NSString stringWithFormat:@"%@",[dic objectForKey:@"image"]]];
        deal.store_id = [NSString stringWithFormat:@"%@",[dic objectForKey:@"store_id"]];
        deal.price = [NSString stringWithFormat:@"%@",[dic objectForKey:@"price"]];
        deal.currency = [NSString stringWithFormat:@"%@",[dic objectForKey:@"currency"]];
        deal.discount = [NSString stringWithFormat:@"%@",[dic objectForKey:@"discount"]];
        deal.expiry_date = [NSString stringWithFormat:@"%@",[dic objectForKey:@"expiry_date"]];
        deal.show_home = [NSString stringWithFormat:@"%@",[dic objectForKey:@"show_home"]];
        deal.publish = [NSString stringWithFormat:@"%@",[dic objectForKey:@"publish"]];
        deal.valid = [NSString stringWithFormat:@"%@",[dic objectForKey:@"valid"]];
        deal.create_time = [NSString stringWithFormat:@"%@",[dic objectForKey:@"create_time"]];
        deal.create_by = [NSString stringWithFormat:@"%@",[dic objectForKey:@"create_by"]];
        deal.update_time = [NSString stringWithFormat:@"%@",[dic objectForKey:@"update_time"]];
        deal.update_by = [NSString stringWithFormat:@"%@",[dic objectForKey:@"update_by"]];
        deal.category_name = [NSString stringWithFormat:@"%@",[dic objectForKey:@"category_name"]];
        deal.store_name = [NSString stringWithFormat:@"%@",[dic objectForKey:@"store_name"]];
//        deal.distance = [NSString stringWithFormat:@"%@",[dic objectForKey:@"distance"]];
        [resultList addObject:deal];
    }
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return resultList;
}

- (void)saveListCompanyWithData:(id)service{
    if (![service isKindOfClass:[NSDictionary class]]){
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        NSDictionary *dic = service;
        SVCCompany *obj = [[SVCCompany MR_findByAttribute:@"id" withValue:[dic objectForKey:@"company_id"]] firstObject];
        if (!obj) {
            obj = [SVCCompany MR_createEntity];
        }
        if (![dic[@"company_id"] isEqual:[NSNull null]]){
            obj.id = dic[@"company_id"];
        }else{
            obj.id = @"";
        }
        if (![dic[@"company_name"] isEqual:[NSNull null]]){
            obj.name = dic[@"company_name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"company_email"] isEqual:[NSNull null]]){
            obj.email = dic[@"company_email"];
        }else{
            obj.email = @"";
        }
        if (![dic[@"company_mobile"] isEqual:[NSNull null]]){
            obj.mobile = dic[@"company_mobile"];
        }else{
            obj.mobile = @"";
        }
        if (![dic[@"company_wechat"] isEqual:[NSNull null]]){
            obj.wechat = dic[@"company_wechat"];
        }else{
            obj.wechat = @"";
        }
        if (![dic[@"company_opening"] isEqual:[NSNull null]]){
            obj.opening_hours = dic[@"company_opening"];
        }else{
            obj.opening_hours = @"";
        }
        if (![dic[@"company_address"] isEqual:[NSNull null]]){
            obj.address = dic[@"company_address"];
        }else{
            obj.address = @"";
        }
        if (![dic[@"company_web"] isEqual:[NSNull null]]){
            obj.web = dic[@"company_web"];
        }else{
            obj.web = @"";
        }
        if (![dic[@"conf_video"] isEqual:[NSNull null]]){
            obj.conf_video = dic[@"conf_video"];
        }else{
            obj.conf_video = @"";
        }
        
        [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    });
}

- (void)saveListAllPropertyLiveWithData:(id)data{
    if (![data isKindOfClass:[NSArray class]]){
        return;
    }
    
    NSArray *arrList = data;
    [SVCGetPropertiesLive MR_truncateAll];
    for (NSDictionary *dic in arrList) {
        
        SVCGetPropertiesLive *obj = [[SVCGetPropertiesLive MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
        if (obj == nil) {
            obj = [SVCGetPropertiesLive createEntity];
        }
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.id = dic[@"id"];
        }else{
            obj.id = @"";
        }
        if (![dic[@"name"] isEqual:[NSNull null]]){
            obj.name = dic[@"name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"unit"] isEqual:[NSNull null]]){
            obj.unit = dic[@"unit"];
        }else{
            obj.unit = @"";
        }
        if (![dic[@"description"] isEqual:[NSNull null]]){
            obj.descriptions = dic[@"description"];
        }else{
            obj.descriptions = @"";
        }
        if (![dic[@"type"] isEqual:[NSNull null]]){
            obj.type = dic[@"type"];
        }else{
            obj.type = @"";
        }
        if (![dic[@"longitude"] isEqual:[NSNull null]]){
            obj.longitude = dic[@"longitude"];
        }else{
            obj.longitude = @"";
        }
        if (![dic[@"latitude"] isEqual:[NSNull null]]){
            obj.latitude = dic[@"latitude"];
        }else{
            obj.latitude = @"";
        }
        if (![dic[@"create_by"] isEqual:[NSNull null]]){
            obj.create_by = dic[@"create_by"];
        }else{
            obj.create_by = @"";
        }
        if (![dic[@"create_time"] isEqual:[NSNull null]]){
            obj.create_time = dic[@"create_time"];
        }else{
            obj.create_time = @"";
        }
        if (![dic[@"update_time"] isEqual:[NSNull null]]){
            obj.update_time = dic[@"update_time"];
        }else{
            obj.update_time = @"";
        }
        if (![dic[@"update_by"] isEqual:[NSNull null]]){
            obj.update_by = dic[@"update_by"];
        }else{
            obj.update_by = @"";
        }
        if (![dic[@"valid"] isEqual:[NSNull null]]){
            obj.valid = dic[@"valid"];
        }else{
            obj.valid = @"";
        }
    }
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
}

- (void)saveListRaceWithData:(id)data{
    if (![data isKindOfClass:[NSArray class]]){
        return;
    }
    
    NSArray *arrList = data;
    [SVCRace MR_truncateAll];
    for (NSDictionary *dic in arrList) {
        SVCRace *obj = [[SVCRace MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
        if (obj == nil) {
            obj = [SVCRace createEntity];
        }
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.id = dic[@"id"];
        }else{
            obj.id = @"";
        }
        if (![dic[@"name"] isEqual:[NSNull null]]){
            obj.name = dic[@"name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"create_by"] isEqual:[NSNull null]]){
            obj.create_by = dic[@"create_by"];
        }else{
            obj.create_by = @"";
        }
        if (![dic[@"create_time"] isEqual:[NSNull null]]){
            obj.create_time = dic[@"create_time"];
        }else{
            obj.create_time = @"";
        }
        if (![dic[@"update_time"] isEqual:[NSNull null]]){
            obj.update_time = dic[@"update_time"];
        }else{
            obj.update_time = @"";
        }
        if (![dic[@"update_by"] isEqual:[NSNull null]]){
            obj.update_by = dic[@"update_by"];
        }else{
            obj.update_by = @"";
        }
        if (![dic[@"valid"] isEqual:[NSNull null]]){
            obj.valid = dic[@"valid"];
        }else{
            obj.valid = @"";
        }
    }
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
}

- (void)saveListDistanceWithData:(id)data andType:(NSString *)type{
    if (![data isKindOfClass:[NSArray class]]){
        return;
    }
    NSArray *arrList = data;
    dispatch_async(dispatch_get_main_queue(), ^{
        [SVCDistance MR_truncateAll];
        for (NSDictionary *dic in arrList) {
            SVCDistance *obj = [[SVCDistance MR_findByAttribute:@"filter_id" withValue:[dic objectForKey:@"filter_id"]] firstObject];
            if (!obj) {
                obj = [SVCDistance MR_createEntity];
            }
            if (![dic[@"filter_id"] isEqual:[NSNull null]]){
                obj.filter_id = dic[@"filter_id"];
            }else{
                obj.filter_id = @"";
            }
            if (![dic[@"filter_name"] isEqual:[NSNull null]]){
                obj.filter_name = dic[@"filter_name"];
            }else{
                obj.filter_name = @"";
            }
            obj.filter_type = dic[@"type"];
        }
        [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    });
}

- (SVCAboutObj *)getAboutUSWithData:(id)data{
    if (![data isKindOfClass:[NSDictionary class]]){
        return nil;
    }
    NSDictionary *dicResult = data;
    SVCAboutObj *aboutUs        = [[SVCAboutObj alloc] init];
    
    // Event booked
    NSArray *arrBooked          = dicResult[@"events_booked"];
    NSMutableArray *listEventBook = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in arrBooked) {
        ItemObject *obj = [[ItemObject alloc] init];
        obj.type = TYPE_EVENT_BOOK;
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.idObj = dic[@"id"];
        }else{
            obj.idObj = @"";
        }
        if (![dic[@"name"] isEqual:[NSNull null]]){
            obj.name = dic[@"name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"title"] isEqual:[NSNull null]]){
            obj.title = dic[@"title"];
        }else{
            obj.title = @"";
        }
        if (![dic[@"image"] isEqual:[NSNull null]]){
            obj.urlImg = dic[@"image"];
        }else{
            obj.urlImg = @"";
        }
        [listEventBook addObject:obj];
    }
    aboutUs.events_booked = listEventBook;
    
    // user deals purchased
    NSArray *arrDeals          = dicResult[@"deal_purchased"];
    NSMutableArray *listDealPurchased = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in arrDeals) {
        ItemObject *obj = [[ItemObject alloc] init];
        obj.type = TYPE_DEAL_PURCHASED;
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.idObj = dic[@"id"];
        }else{
            obj.idObj = @"";
        }
        if (![dic[@"name"] isEqual:[NSNull null]]){
            obj.name = dic[@"name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"title"] isEqual:[NSNull null]]){
            obj.title = dic[@"title"];
        }else{
            obj.title = @"";
        }
        if (![dic[@"image"] isEqual:[NSNull null]]){
            obj.urlImg = dic[@"image"];
        }else{
            obj.urlImg = @"";
        }
        if (![dic[@"price"] isEqual:[NSNull null]]){
            obj.price = dic[@"price"];
        }else{
            obj.price = @"";
        }
        [listDealPurchased addObject:obj];
    }
    
    aboutUs.deal_purchased = listDealPurchased;
    
    // user deals saved
    NSArray *arrDealsSave          = dicResult[@"deals_saved"];
    NSMutableArray *listDealSaved = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in arrDealsSave) {
        ItemObject *obj = [[ItemObject alloc] init];
        obj.type = TYPE_DEAL_PURCHASED;
        if (![dic[@"id"] isEqual:[NSNull null]]){
            obj.idObj = dic[@"id"];
        }else{
            obj.idObj = @"";
        }
        if (![dic[@"name"] isEqual:[NSNull null]]){
            obj.name = dic[@"name"];
        }else{
            obj.name = @"";
        }
        if (![dic[@"title"] isEqual:[NSNull null]]){
            obj.title = dic[@"title"];
        }else{
            obj.title = @"";
        }
        if (![dic[@"image"] isEqual:[NSNull null]]){
            obj.urlImg = dic[@"image"];
        }else{
            obj.urlImg = @"";
        }
        if (![dic[@"price"] isEqual:[NSNull null]]){
            obj.price = dic[@"price"];
        }else{
            obj.price = @"";
        }
        [listDealSaved addObject:obj];
    }
    
    aboutUs.deal_saved = listDealSaved;

    
    return aboutUs;
}

- (void)saveListCategoryWithData:(id)service{
    if (![service isKindOfClass:[NSArray class]]){
        return;
    }
    NSArray *arrList = service;
    dispatch_async(dispatch_get_main_queue(), ^{
        [SVCGetCategories MR_truncateAll];
        for (NSDictionary *dic in arrList) {
            SVCGetCategories *obj = [[SVCGetCategories MR_findByAttribute:@"id" withValue:[dic objectForKey:@"id"]] firstObject];
            if (!obj) {
                obj = [SVCGetCategories MR_createEntity];
            }
            
            if (![dic[@"id"] isEqual:[NSNull null]]){
                obj.id = dic[@"id"];
            }else{
                obj.id = @"";
            }
            if (![dic[@"name"] isEqual:[NSNull null]]){
                obj.name = dic[@"name"];
            }else{
                obj.name = @"";
            }
            if (![dic[@"description"] isEqual:[NSNull null]]){
                obj.descriptions = dic[@"description"];
            }else{
                obj.descriptions = @"";
            }
            if (![dic[@"code"] isEqual:[NSNull null]]){
                obj.code = dic[@"code"];
            }else{
                obj.code = @"";
            }
            if (![dic[@"type"] isEqual:[NSNull null]]){
                obj.type = dic[@"type"];
            }else{
                obj.type = @"";
            }
            if (![dic[@"create_by"] isEqual:[NSNull null]]){
                obj.create_by = dic[@"create_by"];
            }else{
                obj.create_by = @"";
            }
            if (![dic[@"create_time"] isEqual:[NSNull null]]){
                obj.create_time = dic[@"create_time"];
            }else{
                obj.create_time = @"";
            }
            if (![dic[@"update_by"] isEqual:[NSNull null]]){
                obj.update_by = dic[@"update_by"];
            }else{
                obj.update_by = @"";
            }
            if (![dic[@"update_time"] isEqual:[NSNull null]]){
                obj.update_time = dic[@"update_time"];
            }else{
                obj.update_time = @"";
            }
            if (![dic[@"valid"] isEqual:[NSNull null]]){
                obj.valid = dic[@"valid"];
            }else{
                obj.valid = @"";
            }
        }
        [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    });
}

- (NSArray*)getEventsFromResponse:(NSArray*)dic{
    return [SVCHomeEvents initWithArray:dic];
}

-(NSDictionary*)getSpecifyEventFromResponse:(NSDictionary*)response{
    NSMutableDictionary *dic = [NSMutableDictionary new];
    [dic setValue:[SVCSpecificEvent initWithDictionary:response] forKey:@"content"];
    [dic setValue:[SVCGalleryImage initWithArray:response[@"gallery_image"]] forKey:@"image"];
    [dic setValue:[SVCGalleryVideo initWithArray:response[@"gallery_video"]] forKey:@"video"];
    return [dic copy];
}

- (SVCSpecificNews *)getQQNewsDetailWithData:(id)data{
    
    NSDictionary *dic = (NSDictionary *)data;
    NSString * newsID =[dic objectForKey:@"id"];
    SVCSpecificNews * obj =[[SVCSpecificNews MR_findByAttribute:@"id" withValue:newsID] firstObject];
    
    if(!obj){
        obj =[SVCSpecificNews MR_createEntity];
    }
    
    if (![dic[@"id"] isEqual:[NSNull null]]){
        obj.id = dic[@"id"];
    }else{
        obj.id = @"";
    }
    if (![dic[@"name"] isEqual:[NSNull null]]){
        obj.name = dic[@"name"];
    }else{
        obj.name = @"";
    }
    if (![dic[@"category_id"] isEqual:[NSNull null]]){
        obj.category_id = dic[@"category_id"];
    }else{
        obj.category_id = @"";
    }
    if (![dic[@"publish_date"] isEqual:[NSNull null]]){
        obj.publish_date = dic[@"publish_date"];
    }else{
        obj.publish_date = @"";
    }
    if (![dic[@"description"] isEqual:[NSNull null]]){
        obj.descriptions = dic[@"description"];
    }else{
        obj.descriptions = @"";
    }
    if (![dic[@"content_image"] isEqual:[NSNull null]]){
        obj.content_image = dic[@"content_image"];
    }else{
        obj.content_image = @"";
    }
    if (![dic[@"html"] isEqual:[NSNull null]]){
        obj.html = dic[@"html"];
    }else{
        obj.html = @"";
    }
    NSString * imageUrl  = [Util getAbsoluteImageURLWith:[NSString stringWithFormat:@"%@",[dic objectForKey:@"image"]]];
    obj.image =imageUrl;
    
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return obj;
}


@end
