//
//  SVCSpecificHomeService.m
//  HiLife
//
//  Created by CMC on 4/2/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCSpecificHomeService.h"


@implementation SVCSpecificHomeService

@synthesize service_name;
@synthesize service_id;
@synthesize id;
@synthesize category_id;
@synthesize user_id;
@synthesize name;
@synthesize marital_status;
@synthesize descriptions;
@synthesize contact_number;
@synthesize address;
@synthesize image;
@synthesize longitude;
@synthesize latitude;
@synthesize show_home;
@synthesize publish;
@synthesize update_time;
@synthesize update_by;
@synthesize create_by;
@synthesize create_time;
@synthesize valid;
@synthesize OpenningTime;
@synthesize strHours;
@synthesize openHours;
@end
