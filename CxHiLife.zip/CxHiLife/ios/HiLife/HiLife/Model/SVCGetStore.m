//
//  SVCGetStore.m
//  HiLife
//
//  Created by Thong Do Minh on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCGetStore.h"


@implementation SVCGetStore

@dynamic id;
@dynamic category_id;
@dynamic user_id;
@dynamic name;
@dynamic descriptions;
@dynamic contact_number;
@dynamic address;
@dynamic image;
@dynamic hlong;
@dynamic hlat;
@dynamic show_home;
@dynamic publish;
@dynamic update_time;
@dynamic update_by;
@dynamic create_by;
@dynamic create_time;
@dynamic valid;
@dynamic category_name;
@dynamic distance;
- (void)setStoreID:(NSString *)storeID{
    self.id = storeID;
}


@end
