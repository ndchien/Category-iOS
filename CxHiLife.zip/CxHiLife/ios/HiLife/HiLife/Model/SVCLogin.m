//
//  SVCLogin.m
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCLogin.h"


@implementation SVCLogin

@dynamic birth;
@dynamic cars;
@dynamic contact;
@dynamic create_by;
@dynamic create_time;
@dynamic email;
@dynamic first_name;
@dynamic force_password_reset;
@dynamic user_id;
@dynamic language;
@dynamic last_name;
@dynamic confirm_change_live;
@dynamic old_properties_live_id;
@dynamic marital_status;
@dynamic race_id;
@dynamic race_name;
@dynamic password;
@dynamic pets;
@dynamic property_id;
@dynamic property_name;
@dynamic role_id;
@dynamic sex;
@dynamic timezone;
@dynamic owner_pending;
@dynamic token;
@dynamic token_expites;
@dynamic type;
@dynamic unit;
@dynamic unit_no;
@dynamic update_by;
@dynamic update_time;
@dynamic valid;
@dynamic verification_code;
@dynamic credit;

@synthesize other_property_id;
@synthesize dependents;
@synthesize otherProperties;

- (void)initWithDictionary:(NSDictionary *)dic{
    self.user_id = (NSString*)dic[@"id"];
    self.first_name = [dic[@"first_name"] stringValue];
    self.last_name = dic[@"last_name"];
    self.email = dic[@"email"];
    self.contact = dic[@"contact"];
    self.property_id = dic[@"property_id"];
    self.property_name = dic[@"properties_name"];
    self.race_id = dic[@"race_id"];
    self.race_name = dic[@"race_name"];
    self.unit = dic[@"unit"];
    self.unit = dic[@"unit_no"];
    self.type = dic[@"type"];
    self.sex = dic[@"sex"];
    self.old_properties_live_id = dic[@"old_properties_live_id"];
    self.confirm_change_live = dic[@"confirm_change_live"];
    self.marital_status = dic[@"marital_status"];
    self.birth = dic[@"birth"];
    self.role_id = dic[@"role_id"];
    self.verification_code = dic[@"verification_code"];
    self.pets = dic[@"pets"];
    self.cars = dic[@"cars"];
    self.language = dic[@"language"];
    self.timezone = dic[@"timezone"];
    //login.credit = dic[@"credit"];
    self.token = dic[@"token"];
    self.owner_pending = dic[@"owner_pending"];
    self.token_expites = dic[@"token_expites"];
    self.valid = dic[@"valid"];
    self.create_time = dic[@"create_time"];
    self.create_by = dic[@"create_by"];
    self.update_time = dic[@"update_time"];
    self.update_by = dic[@"update_by"];
    self.credit = dic[@"credit"];
}

- (id)mutableCopyWithZone:(NSZone *)zone {
    id instance = nil;
    if ((instance = [[[self class] alloc] init])) {
        [instance setUser_id:self.user_id];
        [instance setFirst_name:self.self.first_name];
        [instance setLast_name:self.last_name];
        [instance setEmail:self.email];
        [instance setContact:self.contact];
        [instance setProperties_id:self.property_id];
        [instance setUnit:self.unit];
        [instance setSex:self.sex];
        [instance setMarital_status:self.marital_status];
        [instance setRace_id:self.race_id];
        [instance setBirth:self.birth];
        [instance setRole_id:self.role_id];
        [instance setVerification_code:self.verification_code];
        [instance setOwner_pending:self.owner_pending];
        [instance setPets:self.pets];
        [instance setCars:self.cars];
        [instance setLanguage:self.language];
        [instance setTimezone:self.timezone];
        [instance setToken:self.token];
        [instance setValid:self.valid];
        [instance setCreate_by:self.create_by];
        [instance setCreate_time:self.create_time];
        [instance setUpdate_by:self.update_by];
        [instance setUpdate_time:self.update_time];
    }
    return instance;
}

@end

@implementation OtherProperties

@synthesize properties_id;
@synthesize name;
@synthesize descriptions;
@synthesize unit;
@synthesize type;
@synthesize address;
@synthesize longitude;
@synthesize latitude;
@synthesize user_id;
@synthesize valid;
@synthesize create_by;
@synthesize create_time;
@synthesize update_by;
@synthesize update_time;


+(instancetype) initWithDictionary:(NSDictionary*)dic{
    OtherProperties *obj = [[OtherProperties alloc] init];
    obj.properties_id = dic[@"id"];
    obj.name = dic[@"name"];
    obj.descriptions = dic[@"description"];
    obj.unit = dic[@"unit"];
    obj.type = dic[@"type"];
    obj.address = dic[@"address"];
    obj.longitude = dic[@"longitude"];
    obj.latitude = dic[@"latitude"];
    obj.valid = dic[@"valid"];
    obj.create_by = dic[@"create_by"];
    obj.create_time = dic[@"create_time"];
    obj.update_by = dic[@"update_by"];
    obj.update_time = dic[@"update_time"];
    obj.user_id = dic[@"user_id"];
    
    return obj;
}

- (NSMutableDictionary*)toDictionary{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setValue:self.name forKey:@"name"];
    [dic setValue:self.descriptions forKey:@"description"];
    [dic setValue:self.unit forKey:@"unit"];
    return dic;
}
@end

@implementation DependentObject

@synthesize dependent_id;
@synthesize first_name;
@synthesize last_name;
@synthesize age;
@synthesize user_id;
@synthesize valid;
@synthesize create_time;
@synthesize create_by;
@synthesize update_time;
@synthesize update_by;

+(instancetype) initWithDictionary:(NSDictionary*)dic{
    DependentObject *obj = [[DependentObject alloc] init];
    obj.dependent_id = dic[@"id"];
    obj.first_name = dic[@"first_name"];
    obj.last_name = dic[@"last_name"];
    obj.age = dic[@"age"];
    obj.valid = dic[@"valid"];
    obj.create_by = dic[@"create_by"];
    obj.create_time = dic[@"create_time"];
    obj.update_by = dic[@"update_by"];
    obj.update_time = dic[@"update_time"];
    obj.user_id = dic[@"user_id"];
    
    return obj;
}

- (NSMutableDictionary*)toDictionary{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:self.first_name forKey:@"first_name"];
    [dict setValue:self.last_name forKey:@"last_name"];
    [dict setValue:self.age forKey:@"age"];
    [dict setValue:self.dependent_id forKey:@"id"];
    return dict;
}
@end
