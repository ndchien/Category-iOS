//
//  SVCSpecificHomeService.h
//  HiLife
//
//  Created by CMC on 4/2/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCSpecificHomeService : NSObject

@property (nonatomic, retain) NSString * service_name;
@property (nonatomic, retain) NSString * service_id;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * category_id;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * marital_status;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * contact_number;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * longitude;
@property (nonatomic, retain) NSString * latitude;
@property (nonatomic, retain) NSString * show_home;
@property (nonatomic, retain) NSString * publish;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * strHours;
@property (nonatomic, retain) NSString * openHours;
@property (nonatomic, strong) NSArray  * OpenningTime;

@end
