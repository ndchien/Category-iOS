//
//  SVCRoomInfo.m
//  HiLife
//
//  Created by CMC on 4/1/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCRoomInfo.h"

@implementation SVCRoomInfo
@synthesize create_by;
@synthesize create_time;
@synthesize descriptions;
@synthesize id;
@synthesize image;
@synthesize name;
@synthesize package_id;
@synthesize price;
@synthesize price_m2;
@synthesize size;
@synthesize update_by;
@synthesize update_time;
@synthesize valid;
@synthesize currency;
@synthesize room_type;
@synthesize room_items;
@synthesize floorplan;
@synthesize raw_design;
@synthesize renovated;
@synthesize arrGallery;
@end
