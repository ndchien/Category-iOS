//
//  SVCHomeContentBottom.m
//  HiLife
//
//  Created by CMC on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCHomeContentBottom.h"


@implementation SVCHomeContentBottom

@dynamic title;
@dynamic descriptions;
@dynamic image;
@dynamic create_time;
@dynamic id;
@dynamic category;
@dynamic index;

@end
