//
//  SVCNews.h
//  HiLife
//
//  Created by Thong Do Minh on 3/24/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCNews : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * category_id;
@property (nonatomic, retain) NSString * publish_date;
@property (nonatomic, retain) NSString * image;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * html;
@property (nonatomic, retain) NSString * banner;

@end
