//
//  SVCCommonConfig.m
//  HiLife
//
//  Created by S0nK3o on 4/10/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCCommonConfig.h"

@implementation SVCCommonConfig

@dynamic id;
@dynamic companyName;
@dynamic companyAddress;
@dynamic companyMobile;
@dynamic companyWeb;
@dynamic companyOpening;
@dynamic companyEmail;
@dynamic companyWechat;

@dynamic confVideo;
@dynamic paypalApplicationId;
@dynamic paypalRecipient;
@dynamic paypalCurrency;

@dynamic paypalType;

@end
