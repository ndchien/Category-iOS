//
//  SVCPocket.m
//  HiLife
//
//  Created by S0nK3o on 4/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCPocket.h"

@implementation SVCPocket

@dynamic id;
@dynamic banner;
@dynamic dealName;
@dynamic dealId;
@dynamic dealHicredit;
@dynamic storeName;
@dynamic expiryDate;
@dynamic price;
@dynamic discount;
@dynamic image;
@dynamic status;
@dynamic expiry_date_string;
@dynamic deal_redeem_code;
@dynamic deal_dialog_title;
@end
