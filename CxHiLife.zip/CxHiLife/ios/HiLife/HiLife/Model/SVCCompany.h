//
//  SVCCompany.h
//  HiLife
//
//  Created by CMC iOS Dev on 25/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCCompany : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * wechat;
@property (nonatomic, retain) NSString * mobile;
@property (nonatomic, retain) NSString * opening_hours;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * up_by;
@property (nonatomic, retain) NSString * up_time;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * web;
@property (nonatomic, retain) NSString * conf_video;
@end
