//
//  SVCAddProperTyLive.m
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCAddProperTyLive.h"


@implementation SVCAddProperTyLive

@dynamic name;
@dynamic type;
@dynamic unit;
@dynamic user_id;

@end
