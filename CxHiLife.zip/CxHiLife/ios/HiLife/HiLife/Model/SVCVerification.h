//
//  SVCVerification.h
//  HiLife
//
//  Created by Thong Do Minh on 3/16/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SVCVerification : NSManagedObject

@property (nonatomic, retain) NSString * first_name;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * last_name;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * contact;
@property (nonatomic, retain) NSString * property_id;
@property (nonatomic, retain) NSString * password;
@property (nonatomic, retain) NSString * unit;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * sex;
@property (nonatomic, retain) NSString * marital_status;
@property (nonatomic, retain) NSString * birth;
@property (nonatomic, retain) NSString * role_id;
@property (nonatomic, retain) NSString * user_id;
@property (nonatomic, retain) NSString * verification_code;
@property (nonatomic, retain) NSString * pets;
@property (nonatomic, retain) NSString * cars;
@property (nonatomic, retain) NSString * language;
@property (nonatomic, retain) NSString * force_password_reset;
@property (nonatomic, retain) NSString * timezone;
@property (nonatomic, retain) NSString * token;
@property (nonatomic, retain) NSString * valid;
@property (nonatomic, retain) NSString * create_time;
@property (nonatomic, retain) NSString * create_by;
@property (nonatomic, retain) NSString * update_time;
@property (nonatomic, retain) NSString * update_by;

+(instancetype)initWithDictionary:(NSDictionary *)dic;
@end
