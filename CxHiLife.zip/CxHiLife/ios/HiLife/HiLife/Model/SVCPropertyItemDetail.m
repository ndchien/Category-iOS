//
//  SVCPropertyItemDetail.m
//  HiLife
//
//  Created by C4-Mac Mini on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCPropertyItemDetail.h"

@implementation SVCPropertyItemDetail
@synthesize  id;
@synthesize  properties_item_id;
@synthesize  content;
@synthesize  phone;
@synthesize  email;
@synthesize  create_time;
@synthesize  create_by;
@synthesize  update_time;
@synthesize  update_by;
@synthesize  valid;

+(instancetype)initWithDictionary:(NSDictionary *)dic{
    SVCPropertyItemDetail *property = [SVCPropertyItemDetail MR_createEntity];
    [Util getInstanceFromServerSesponse:dic withInstance:property];
    [[NSManagedObjectContext MR_defaultContext] saveToPersistentStoreAndWait];
    return property;
}

+(NSArray*)initWithArray:(NSArray*)array{
    NSMutableArray *result = [NSMutableArray new];
    for (NSDictionary *dic in array) {
        [result addObject:[SVCPropertyItemDetail initWithDictionary:dic]];
    }
    return result;
}
@end
