//
//  UserModel.m
//  SHSSC
//
//  Created by RibboN Dinh on 3/3/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@synthesize server_id;
@synthesize full_name;
@synthesize email;
@synthesize address;
@synthesize contact_number;
@synthesize gender;
@synthesize nric_passport;
@synthesize salt;
@synthesize national_id;
@synthesize dob;
@synthesize photo;
@synthesize note;
@synthesize os_type;
@synthesize machine_code;
@synthesize user_token;

+(instancetype) initWithDictionary:(NSDictionary*)dic{
    NSString* server_id  = dic[@"id"];
    NSString* full_name= dic[@"full_name"];
    NSString* email= dic[@"email"];
    NSString* address= dic[@"address"];
    NSString* contact_number= dic[@"contact_number"];
    NSString* gender= dic[@"gender"];
    NSString* nric_passport= dic[@"nric_passport"];
    NSString* salt= dic[@"salt"];
    NSString* national_id= dic[@"national_id"];
    NSString* dob= dic[@"dob"];
    NSString* photo= dic[@"photo"];
    NSString* note= dic[@"note"];
    NSString* os_type= dic[@"os_type"];
    NSString* machine_code= dic[@"machine_code"];
    NSString* user_token= dic[@"user_token"];
    
    UserModel *user = [UserModel new];
    
    user.server_id = server_id;
    user.full_name = full_name;
    user.email = email;
    user.address = address;
    user.contact_number = contact_number;
    user.gender = gender;
    user.nric_passport = nric_passport;
    user.salt = salt;
    user.national_id = national_id;
    user.dob = dob;
    user.photo = photo;
    user.note = note;
    user.os_type = os_type;
    user.machine_code = machine_code;
    user.user_token = user_token;
    
    return user;
}
@end
