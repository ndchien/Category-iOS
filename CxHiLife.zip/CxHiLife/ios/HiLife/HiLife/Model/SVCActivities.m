//
//  SVCActivities.m
//  HiLife
//
//  Created by CMC on 3/26/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCActivities.h"


@implementation SVCActivities

@dynamic id;
@dynamic name;
@dynamic create_id;
@dynamic start_date;
@dynamic end_date;
@dynamic image;
@dynamic descriptions;
@dynamic video;
@dynamic create_by;
@dynamic create_time;
@dynamic valid;
@dynamic update_by;
@dynamic update_time;
@dynamic show_home;
@dynamic publish;

@end
