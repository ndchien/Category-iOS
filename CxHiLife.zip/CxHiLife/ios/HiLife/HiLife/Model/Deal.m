//
//  Deal.m
//  HiLife
//
//  Created by CMC on 3/17/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "Deal.h"

@implementation Deal
@synthesize dealid;
@synthesize dealname;
@synthesize dealcateid;
@synthesize dealuserid;
@synthesize dealbanner;
@synthesize dealimage;
@synthesize dealstoreid;
@synthesize dealprice;
@synthesize dealdiscount;
@synthesize dealexpirydate;
@synthesize dealshowhome;
@synthesize dealpublish;
@synthesize dealvalid;
@synthesize dealcreatetime;
@synthesize dealcreateby;
@synthesize dealupdatetime;
@synthesize dealupdateby;
@synthesize dealcatename;
@synthesize dealstorename;
@synthesize dealdistance;
@end
