//
//  SVCTip.h
//  HiLife
//
//  Created by C4-Mac Mini on 3/31/15.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface SVCTip : NSManagedObject

@property (nonatomic, strong) NSString *id;
@property (nonatomic, strong) NSString *category_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *banner;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *descriptions;
@property (nonatomic, strong) NSString *html;
@property (nonatomic, strong) NSString *show_home;
@property (nonatomic, strong) NSString *publish;
@property (nonatomic, strong) NSString *create_time;
@property (nonatomic, strong) NSString *create_by;
@property (nonatomic, strong) NSString *update_time;
@property (nonatomic, strong) NSString *update_by;
@property (nonatomic, strong) NSString *valid;
@property (nonatomic, strong) NSString *category_name;

+(instancetype)initWithDictionary:(NSDictionary*)dic;
+(NSArray*)initWithArray:(NSArray*)array;
@end
