//
//  SVCQuestion.m
//  HiLife
//
//  Created by CMC iOS Dev on 25/03/2015.
//  Copyright (c) 2015 CMCSoft. All rights reserved.
//

#import "SVCQuestion.h"


@implementation SVCQuestion

@dynamic question_id;
@dynamic name;
@dynamic create_by;
@dynamic create_time;
@dynamic up_by;
@dynamic up_time;
@dynamic valid;

@end
