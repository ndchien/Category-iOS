cordova.define("com.firerunner.cordova.FacebookSharePlugin", function(require, exports, module) {

    
    var plugin = {
    	shareActivity: function(item, pageUrl, pictureUrl, description, isOwnerSharing, successCallback, errorCallback){
    		cordova.exec(successCallback, errorCallback, "FacebookSharePlugin", "shareActivity", [item, pageUrl, pictureUrl, description, isOwnerSharing]);
    	},
    	shareEvent: function(item, pageUrl, pictureUrl, description, successCallback, errorCallback){
            cordova.exec(successCallback, errorCallback, "FacebookSharePlugin", "shareEvent", [item, pageUrl, pictureUrl, description]);
        }
    };
           

    module.exports = plugin;
   
});