cordova.define("com.firerunner.cordova.jstyle.JStyle", function (require, exports, module) { // API definition for EvoThings BLE plugin.
    //
    // Use jsdoc to generate documentation.

    // The following line causes a jsdoc error.
    // Use the jsdoc option -l to ignore the error.
    var exec = cordova.require('cordova/exec');

    exports.connectDevice = function (address, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, "JStyle", "connectDevice", [{ address : address }]);
    };
               
    exports.exec = function (commandName, params, successCallback, errorCallback) {
               console.log('JStyle will try executing: ' + commandName);
        cordova.exec(successCallback, errorCallback, "JStyle", commandName, params);
    };
               
    exports.startRealTime = function (notifyCallback, successCallback, errorCallback) {
               console.log('Notify callback: ' + typeof(notifyCallback));
               var isSuccessCalled = false;
               cordova.exec(function(data){
                            if(!isSuccessCalled && successCallback){
                                successCallback(data.value);
                                isSuccessCalled = true;
                            }
                            if(notifyCallback) notifyCallback(data.value);
                            }, errorCallback, "JStyle", "startRealTime", []);
    };

    exports.startHeartRate = function (notifyCallback, successCallback, errorCallback) {
                   console.log('Notify callback: ' + typeof(notifyCallback));
                   var isSuccessCalled = false;
                   cordova.exec(function(data){
                                if(!isSuccessCalled && successCallback){
                                    successCallback(data.value);
                                    isSuccessCalled = true;
                                }
                                if(notifyCallback) notifyCallback(data.value);
                                }, errorCallback, "JStyle", "startHeartRate", []);
        };
               
               exports.isConnected = function (successCallback, errorCallback) {
               cordova.exec(successCallback, errorCallback, "JStyle", "isConnected", []);
               };
   
    exports.encodedStringToBytes = function (string) {
        var data = atob(string);
        var bytes = new Uint8Array(data.length);
        for (var i = 0; i < bytes.length; i++) {
            bytes[i] = data.charCodeAt(i);
        }
        return bytes;
    };

    exports.bytesToEncodedString = function (bytes) {
        return btoa(String.fromCharCode.apply(null, bytes));
    };

    exports.stringToBytes = function (string) {
        var bytes = new ArrayBuffer(string.length * 2);
        var bytesUint16 = new Uint16Array(bytes);
        for (var i = 0; i < string.length; i++) {
            bytesUint16[i] = string.charCodeAt(i);
        }
        return new Uint8Array(bytesUint16);
    };

    exports.bytesToString = function (bytes) {
        return String.fromCharCode.apply(null, new Uint16Array(bytes));
    };

    
});
