cordova.define("com.firerunner.cordova.SideBarMenu", function(require, exports, module) {

    
    var plugin = {
    	setMenuItems: function(items, successCallback, errorCallback){
    		cordova.exec(successCallback, errorCallback, "SideBarMenu", "setMenuItems", [items]);
    	},
    	setBackgroundColor: function(color, successCallback, errorCallback){
    		cordova.exec(successCallback, errorCallback, "SideBarMenu", "setBackgroundColor", [color]);
    	},
    	toggle: function(successCallback, errorCallback){
    		cordova.exec(successCallback, errorCallback, "SideBarMenu", "toggle", []);
    	}
    };
           

    module.exports = plugin;
   
});