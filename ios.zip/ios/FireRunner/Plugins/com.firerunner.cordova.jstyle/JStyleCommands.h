//
//  JStyleCommands.h
//  FireRunner
//
//  Created by Artem Lakomov on 2/28/15.
//
//

#import <Foundation/Foundation.h>

@interface JStyleCommands : NSObject

- (NSData*) setDateTime:(NSDate*)date;
- (BOOL) setDateTimeResult:(NSData*)value;
- (NSData*) getDayActivity:(int)dayIndex;
- (NSArray*) getDayActivityResult:(NSArray*)values;
- (BOOL) getDayActivityEmptyResponse:(NSData*)value;
- (NSData*) getTotalDayActivity:(int)dayIndex;
- (NSMutableDictionary*) getTotalDayActivityResult:(NSArray*)values;
- (NSData*) setPersonalInformation:(NSDictionary*)bio;
- (BOOL) setPersonalInformationResult:(NSData*)value;
- (NSData*) getPersonalInformation;
- (NSDictionary*) getPersonalInformationResult:(NSData*)value;
- (NSData*) setTargetSteps:(unsigned int)steps;
- (BOOL) setTargetStepsResult:(NSData*)value;
- (NSData*) getTargetSteps;
- (unsigned int) getTargetStepsResult:(NSData*)value;
- (NSData*) vibrate:(int)sec;
- (BOOL) vibrateResult:(NSData*)value;
- (NSData*) getDeviceName;
- (NSString*) getDeviceNameResult:(NSData*)value;
- (NSData*) startRealTime;
- (NSDictionary*) startRealTimeResult:(NSData*)value;
// sonnh
- (NSDictionary*) startRealTimeResultWithJumBLE:(NSData*)value;
// end
- (NSData*) stopRealTime;
- (BOOL) stopRealTimeResult:(NSData*)value;
- (NSData*) startHeartRate;
- (NSDictionary*) startHeartRateResult:(NSData*)value;
- (NSData*) stopHeartRate;
- (BOOL) stopHeartRateResult:(NSData*)value;
- (NSData*) reset;
- (BOOL) resetResult:(NSData*)value;
- (NSData*) getDeviceInfo;
- (NSDictionary*) getDeviceInfoResult:(NSData*)value;
- (NSData*) startBonding;
- (BOOL) startBondingResult:(NSData*)value;
- (NSData*) getCurrentActivity;
- (NSDictionary*) getCurrentActivityResult:(NSData*)value;



@end
