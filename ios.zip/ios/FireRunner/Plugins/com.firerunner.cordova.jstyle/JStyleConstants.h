//
//  JStyleConstants.h
//  FireRunner
//
//  Created by Artem Lakomov on 4/11/15.
//
//

#ifndef FireRunner_JStyleConstants_h
#define FireRunner_JStyleConstants_h


// for scan none device: 180D , if has using return jServiceId : 0A5D115B-9CE5-2510-20F2-DB4986499778
static NSString *const JServiceId = @"180D";
static NSString *const JCharaTX = @"0A5D115B-9CE5-2510-20F2-DB4986499778";
static NSString *const JCharaRX = @"0A5D115B-9CE5-2510-20F2-DB4986499778";


static NSString *const JpluginName = @"JStyle";
static NSString *const JScannerName = @"JStyleScanner";

static NSString *const JkeyStatus = @"status";
static NSString *const JkeyError = @"error";
static NSString *const JkeyRequest = @"request";
static NSString *const JkeyMessage = @"message";
static NSString *const JkeyName = @"name";
static NSString *const JkeyAddress = @"address";
static NSString *const JkeyProperties = @"properties";
static NSString *const JkeyRssi = @"rssi";
static NSString *const JkeyAdvertisement = @"advertisement";
static NSString *const JkeyServiceUuids = @"serviceUuids";
static NSString *const JkeyCharacteristicUuids = @"characteristicUuids";
static NSString *const JkeyCharacteristics = @"characteristics";
static NSString *const JkeyDescriptorUuids = @"descriptorUuids";
static NSString *const JkeyServiceUuid = @"serviceUuid";
static NSString *const JkeyCharacteristicUuid = @"characteristicUuid";
static NSString *const JkeyDescriptorUuid = @"descriptorUuid";
static NSString *const JkeyValue = @"value";
static NSString *const JkeyType = @"type";
static NSString *const JkeyIsInitialized = @"isInitalized";
static NSString *const JkeyIsEnabled = @"isEnabled";
static NSString *const JkeyIsScanning = @"isScanning";
static NSString *const JkeyIsConnected = @"isConnected";
static NSString *const JkeyIsDiscovered = @"isDiscovered";

//Write Type
static NSString *const JwriteTypeNoResponse = @"noResponse";

//Properties
static NSString *const JpropertyBroadcast = @"broadcast";
static NSString *const JpropertyRead = @"read";
static NSString *const JpropertyWriteWithoutResponse = @"writeWithoutResponse";
static NSString *const JpropertyWrite = @"write";
static NSString *const JpropertyNotify = @"notify";
static NSString *const JpropertyIndicate = @"indicate";
static NSString *const JpropertyAuthenticatedSignedWrites = @"authenticatedSignedWrites";
static NSString *const JpropertyExtendedProperties = @"extendedProperties";
static NSString *const JpropertyNotifyEncryptionRequired = @"notifyEncryptionRequired";
static NSString *const JpropertyIndicateEncryptionRequired = @"indicateEncryptionRequired";

//Status Types
static NSString *const JstatusEnabled = @"enabled";
static NSString *const JstatusScanStarted = @"scanStarted";
static NSString *const JstatusScanStopped = @"scanStopped";
static NSString *const JstatusScanResult = @"scanResult";
static NSString *const JstatusConnected = @"connected";
static NSString *const JstatusConnecting = @"connecting";
static NSString *const JstatusDisconnected = @"disconnected";
static NSString *const JstatusDisconnecting = @"disconnecting";
static NSString *const JstatusClosed = @"closed";
static NSString *const JstatusDiscoveredServices = @"discoveredServices";
static NSString *const JstatusDiscoveredCharacteristics = @"discoveredCharacteristics";
static NSString *const JstatusDiscoveredDescriptors = @"discoveredDescriptors";
static NSString *const JstatusRead = @"read";
static NSString *const JstatusSubscribed = @"subscribed";
static NSString *const JstatusSubscribedResult = @"subscribedResult";
static NSString *const JstatusUnsubscribed = @"unsubscribed";
static NSString *const JstatusWritten = @"written";
static NSString *const JstatusReadDescriptor = @"readDescriptor";
static NSString *const JstatusWrittenDescriptor = @"writtenDescriptor";
static NSString *const JstatusRssi = @"rssi";

//Error Types
static NSString *const JerrorInitialize = @"initialize";
static NSString *const JerrorEnable = @"enable";
static NSString *const JerrorArguments = @"arguments";
static NSString *const JerrorStartScan = @"startScan";
static NSString *const JerrorStopScan = @"stopScan";
static NSString *const JerrorConnect = @"connect";
static NSString *const JerrorReconnect = @"reconnect";
static NSString *const JerrorDiscoverServices = @"discoverServices";
static NSString *const JerrorDiscoverCharacteristics = @"discoverCharacteristics";
static NSString *const JerrorDiscoverDescriptors = @"discoverDescriptors";
static NSString *const JerrorRead = @"read";
static NSString *const JerrorSubscription = @"subscription";
static NSString *const JerrorWrite = @"write";
static NSString *const JerrorReadDescriptor = @"readDescriptor";
static NSString *const JerrorWriteDescriptor = @"writeDescriptor";
static NSString *const JerrorRssi = @"rssi";
static NSString *const JerrorNeverConnected = @"neverConnected";
static NSString *const JerrorIsNotDisconnected = @"isNotDisconnected";
static NSString *const JerrorIsNotConnected = @"isNotConnected";
static NSString *const JerrorIsDisconnected = @"isDisconnected";
static NSString *const JerrorService = @"service";
static NSString *const JerrorCharacteristic = @"characteristic";
static NSString *const JerrorDescriptor = @"descriptor";

//Error Messages
//Initialization
static NSString *const JlogPoweredOff = @"Bluetooth powered off";
static NSString *const JlogUnauthorized = @"Bluetooth unauthorized";
static NSString *const JlogUnknown = @"Bluetooth unknown state";
static NSString *const JlogResetting = @"Bluetooth resetting";
static NSString *const JlogUnsupported = @"Bluetooth unsupported";
static NSString *const JlogNotInit = @"Bluetooth not initialized";
static NSString *const JlogNotEnabled = @"Bluetooth not enabled";
static NSString *const JlogAlreadyInit = @"Bluetooth already initialized";
//Scanning
static NSString *const JlogAlreadyScanning = @"Scanning already in progress";
static NSString *const JlogNotScanning = @"Not scanning";
//Connection
static NSString *const JlogPreviouslyConnected = @"Device previously connected, reconnect or close for new device";
static NSString *const JlogNeverConnected = @"Never connected to device";
static NSString *const JlogIsNotConnected = @"Device isn't connected";
static NSString *const JlogIsNotDisconnected = @"Device isn't disconnected";
static NSString *const JlogIsDisconnected = @"Device is disconnected";
static NSString *const JlogNoAddress = @"No device address";
static NSString *const JlogNoDevice = @"Device not found";
static NSString *const JlogBusy = @"Another command is executiing";
//Read/write
static NSString *const JlogNoArgObj = @"Argument object not found";
static NSString *const JlogNoService = @"Service not found";
static NSString *const JlogNoCharacteristic = @"Characteristic not found";
static NSString *const JlogNoDescriptor = @"Descriptor not found";
static NSString *const JlogWriteValueNotFound = @"Write value not found";
static NSString *const JlogWriteDescriptorValueNotFound = @"Write descriptor value not found";
static NSString *const JlogNoResult = @"Failed to receive command result";

static NSString *const JoperationSetDateTime = @"setDateTime";
static NSString *const JoperationGetDayActivity = @"getDayActivity";
static NSString *const JoperationGetTotalDayActivity = @"getTotalDayActivity";
static NSString *const JoperationGetCurrentActivity = @"getCurrentActivity";
static NSString *const JoperationSetPersonalInformation = @"setPersonalInformation";
static NSString *const JoperationGetPersonalInformation = @"getPersonalInformation";
static NSString *const JoperationSetTargetSteps = @"setTargetSteps";
static NSString *const JoperationGetTargetSteps = @"getTargetSteps";
static NSString *const JoperationVibrate = @"vibrate";
static NSString *const JoperationGetDeviceName = @"getDeviceName";
static NSString *const JoperationGetDeviceInfo = @"getDeviceInfo";
static NSString *const JoperationStartRealTime = @"startRealTime";
static NSString *const JoperationStopRealTime = @"stopRealTime";
static NSString *const JoperationStartHeartRate = @"startHeartRate";
static NSString *const JoperationStopHeartRate = @"stopHeartRate";
static NSString *const JoperationStartBonding = @"startBonding";
static NSString *const JoperationReset = @"reset";


#endif
