#import "JStyle.h"


@implementation JStyle

- (void)pluginInitialize
{
    service = [[NSUUID UUID] initWithUUIDString:JServiceId];
    tx = [[NSUUID UUID] initWithUUIDString:JCharaTX];
    rx = [[NSUUID UUID] initWithUUIDString:JCharaRX];
    commands = [[JStyleCommands alloc] init];
    values = [NSMutableArray array];
    queue = [NSMutableArray array];
    scanner = [[JStyleScanner alloc] init];
}

//tracker-specific logic
- (void) setDateTime:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationSetDateTime;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    NSTimeInterval timeStamp = [cmd.arguments[0] doubleValue] / 1000;
    NSDate *dt = [NSDate dateWithTimeIntervalSince1970: timeStamp];
    
    c.data = [commands setDateTime:dt];
    NSLog(@"JStyle will execute setDateTime: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getDayActivity:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetDayActivity;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 96;
    c.commandTimeout = 15;
    
    
    int dayIndex = [cmd.arguments[0] intValue];
    
    c.data = [commands getDayActivity:dayIndex];
    NSLog(@"JStyle will execute getDayActivity: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getTotalDayActivity:(CDVInvokedUrlCommand *)cmd
{
    int dayIndex = [cmd.arguments[0] intValue];
    if(dayIndex == 0){
        [self getCurrentActivity:cmd];
        return;
    }
    
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetTotalDayActivity;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 2;
    c.data = [commands getTotalDayActivity:dayIndex];
    NSLog(@"JStyle will execute getTotalDayActivity: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getCurrentActivity:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetCurrentActivity;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands getCurrentActivity];
    NSLog(@"JStyle will execute getCurrentActivity: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) setPersonalInformation:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationSetPersonalInformation;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    c.data = [commands setPersonalInformation:cmd.arguments[0]];
    NSLog(@"JStyle will execute setPersonalInformation: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getPersonalInformation:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetPersonalInformation;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    c.data = [commands getPersonalInformation];
    NSLog(@"JStyle will execute getPersonalInformation: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) setTargetSteps:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationSetTargetSteps;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    c.data = [commands setTargetSteps:(unsigned int)[cmd.arguments[0] intValue]];
    NSLog(@"JStyle will execute setTargetSteps: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getTargetSteps:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetTargetSteps;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands getTargetSteps];
    NSLog(@"JStyle will execute getTargetSteps: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) vibrate:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationVibrate;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands vibrate:(int)[cmd.arguments[0] intValue]];
    NSLog(@"JStyle will execute vibrate: %@", c.data);
    [self process];
}

- (void) getDeviceName:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetDeviceName;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands getDeviceName];
    NSLog(@"JStyle will execute getDeviceName: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) getDeviceInfo:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationGetDeviceInfo;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands getDeviceInfo];
    NSLog(@"JStyle will execute getDeviceInfo: %@", c.data);
    
    
    [self enqueue:c];
    [self process];
}

- (void) startBonding:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationStartBonding;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 2;
    c.commandTimeout = 11;
    
    c.data = [commands startBonding];
    NSLog(@"JStyle will execute startBonding: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) startRealTime:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationStartRealTime;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands startRealTime];
    NSLog(@"JStyle will execute startRealTime: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) stopRealTime:(CDVInvokedUrlCommand *)cmd
{
    
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationStopRealTime;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    
    c.data = [commands stopRealTime];
    NSLog(@"JStyle will execute stopRealTime: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) startHeartRate:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationStartHeartRate;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    c.commandTimeout = 20;
    
    c.data = [commands startHeartRate];
    NSLog(@"JStyle will execute startHeartRate: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) stopHeartRate:(CDVInvokedUrlCommand *)cmd
{
    
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationStopHeartRate;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    
    c.data = [commands stopHeartRate];
    NSLog(@"JStyle will execute stopHeartRate: %@", c.data);
    
    [self enqueue:c];
    [self process];
}

- (void) reset:(CDVInvokedUrlCommand *)cmd
{
    JStyleCommand *c = [[JStyleCommand alloc] init];
    c.commandName = JoperationReset;
    c.commandCallback = cmd.callbackId;
    c.rxCounter = 1;
    c.data = [commands reset];
    NSLog(@"JStyle will execute reset: %@", c.data);
    [self enqueue:c];
    [self process];
}


-(void) process
{
    if(currentCommand != nil) return;
    currentCommand = [self dequeue];
    if(currentCommand != nil){
        [self write:currentCommand.data];
    }
}


- (void)write:(NSData *)value
{
    if(currentCommand == nil) return;
    
    //Ensure Bluetooth is enabled
    if (![self isPluginInitialized])
    {        
        NSNumber* request = [NSNumber numberWithBool:YES];
        centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:@{ CBCentralManagerOptionRestoreIdentifierKey:JpluginName, CBCentralManagerOptionShowPowerAlertKey:request }];
        return;
    }
    
    //Ensure device was connected
    if ([self deviceWasNeverConnected])
    {
        [self connectToCurrentAddress];
        return;
    }
    
    //Ensure device is connected
    if (![self isDeviceConnected: address.UUIDString])
    {
        [self connectToCurrentAddress];
        return;
    }
    
    
    //Get service
    CBService* serv = [self getService:[NSDictionary dictionaryWithObjectsAndKeys:service.UUIDString,JkeyServiceUuid, nil]];
    
    //Get characteristic
    CBCharacteristic* characteristic = [self getCharacteristic:[NSDictionary dictionaryWithObjectsAndKeys:tx.UUIDString,JkeyCharacteristicUuid, nil] forService:serv];
    
    //Set wait handle to cancel command if times out
    int timeout = currentCommand.commandTimeout > 0 ? currentCommand.commandTimeout : currentCommand.rxCounter * 3;
    handle = perform_block_after_delay(timeout, ^{
        NSLog(@"JStyle cleans up current command: %@", currentCommand.commandName);
        
        if(currentCommand == nil) {
            [self process];
            return;
        }
        
        if(currentCommand.commandCallback != nil)
        {
            NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorConnect, JkeyError, JlogUnknown, JkeyMessage, nil];
            CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
            [pluginResult setKeepCallbackAsBool:false];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        }
        
        
        [self cleanCurrentCommand];
        [self process];
    });
    
    //Try to write value
//    [activePeripheral writeValue:[self setCounting:1] forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
}


// connection handling
- (void) connectDevice:(CDVInvokedUrlCommand*)command
{
    //Get the arguments
    NSDictionary* obj = [self getArgsObject:command.arguments];
    if ([self isNotArgsObject:obj :command])
    {
        return;
    }
    
    //Get the device address
    address = [self getAddress:obj];
    if (address == nil)
    {
        NSLog(@"JStyle cannot connect: unknown address");
        NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorConnect, JkeyError, JlogNoAddress, JkeyMessage, nil];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [pluginResult setKeepCallbackAsBool:false];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        return;
    }
    NSLog(@"JStyle will try to connect to %@", address);
    
    //remember the callback
    connectDeviceCallback = command.callbackId;
    CDVPluginResult *plr = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:nil];
    [plr setKeepCallback:[NSNumber numberWithBool:YES]];
    
    if(![self isPluginInitialized])
    {
        NSLog(@"JStyle bluetooth is not initialized");
        //By default, request the user to enable Bluetooth
        NSNumber* request = [NSNumber numberWithBool:YES];
        centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:@{ CBCentralManagerOptionRestoreIdentifierKey:JpluginName, CBCentralManagerOptionShowPowerAlertKey:request }];
        return;
    }
    
    //if the device is not currently connected
    if(![self isDeviceConnected:address.UUIDString])
    {
        NSLog(@"JStyle device not connected");
        [self connectToCurrentAddress];
        return;
    }
    
    //Return device information of what was connected
    NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JstatusConnected, JkeyStatus, name, JkeyName, address.UUIDString, JkeyAddress, nil];
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    
    
    
}

- (void) connectToCurrentAddress
{
    // not possible to do connect
    if(address == nil){
        return;
    }
    
    //Get the peripherals and ensure at least one exists
    NSLog(@"JStyle enumerating peripherals");
    NSArray* peripherals = [centralManager retrievePeripheralsWithIdentifiers:@[address]];
    if (peripherals.count == 0)
    {
        NSLog(@"JStyle not found the peripheral with address %@", address);
        NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorConnect, JkeyError, JlogNoDevice, JkeyMessage, nil];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [pluginResult setKeepCallbackAsBool:false];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        return;
    }
    
    //Set the active peripheral
    activePeripheral = peripherals[0];
//    [activePeripheral setDelegate:self];
    
    //Get the name, which could be null
    name = [self formatName:activePeripheral.name];
    
    NSLog(@"JStyle is connecting to peripheral with name %@ and address %@", name, address);
    //Attempt the actual connection
    [centralManager cancelPeripheralConnection:activePeripheral];    
    [centralManager connectPeripheral:activePeripheral options:nil];
}

- (void) scan:(CDVInvokedUrlCommand*)command
{
    [scanner scan:command :self.commandDelegate];
}

//Central Manager Delegates
- (void) centralManagerDidUpdateState:(CBCentralManager *)central
{
    //Decide on error message
    NSString* error = nil;
    switch ([centralManager state])
    {
        case CBCentralManagerStatePoweredOff:
        {
            error = JlogPoweredOff;
            break;
        }
            
        case CBCentralManagerStateUnauthorized:
        {
            error = JlogUnauthorized;
            break;
        }
            
        case CBCentralManagerStateUnknown:
        {
            error = JlogUnknown;
            break;
        }
            
        case CBCentralManagerStateResetting:
        {
            error = JlogResetting;
            break;
        }
            
        case CBCentralManagerStateUnsupported:
        {
            error = JlogUnsupported;
            break;
        }
            
        case CBCentralManagerStatePoweredOn:
        {
            //Bluetooth on!
            break;
        }
    }
    
    NSDictionary* returnObj = nil;
    CDVPluginResult* pluginResult = nil;
    
    //If error message exists, send error
    if (error != nil)
    {
        NSLog(@"JStyle bluetooth initialization error: %@", error);
        returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorEnable, JkeyError, error, JkeyMessage, nil];
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        
        //Clear out the callbacks cause user will need to connect again after Bluetooth is back on
        connectDeviceCallback = nil;
        //[self clearOperationCallbacks];
        activePeripheral = nil;
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
    }
    //Else enabling was successful
    else
    {
        NSLog(@"JStyle bluetooth initialized, connecting");
        [self connectToCurrentAddress];
    }
    
}

- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary *)dict
{
    //CentralManager is unhappy when this callback is not present...
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    //On new connection, reset the operation callbacks
    operationCallbacks = [NSMutableDictionary dictionary];
//    activePeripheral = peripheral;
    NSLog(@"JStyle connected to peripheral with name %@ and address %@", name, address);
    //initiate services discovery
//    NSArray *services = [NSArray arrayWithObject:service];
//    [peripheral setDelegate:self];
//    [activePeripheral setDelegate:self];
//    [activePeripheral discoverServices:nil];
    [peripheral setDelegate:self];
    [peripheral discoverServices:nil];
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"JStyle had an error connecting to peripheral with name %@ and address %@: %@", name, address,error.description);
    //If no connect callback, can't continue
    if (connectDeviceCallback == nil)
    {
        return;
    }
    
    //Return the error message
    NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorConnect, JkeyError, error.description, JkeyMessage, nil];
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
    
    //And clear callback
    connectDeviceCallback = nil;
}

//Peripheral Delegates
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    //If error is set, send back error
    if (error != nil)
    {
        if(error.code == 3){
            NSLog(@"JStyle 'not connected' error when discovering services, trying to reconnect");
            [self connectToCurrentAddress];
            return;
        }
        NSLog(@"JStyle error when discovering services: %@", error.description);
        NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorDiscoverServices, JkeyError, name, JkeyName, [peripheral.identifier UUIDString], JkeyAddress, error.description, JkeyMessage, nil];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        
        return;
    }
    
    //initiate characteristics discovery
    for (CBService* srvice in peripheral.services)
    {
        NSLog(@"JStyle discovered service: %@", srvice);
        
            //Discover the characteristics for the service
            [peripheral discoverCharacteristics:nil forService:srvice];
    }
    
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)srvice error:(NSError *)error
{
    
    //Return error if necessary
    if (error != nil)
    {
        NSLog(@"JStyle error when discovering characteristics: %@", error.description);
        NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorDiscoverCharacteristics, JkeyError, name, JkeyName, [peripheral.identifier UUIDString], JkeyAddress, error.description, JkeyMessage, nil];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        return;
    }
    
//    activePeripheral = peripheral;
    
    //Get array of characteristics with their UUIDs and properties
    NSLog(@"JStyle trying to find RX characteristic: %@", [[CBUUID UUIDWithNSUUID:rx] UUIDString]);
    for (CBCharacteristic* characteristic in srvice.characteristics)
    {
        NSLog(@"JStyle discovered characteristic: %@", characteristic.UUID.UUIDString);
//        if([characteristic.UUID isEqual:[CBUUID UUIDWithNSUUID:rx]]){
//            //Start the subscription
//            NSLog(@"JStyle discovered RX characteristic, subscribing");
//            
//        }
        [peripheral writeValue:[self setCounting:100] forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
    }
}

// condition of weight jump > 10
-(NSData *)setWeight:(int)weight {
    if (weight > 999) {
        weight = 999;
    }
    
    unsigned char y = (unsigned char)weight;
    
    NSData* expectedData3 = nil;
    unsigned char bytes3[] = { 0x03 ,0x0a ,y}; // Set Weight
    expectedData3 = [NSData dataWithBytes:bytes3 length:3];
    return expectedData3;
}

// Set Count Down
-(NSData *)setCounting : (int) goal {
    NSData* expectedData3 = nil;
    unsigned char bytes3[] = { 0x03 ,0x09 ,0x00 ,0X00 ,0XC8 };
    expectedData3 = [NSData dataWithBytes:bytes3 length:5];
    return expectedData3;
}

// Set User Name For BLE Device

-(NSData *)setUserName: (NSString *)userName {
    NSData* expectedData3 = nil;
    unsigned char bytes3[8] = {0x03,0x0b};
    for(int i=0;i<userName.length;i++){
        bytes3[i+2]=[userName characterAtIndex:i];
    }
    expectedData3 = [NSData dataWithBytes:bytes3 length:8];
    return expectedData3;
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
 
    //Create the initial return object
    NSMutableDictionary* returnObj = [NSMutableDictionary dictionaryWithObjectsAndKeys: characteristic.service.UUID.UUIDString, JkeyServiceUuid, [characteristic.UUID UUIDString], JkeyCharacteristicUuid, nil];
    
    if (error != nil)
    {
        NSLog(@"JStyle error when subscribing RX characteristics: %@", error.description);
        
        //Add error information
        [returnObj setValue:JerrorSubscription forKey:JkeyError];
        [returnObj setValue:error.description forKey:JkeyMessage];
        
        //Send error
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        
        return;
    }
    
    //If notifying, send result via connect operation
    if (characteristic.isNotifying)
    {
        if(currentCommand != nil && currentCommand.data != nil)
        {
            NSLog(@"JStyle retrying write for %@ command...", currentCommand);
            [self write:currentCommand.data];
        }
        else
        {
            NSLog(@"JStyle RX characteristic subscribed...");
            //Return device information of what was connected
            [returnObj setValue:JstatusConnected forKey:JkeyStatus];
            [returnObj setValue:name forKey:JkeyName];
            [returnObj setValue:address.UUIDString forKey:JkeyAddress];
            CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
        
            [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        }
    }
    else
    {
        NSLog(@"JStyle RX characteristic unsubscribed...");
        [returnObj setValue:JstatusUnsubscribed forKey:JkeyStatus];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:connectDeviceCallback];
        
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    
    //Create initial return object
    NSMutableDictionary* returnObj = [NSMutableDictionary dictionaryWithObjectsAndKeys: characteristic.service.UUID.UUIDString, JkeyServiceUuid, characteristic.UUID.UUIDString, JkeyCharacteristicUuid, nil];
    
    //If error exists, return error
    if (error != nil)
    {
        NSLog(@"JStyle error when writing to TX characteristics: %@", error.description);
        
        [returnObj setValue:JerrorWrite forKey:JkeyError];
        [returnObj setValue:error.description forKey:JkeyMessage];
        
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
    }
    else
    {
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        NSLog(@"JStyle written to TX characteristic...");
    }
    
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    NSLog(@"JStyle characteristic changed: %@, %@", characteristic.UUID.UUIDString, characteristic.value);
    
    
    //Create the initial return object
    NSMutableDictionary* returnObj = [NSMutableDictionary dictionaryWithObjectsAndKeys: characteristic.service.UUID.UUIDString, JkeyServiceUuid, characteristic.UUID.UUIDString, JkeyCharacteristicUuid, nil];
    
    
    NSObject *retval = [commands startRealTimeResultWithJumBLE:characteristic.value];
    if (!retval) {
        // add value
        [values addObject:characteristic.value];
        currentCommand.rxCounter--;
        
        if(currentCommand.rxCounter < 1)
        {
            //decode command result and pass to callback
            NSObject *retval = [self decodeCommandResult:values];
            if(retval != nil){
                NSLog(@"JStyle sending retval...");
                [returnObj setObject:retval forKey:JkeyValue];
                CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
            }
            else
            {
                NSLog(@"JStyle sending error...");
                [returnObj setValue:JlogNoResult forKey:JkeyMessage];
                CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
            }
            
            if(handle){
                handle(NO);
            } else {
                [self cleanCurrentCommand];
            }
        }
        return;
    }
    [returnObj setObject:retval forKey:JkeyValue];
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
    [pluginResult setKeepCallbackAsBool:YES];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
    if(handle) handle(YES);
    
    return;
    
    //If an error exists...
    if (error != nil)
    {
        NSLog(@"JStyle error when on characteristic value update: %@", error.description);
        
        //Return the error message
        [returnObj setValue:error.description forKey:JkeyMessage];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        
        if(handle){
            handle(NO);
        } else {
            currentCommand = nil;
            [values removeAllObjects];
        }
        
        return;
    }
    
    //check if first of 96 responses say that there will be no data
    if(currentCommand.commandName == JoperationGetDayActivity && values.count == 0)
    {
        if([commands getDayActivityEmptyResponse:characteristic.value])
        {
            NSLog(@"JStyle sending empty retval for getDayActivity...");
            [returnObj setObject:[NSArray array] forKey:JkeyValue];
            CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
            if(handle){
                handle(NO);
            } else {
                [self cleanCurrentCommand];
            }
            return;
        }
    }
    
    if (currentCommand.commandName == JoperationStartRealTime)
    {
        NSObject *retval = [commands startRealTimeResultWithJumBLE:characteristic.value];
        [returnObj setObject:retval forKey:JkeyValue];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
        [pluginResult setKeepCallbackAsBool:YES];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        if(handle) handle(YES);
        
        return;
    }
    
    if (currentCommand.commandName == JoperationStartHeartRate)
    {
        NSObject *retval = [commands startHeartRateResult:characteristic.value];
        [returnObj setObject:retval forKey:JkeyValue];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
        [pluginResult setKeepCallbackAsBool:YES];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        if(handle) handle(YES);
        
        return;
    }
    
    // add value
    [values addObject:characteristic.value];
    currentCommand.rxCounter--;
    
    if(currentCommand.rxCounter < 1)
    {
        //decode command result and pass to callback
        NSObject *retval = [self decodeCommandResult:values];
        if(retval != nil){
            NSLog(@"JStyle sending retval...");
            [returnObj setObject:retval forKey:JkeyValue];
            CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        }
        else
        {
            NSLog(@"JStyle sending error...");
            [returnObj setValue:JlogNoResult forKey:JkeyMessage];
            CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCommand.commandCallback];
        }
        
        if(handle){
            handle(NO);
        } else {
            [self cleanCurrentCommand];
        }
    }
    
}

- (void)isConnected:(CDVInvokedUrlCommand *)command
{
    //See if device is connected
    NSNumber* result = [NSNumber numberWithBool:[self isDeviceConnected:address.UUIDString]];
    
    NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: result, JkeyIsConnected, nil];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
    [pluginResult setKeepCallbackAsBool:false];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

// Helper functions

- (NSObject*) decodeCommandResult:(NSArray*)val
{
    if(currentCommand.commandName == JoperationSetDateTime){
        return [NSNumber numberWithBool:[commands setDateTimeResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationGetDayActivity){
        return [commands getDayActivityResult:val];
    } else if (currentCommand.commandName == JoperationGetTotalDayActivity){
        return [commands getTotalDayActivityResult:val];        
    } else if (currentCommand.commandName == JoperationSetPersonalInformation){
        return [NSNumber numberWithBool:[commands setPersonalInformationResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationGetPersonalInformation){
        return [commands getPersonalInformationResult:[val objectAtIndex:0]];
    } else if (currentCommand.commandName == JoperationSetTargetSteps){
        return [NSNumber numberWithBool:[commands setTargetStepsResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationGetTargetSteps){
        return [NSNumber numberWithInt:[commands getTargetStepsResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationVibrate){
        return [NSNumber numberWithBool:[commands vibrateResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationGetDeviceName){
        return [commands getDeviceNameResult:[val objectAtIndex:0]];
    } else if (currentCommand.commandName == JoperationStopRealTime){
        return [NSNumber numberWithBool:[commands stopRealTimeResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationStopHeartRate){
        return [NSNumber numberWithBool:[commands stopHeartRateResult:[val objectAtIndex:0]]];
    }else if (currentCommand.commandName == JoperationReset){
        return [NSNumber numberWithBool:[commands resetResult:[val objectAtIndex:0]]];
    } else if (currentCommand.commandName == JoperationGetDeviceInfo){
        return [commands getDeviceInfoResult:[val objectAtIndex:0]];
    } else if (currentCommand.commandName == JoperationStartBonding){
        return [NSNumber numberWithBool:[commands startBondingResult:[val objectAtIndex:1]]];
    } else if (currentCommand.commandName == JoperationGetCurrentActivity){
        return [commands getCurrentActivityResult:[val objectAtIndex:0]];
    }
    
    return nil;
}

- (void) cleanCurrentCommand
{
    currentCommand = nil;
    [values removeAllObjects];
}

- (void) enqueue:(JStyleCommand *)cmd
{
    [queue addObject:cmd];
}

- (JStyleCommand*) dequeue
{
    if(queue.count == 0) return nil;
    id headObject = [queue objectAtIndex:0];
    if (headObject != nil) {
        [queue removeObjectAtIndex:0];
    }
    return headObject;
}


- (BOOL) isNotArgsObject:(NSDictionary*) obj :(CDVInvokedUrlCommand *)command
{
    if (obj != nil)
    {
        return false;
    }
    
    NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorArguments, JkeyError, JlogNoArgObj, JkeyMessage, nil];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
    [pluginResult setKeepCallbackAsBool:false];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    
    return true;
}

- (BOOL)isDeviceConnected:(NSString *)addr
{
    return  activePeripheral != nil && activePeripheral.state == CBPeripheralStateConnected && [activePeripheral.identifier.UUIDString isEqualToString:addr] ;
}

- (BOOL)deviceWasNeverConnected
{
    return activePeripheral == nil;
}

- (BOOL)isPluginInitialized
{
    return  centralManager != nil;
}

- (BOOL)isBluetoothEnabled
{
    return  centralManager != nil && centralManager.state == CBCentralManagerStatePoweredOn;
}

//General Helpers
-(NSDictionary*) getArgsObject:(NSArray *)args
{
    if (args == nil)
    {
        return nil;
    }
    
    if (args.count == 1)
    {
        return (NSDictionary *)[args objectAtIndex:0];
    }
    return nil;
}

-(NSData*) getValue:(NSDictionary *) obj
{
    NSString* string = [obj valueForKey:JkeyValue];
    
    if (string == nil)
    {
        return nil;
    }
    
    if (![string isKindOfClass:[NSString class]])
    {
        return nil;
    }
    
    NSData *data = [[NSData alloc] initWithBase64EncodedString:string options:0];
    
    if (data == nil || data.length == 0)
    {
        return nil;
    }
    
    return data;
}

-(void) addValue:(NSData *) bytes toDictionary:(NSMutableDictionary *) obj
{
    NSString *string = [bytes base64EncodedStringWithOptions:0];
    
    if (string == nil || string.length == 0)
    {
        return;
    }
    
    [obj setValue:string forKey:JkeyValue];
}

-(NSMutableArray*) getUuids:(NSDictionary *) dictionary forType:(NSString*) type
{
    NSMutableArray* uuids = [[NSMutableArray alloc] init];
    
    NSArray* checkUuids = [dictionary valueForKey:type];
    
    if (checkUuids == nil)
    {
        return nil;
    }
    
    if (![checkUuids isKindOfClass:[NSArray class]])
    {
        return nil;
    }
    
    for (NSString* checkUuid in checkUuids)
    {
        CBUUID* uuid = [CBUUID UUIDWithString:checkUuid];
        
        if (uuid != nil)
        {
            [uuids addObject:uuid];
        }
    }
    
    if (uuids.count == 0)
    {
        return nil;
    }
    
    return uuids;
}

-(NSUUID*) getAddress:(NSDictionary *)obj
{
    NSString* addressString = [obj valueForKey:JkeyAddress];
    
    if (addressString == nil)
    {
        return nil;
    }
    
    if (![addressString isKindOfClass:[NSString class]])
    {
        return nil;
    }
    
    return [[NSUUID UUID] initWithUUIDString:addressString];
}

-(NSNumber*) getRequest:(NSDictionary *)obj
{
    NSNumber* request = [obj valueForKey:JkeyRequest];
    
    if (request == nil)
    {
        return [NSNumber numberWithBool:NO];
    }
    
    if (![request isKindOfClass:[NSNumber class]])
    {
        return [NSNumber numberWithBool:NO];
    }
    
    return request;
}

-(int) getWriteType:(NSDictionary *)obj
{
    NSString* writeType = [obj valueForKey:JkeyType];
    
    if (writeType == nil || [writeType compare:JwriteTypeNoResponse])
    {
        return CBCharacteristicWriteWithResponse;
    }
    return CBCharacteristicWriteWithoutResponse;
}

-(NSObject*) formatName:(NSString*)name
{
    if (name != nil)
    {
        return name;
    }
    
    return [NSNull null];
}

-(CBService*) getService:(NSDictionary *)obj
{
    if (activePeripheral.services == nil)
    {
        return nil;
    }
    
    NSString* uuidString = [obj valueForKey:JkeyServiceUuid];
    
    if (uuidString == nil)
    {
        return nil;
    }
    
    if (![uuidString isKindOfClass:[NSString class]])
    {
        return nil;
    }
    
    CBUUID* uuid = [CBUUID UUIDWithString:uuidString];
    
    if (uuid == nil)
    {
        return nil;
    }
    
    CBService* service = nil;
    
    for (CBService* item in activePeripheral.services)
    {
        if ([item.UUID isEqual: uuid])
        {
            service = item;
        }
    }
    
    return service;
}

-(CBCharacteristic*) getCharacteristic:(NSDictionary *) obj forService:(CBService*) service
{
    if (service.characteristics == nil)
    {
        return nil;
    }
    
    NSString* uuidString = [obj valueForKey:JkeyCharacteristicUuid];
    
    if (uuidString == nil)
    {
        return nil;
    }
    
    if (![uuidString isKindOfClass:[NSString class]])
    {
        return nil;
    }
    
    CBUUID* uuid = [CBUUID UUIDWithString:uuidString];
    
    if (uuid == nil)
    {
        return nil;
    }
    
    CBCharacteristic* characteristic = nil;
    
    NSLog(@"%@", service.characteristics);
    
    for (CBCharacteristic* item in service.characteristics)
    {
        if ([item.UUID isEqual: uuid])
        {
            characteristic = item;
        }
    }
    
    return characteristic;
}

-(CBDescriptor*) getDescriptor:(NSDictionary *) obj forCharacteristic:(CBCharacteristic*) characteristic
{
    if (characteristic.descriptors == nil)
    {
        return nil;
    }
    
    NSString* uuidString = [obj valueForKey:JkeyDescriptorUuid];
    
    if (uuidString == nil)
    {
        return nil;
    }
    
    if (![uuidString isKindOfClass:[NSString class]])
    {
        return nil;
    }
    
    CBUUID* uuid = [CBUUID UUIDWithString:uuidString];
    
    if (uuid == nil)
    {
        return nil;
    }
    
    CBDescriptor* descriptor = nil;
    
    for (CBDescriptor* item in characteristic.descriptors)
    {
        if ([item.UUID isEqual: uuid])
        {
            descriptor = item;
        }
    }
    
    return descriptor;
}

-(NSMutableDictionary*) getProperties:(CBCharacteristic*) characteristic
{
    NSMutableDictionary* propertiesObject = [NSMutableDictionary dictionary];
    
    CBCharacteristicProperties properties = characteristic.properties;
    
    if ((properties & CBCharacteristicPropertyBroadcast) == CBCharacteristicPropertyBroadcast)
    {
        [propertiesObject setValue:@YES forKey:JpropertyBroadcast];
    }
    
    if ((properties & CBCharacteristicPropertyRead) == CBCharacteristicPropertyRead)
    {
        [propertiesObject setValue:@YES forKey:JpropertyRead];
    }
    
    if ((properties & CBCharacteristicPropertyWriteWithoutResponse) == CBCharacteristicPropertyWriteWithoutResponse)
    {
        [propertiesObject setValue:@YES forKey:JpropertyWriteWithoutResponse];
    }
    
    if ((properties & CBCharacteristicPropertyWrite) == CBCharacteristicPropertyWrite)
    {
        [propertiesObject setValue:@YES forKey:JpropertyWrite];
    }
    
    if ((properties & CBCharacteristicPropertyNotify) == CBCharacteristicPropertyNotify)
    {
        [propertiesObject setValue:@YES forKey:JpropertyNotify];
    }
    
    if ((properties & CBCharacteristicPropertyIndicate) == CBCharacteristicPropertyIndicate)
    {
        [propertiesObject setValue:@YES forKey:JpropertyIndicate];
    }
    
    if ((properties & CBCharacteristicPropertyAuthenticatedSignedWrites) == CBCharacteristicPropertyAuthenticatedSignedWrites)
    {
        [propertiesObject setValue:@YES forKey:JpropertyAuthenticatedSignedWrites];
    }
    
    if ((properties & CBCharacteristicPropertyExtendedProperties) == CBCharacteristicPropertyExtendedProperties)
    {
        [propertiesObject setValue:@YES forKey:JpropertyExtendedProperties];
    }
    
    if ((properties & CBCharacteristicPropertyNotifyEncryptionRequired) == CBCharacteristicPropertyNotifyEncryptionRequired)
    {
        [propertiesObject setValue:@YES forKey:JpropertyNotifyEncryptionRequired];
    }
    
    if ((properties & CBCharacteristicPropertyIndicateEncryptionRequired) == CBCharacteristicPropertyIndicateEncryptionRequired)
    {
        [propertiesObject setValue:@YES forKey:JpropertyIndicateEncryptionRequired];
    }
    
    return propertiesObject;
}

@end