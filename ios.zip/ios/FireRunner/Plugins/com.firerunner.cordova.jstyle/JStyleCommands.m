//
//  JStyleCommands.m
//  FireRunner
//
//  Created by Artem Lakomov on 2/28/15.
//
//

#import "JStyleCommands.h"

@implementation JStyleCommands

- (NSData*) setDateTime:(NSDate*)dateTime
{
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSUInteger componentFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSDateComponents *components = [cal components:componentFlags fromDate:dateTime];
    
    const unsigned char bytes[] = {
        0x01,
        [self toBCD: (int)(components.year - 2000)],
        [self toBCD: (int)components.month],
        [self toBCD: (int)components.day],
        [self toBCD: (int)components.hour],
        [self toBCD: (int)components.minute],
        [self toBCD: (int)components.second],
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}


- (BOOL) setDateTimeResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x01;
}


- (NSData*) getDayActivity:(int)dayIndex
{
    const unsigned char bytes[] = {
        0x43,
        [self toBCD: dayIndex],
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSArray*) getDayActivityResult:(NSArray*)values
{
    NSData *arr = [values objectAtIndex:0];
    unsigned char* bytes = (unsigned char*)arr.bytes;
    if(bytes[0] == 0xC3)return nil;
    
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:values.count];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    
    for(int i = 0; i < values.count; i++)
    {
        
        unsigned char* data = [self fromBCDArray:(unsigned char*)[[values objectAtIndex:i] bytes]];
        //unsigned char* data = (unsigned char*)[[values objectAtIndex:i] bytes];
        NSMutableDictionary *item = [NSMutableDictionary dictionary];
        
        int interval = data[5];
        int hh = interval * 15 / 60;
        int mm = interval * 15 - hh * 60;
        
        int day = (int)data[4];
        int month = (int)data[3];
        int year = 2000 + (int)data[2];
        
        
        
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        
        [components setTimeZone:[NSTimeZone systemTimeZone]];
        [components setDay:day];
        [components setMonth:month];
        [components setYear:year];
        [components setHour:hh];
        [components setMinute:mm];
        
        NSDate *date = [calendar dateFromComponents:components];
        
        [item setObject:[dateFormatter stringFromDate:date] forKey:@"date"];
        [item setObject:[NSNumber numberWithInt:interval] forKey:@"interval"];
        
        //activity or sleep
        if (data[6] == 0) {
            int calories = (int)(data[8]*256+data[7]) / 100;
            [item setObject:[NSNumber numberWithInt:calories] forKey:@"calories"];
            int walkingSteps = data[10]*256+data[9];
            [item setObject:[NSNumber numberWithInt:walkingSteps] forKey:@"walkingSteps"];
            int runningSteps = data[14]*256+data[13];
            [item setObject:[NSNumber numberWithInt:runningSteps] forKey:@"runningSteps"];
            int walkingMeters = data[12]*256+data[11];
            [item setObject:[NSNumber numberWithInt:walkingMeters] forKey:@"walkingMeters"];
        } else {
            int arrLen = 8;
            int sleep = 0;
            for (int j = 6; j <= arrLen; j++) {
                sleep += data[j];
            }
            int sleepQualityPercent = round((128 - sleep / arrLen) / 1.28); // calc % sleep quality. sleep is 1 to 128,  1 is the best
            [item setObject:[NSNumber numberWithInt:sleepQualityPercent] forKey:@"sleep"];
        }
        
        [result addObject:item];
    }
    
    return result;
}

- (BOOL) getDayActivityEmptyResponse:(NSData*)value
{
    unsigned char *bytes = (unsigned char*)([value bytes]);
    return bytes[0] == 0x43 && bytes[1] == 0xFF;
}

- (NSData*) getTotalDayActivity:(int)dayIndex
{
    const unsigned char bytes[] = {
        0x07,
        [self toBCD: dayIndex],
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) getTotalDayActivityResult:(NSArray*)values
{
    unsigned char* bytes1 = (unsigned char*)[[values objectAtIndex:0] bytes];
    if(bytes1[0] == 0x87)return nil;
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayRunningSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayRunningMinutes"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingMinutes"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingMeters"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"calories"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"sleep"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"lastRunSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"lastRunMinutes"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    if(bytes1[3] != 0)
    {
        unsigned char* bytes2 = (unsigned char*)[[values objectAtIndex:1] bytes];
        
        int day = (int)bytes1[5];
        int month = (int)bytes1[4];
        int year = 2000 + (int)bytes1[3];
        
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        
        [components setTimeZone:[NSTimeZone systemTimeZone]];
        [components setDay:day];
        [components setMonth:month];
        [components setYear:year];
        
        NSDate *date = [calendar dateFromComponents:components];
        
        [item setObject:[dateFormatter stringFromDate:date] forKey:@"date"];
        int walkingSteps = (bytes1[8] & 0xFF) + ((bytes1[7] & 0xFF) << 8) + ((bytes1[6] & 0xFF) << 16);
        [item setObject:[NSNumber numberWithInt:walkingSteps] forKey:@"todayWalkingSteps"];
        int runningSteps = (bytes1[11] & 0xFF) + ((bytes1[10] & 0xFF) << 8) + ((bytes1[9] & 0xFF) << 16);
        [item setObject:[NSNumber numberWithInt:runningSteps] forKey:@"todayRunningSteps"];
        int calories = (int)((bytes1[14] & 0xFF + ((bytes1[13] & 0xFF) << 8) + ((bytes1[11] & 0xFF) << 16)) / 100);
        [item setObject:[NSNumber numberWithInt:calories] forKey:@"calories"];
        int walkingMeters = (bytes2[8] & 0xFF) + ((bytes2[7] & 0xFF) << 8) + ((bytes2[6] & 0xFF) << 16);
        [item setObject:[NSNumber numberWithInt:walkingMeters] forKey:@"todayWalkingMeters"];
        int walkingMinutes = (bytes2[10] & 0xFF) + ((bytes2[9] & 0xFF) << 8);
        [item setObject:[NSNumber numberWithInt:walkingMinutes] forKey:@"todayWalkingMinutes"];
        
    }
    
    return item;
}

- (NSData*) setPersonalInformation:(NSDictionary*)bio
{
    unsigned char gender = [[bio objectForKey:@"gender"] isEqualToString:@"M"] ? 1 : 0 ;
    int age = [[bio objectForKey:@"age"] intValue];
    int height = [[bio objectForKey:@"height"] intValue];
    int weight = [[bio objectForKey:@"weight"] intValue];
    int stride = [[bio objectForKey:@"stride"] intValue];
    
    const unsigned char bytes[] = {
        0x02,
        gender,
        age,
        height,
        weight,
        stride,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) setPersonalInformationResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x02;
}


- (NSData*) getPersonalInformation
{
    const unsigned char bytes[] = {
        0x42,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) getPersonalInformationResult:(NSData*)value
{
    unsigned char* bytes = (unsigned char*)[value bytes];
    if(bytes[0] == 0xC2)return nil;
    
    NSMutableString *genderString = [NSMutableString string];
    if(bytes[1] == 0)
    {
        [genderString setString:@"F"];
    }
    else
    {
        [genderString setString:@"M"];
    }
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:genderString forKey:@"gender"];
    [item setObject:[NSNumber numberWithInt:bytes[2]] forKey:@"age"];
    [item setObject:[NSNumber numberWithInt:bytes[3]] forKey:@"height"];
    [item setObject:[NSNumber numberWithInt:bytes[4]] forKey:@"weight"];
    [item setObject:[NSNumber numberWithInt:bytes[5]] forKey:@"stride"];
    
    return item;
}

- (NSData*) setTargetSteps:(unsigned int)steps
{
    unsigned char array[3];
    array[0] = steps >> 16 & 0xFF;
    array[1] = steps >> 8  & 0xFF;
    array[2] = steps       & 0xFF;
    
    const unsigned char bytes[] = {
        0x0B,
        array[0],
        array[1],
        array[2],
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) setTargetStepsResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x0B;
}

- (NSData*) getTargetSteps
{
    const unsigned char bytes[] = {
        0x4B,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (unsigned int) getTargetStepsResult:(NSData*)value
{
    unsigned char* bytes = (unsigned char*)[value bytes];
    unsigned int target = bytes[3] + (bytes[2] << 8) + (bytes[1] << 16);
    return target;
}

- (NSData*) vibrate:(int)sec
{
    const unsigned char bytes[] = {
        0x36,
        sec,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) vibrateResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x36;
}

- (NSData*) getDeviceName
{
    const unsigned char bytes[] = {
        0x3E,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSString*) getDeviceNameResult:(NSData*)value
{
    return [[NSString alloc] initWithData:value encoding:NSASCIIStringEncoding];
}

- (NSData*) getDeviceInfo
{
    const unsigned char bytes[] = {
        0x40,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) getDeviceInfoResult:(NSData*)value
{
    unsigned char* bytes = (unsigned char*)[value bytes];
    NSDictionary *result = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:bytes[1]], @"device",  [NSNumber numberWithInt:bytes[2]], @"version", nil];
    return result;
}

- (NSData*) startRealTime
{
    const unsigned char bytes[] = {
        0x09,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSData*) stopRealTime
{
    const unsigned char bytes[] = {
        0x0A,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) startRealTimeResult:(NSData*)value
{
    unsigned char* bytes = (unsigned char*)[value bytes];
    int steps = bytes[3] + (bytes[2] << 8) + (bytes[1] << 16);
    int runningSteps = bytes[6] + (bytes[5] << 8) + (bytes[4] << 16);
    int calories = bytes[9] + (bytes[8] << 8) + (bytes[7] << 16);
    int meters = bytes[12] + (bytes[11] << 8) + (bytes[10] << 16);
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:[NSNumber numberWithInt:steps] forKey:@"lastRunSteps"];
    [item setObject:[NSNumber numberWithInt:runningSteps] forKey:@"lastRunRunningSteps"];
    [item setObject:[NSNumber numberWithInt:meters] forKey:@"lastRunMeters"];
    [item setObject:[NSNumber numberWithInt:calories] forKey:@"calories"];
    
    return item;
}

- (NSDictionary*) startRealTimeResultWithJumBLE:(NSData*)value {
    unsigned char* bytes = (unsigned char*)[value bytes];
//    int productId = (bytePtr[0] & 0xf0) >> 4 ;
//    int exeriseType = (bytePtr[0] & 0x0e) >> 1 ;
//    int exeriseMode = ((bytePtr[0] & 0x01) << 1)|((bytePtr[1] & 0x80) >>7) ;
//    int year = (bytePtr[1] & 0x7c) >> 2 ;
//    int month = ((bytePtr[1] & 0x07 ) <<2) | ( (bytePtr[2] & 0xC0)>>6) ;
//    int date = (bytePtr[2] & 0x7c ) >> 1 ;
//    int hour = (( bytePtr[2] & 0x01) <<4)| ((bytePtr[3] & 0xF0)>>4) ;
//    int minute = ((bytePtr[3] & 0x0f) <<2) | ((bytePtr[4] & 0xC0) >>6);
//    int second = (bytePtr[4] &0x3F);
//    int exhour = (bytePtr[5] & 0xf8) >>3;
//    int exminute = ((bytePtr[5] & 0x07)<<3) |( (bytePtr[6] & 0xe0)>>5);
//    int exsecond = (( bytePtr[6] & 0x1f) <<1) | ((bytePtr[7] & 0x80) >>7);
    
    if (!bytes) {
        return nil;
    }
    
    int extimes = ((bytes[7] & 0x7f) <<8) | bytes[8];
    int excalogires = bytes[9];
    int realData = (bytes[5] & 0xF0) | (bytes[6] & 0xF0);
    
    if (extimes != 0) {
        realData = extimes;
    }
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:[NSNumber numberWithInt:realData] forKey:@"lastRunSteps"];
    [item setObject:[NSNumber numberWithInt:realData] forKey:@"lastRunRunningSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"lastRunMeters"];
    [item setObject:[NSNumber numberWithInt:excalogires] forKey:@"calories"];
    
    return item;
}

- (BOOL) stopRealTimeResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x0A;
}

- (NSData*) startHeartRate
{
    const unsigned char bytes[] = {
        0x99,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) startHeartRateResult:(NSData*)value
{
    NSMutableArray *arr = [NSMutableArray array];
    unsigned char* bytes = (unsigned char*)[value bytes];
    for(int i = 1; i < 15; i++)
    {
        [arr addObject:[NSNumber numberWithInt:bytes[i]]];
    }
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:arr forKey:@"heartRate"];
    
    return item;
}

- (NSData*) stopHeartRate
{
    const unsigned char bytes[] = {
        0x98,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) stopHeartRateResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0xa8;
}


- (NSData*) reset
{
    const unsigned char bytes[] = {
        0x2E,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) resetResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x2E;
}

- (NSData*) startBonding
{
    const unsigned char bytes[] = {
        0x20,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (BOOL) startBondingResult:(NSData*)value
{
    return ((unsigned char*)[value bytes])[0] == 0x21;
}

- (NSData*) getCurrentActivity
{
    const unsigned char bytes[] = {
        0x48,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        [self CRC:bytes]
    };
    
    NSData *data = [NSData dataWithBytes:bytes length:16];
    return data;
}

- (NSDictionary*) getCurrentActivityResult:(NSData*)value
{
    unsigned char* bytes1 = (unsigned char*)[value bytes];
    if(bytes1[0] == 0x87)return nil;
    
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayRunningSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayRunningMinutes"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingMinutes"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"todayWalkingMeters"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"calories"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"sleep"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"lastRunSteps"];
    [item setObject:[NSNumber numberWithInt:0] forKey:@"lastRunMinutes"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    
    int walkingSteps = (bytes1[3] & 0xFF) + ((bytes1[2] & 0xFF) << 8) + ((bytes1[1] & 0xFF) << 16);
    [item setObject:[NSNumber numberWithInt:walkingSteps] forKey:@"todayWalkingSteps"];
    int runningSteps = (bytes1[6] & 0xFF) + ((bytes1[5] & 0xFF) << 8) + ((bytes1[4] & 0xFF) << 16);
    [item setObject:[NSNumber numberWithInt:runningSteps] forKey:@"todayRunningSteps"];
    int calories = (int)((bytes1[9] & 0xFF + ((bytes1[8] & 0xFF) << 8) + ((bytes1[7] & 0xFF) << 16)) / 100);
    [item setObject:[NSNumber numberWithInt:calories] forKey:@"calories"];
    int walkingMeters = ((bytes1[12] & 0xFF) + ((bytes1[11] & 0xFF) << 8) + ((bytes1[10] & 0xFF) << 16)) * 10;
    [item setObject:[NSNumber numberWithInt:walkingMeters] forKey:@"todayWalkingMeters"];
    int walkingMinutes = (bytes1[14] & 0xFF) + ((bytes1[13] & 0xFF) << 8);
    [item setObject:[NSNumber numberWithInt:walkingMinutes] forKey:@"todayWalkingMinutes"];    
    
    return item;
}



- (unsigned int) fromBCD:(unsigned char)bcd{
    
    unsigned int result = 0;
    return result * 100 + (bcd >> 4) * 10 + (bcd & 15);
    //return (bcd & 0xF) + ((bcd & 0xF0) >> 4) * 10;
}

- (unsigned char) toBCD:(unsigned int)dec
{
    unsigned int result = 0;
    int shift = 0;
    
    while (dec)
    {
        result +=  (dec % 10) << shift;
        dec = dec / 10;
        shift += 4;
    }
    return result;
}

- (unsigned char) CRC:(unsigned char[])command
{
    unsigned char crc = 0;
    for (int i = 0; i < 15; i++) {
        crc += command[i];
    }
    return crc & 0xFF;
}

- (unsigned char*) fromBCDArray:(unsigned char*)array
{
    for(int i = 0; i < 16; i++)
    {
        array[i] = [self fromBCD:(int)array[i]];
    }
    return array;
}

@end
