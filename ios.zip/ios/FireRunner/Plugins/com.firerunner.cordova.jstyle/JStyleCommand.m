//
//  JStyleCommand.m
//  FireRunner
//
//  Created by Artem Lakomov on 6/22/15.
//
//

#import "JStyleCommand.h"



@implementation JStyleCommand

@synthesize data, commandCallback, commandName,rxCounter, commandTimeout;



@end
