//
//  JStyleScanner.m
//  FireRunner
//
//  Created by Artem Lakomov on 4/11/15.
//
//

#import "JStyleScanner.h"

@implementation JStyleScanner

- (void) scan:(CDVInvokedUrlCommand *)command :(CDVCommandDelegateImpl*)delegate
{
    if(isScanning) return;
    isScanning = true;
    
    scanCommand = command;
    scanDelegate = delegate;
    timeout = [command.arguments[0] intValue];
    
    if(centralManager == nil)
    {
        NSLog(@"JStyle bluetooth is not initialized");
        //By default, request the user to enable Bluetooth
        NSNumber* request = [NSNumber numberWithBool:YES];
        centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:@{ CBCentralManagerOptionRestoreIdentifierKey:JScannerName, CBCentralManagerOptionShowPowerAlertKey:request }];
    } else {
        [self startScan];
    }
}

- (void) startScan
{
    discoveredDevices = [NSMutableArray array];    
    [centralManager scanForPeripheralsWithServices:[NSArray arrayWithObject:[CBUUID UUIDWithString:JServiceId]] options:nil];
    //Set wait handle to cancel command if times out
    handle = perform_block_after_delay(timeout, ^{
        NSLog(@"JStyle scanner timeout,  sending result");
        [self finishScan];
    });
    NSLog(@"JStyle bluetooth scanning started");
}

- (void) finishScan
{
    [centralManager stopScan];
    
    NSArray * connectedPeritherals = [centralManager retrieveConnectedPeripheralsWithServices:[NSArray arrayWithObject:[CBUUID UUIDWithString:JServiceId]]];
    for (int i = 0; i < connectedPeritherals.count; i++) {
        CBPeripheral *peripheral = connectedPeritherals[i];
        
        NSObject* name = [self formatName:peripheral.name];
        NSMutableDictionary* deviceObj = [NSMutableDictionary dictionaryWithObjectsAndKeys: name, JkeyName, peripheral.identifier.UUIDString, JkeyAddress, nil];
        
        [discoveredDevices addObject:deviceObj];
    }
    
    isScanning = false;
    timeout = 0;
    
    NSDictionary* returnObj = [NSDictionary dictionaryWithObjectsAndKeys: discoveredDevices, JkeyValue, nil];
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:returnObj];
    [scanDelegate sendPluginResult:pluginResult callbackId:scanCommand.callbackId];
    
    discoveredDevices = nil;
    scanCommand = nil;
    scanDelegate = nil;
    
    NSLog(@"JStyle bluetooth scan complete...");
}

//Central Manager Delegates
- (void) centralManagerDidUpdateState:(CBCentralManager *)central
{
    //Decide on error message
    NSString* error = nil;
    switch ([centralManager state])
    {
        case CBCentralManagerStatePoweredOff:
        {
            error = JlogPoweredOff;
            break;
        }
        
        case CBCentralManagerStateUnauthorized:
        {
            error = JlogUnauthorized;
            break;
        }
        
        case CBCentralManagerStateUnknown:
        {
            error = JlogUnknown;
            break;
        }
        
        case CBCentralManagerStateResetting:
        {
            error = JlogResetting;
            break;
        }
        
        case CBCentralManagerStateUnsupported:
        {
            error = JlogUnsupported;
            break;
        }
        
        case CBCentralManagerStatePoweredOn:
        {
            //Bluetooth on!
            break;
        }
    }
    
    NSDictionary* returnObj = nil;
    CDVPluginResult* pluginResult = nil;
    
    //If error message exists, send error
    if (error != nil)
    {
        NSLog(@"JStyle bluetooth initialization error: %@", error);
        returnObj = [NSDictionary dictionaryWithObjectsAndKeys: JerrorEnable, JkeyError, error, JkeyMessage, nil];
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [scanDelegate sendPluginResult:pluginResult callbackId:scanCommand.callbackId];
    }
    //Else enabling was successful
    else
    {
        NSLog(@"JStyle bluetooth initialized, start scanning");
        [self startScan];
    }
    
}

- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary *)dict
{
    //CentralManager is unhappy when this callback is not present...
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    for (int i = 0; i < discoveredDevices.count; i++) {
        if([[discoveredDevices[i] valueForKey:JkeyAddress] isEqualToString:peripheral.identifier.UUIDString]){
            return;
        }
    }
    
    //Return all the device details
    NSObject* name = [self formatName:peripheral.name];
    NSData* data = [advertisementData valueForKey:CBAdvertisementDataManufacturerDataKey];
    NSString* dataString = [data base64EncodedStringWithOptions:0];
    NSMutableDictionary* deviceObj = [NSMutableDictionary dictionaryWithObjectsAndKeys: name, JkeyName, peripheral.identifier.UUIDString, JkeyAddress, RSSI, JkeyRssi, dataString, JkeyAdvertisement, nil];
    
    NSLog(@"JStyle bluetooth scan discovered device: %@", deviceObj);
    
    [discoveredDevices addObject:deviceObj];
}


-(NSObject*) formatName:(NSString*)name
{
    if (name != nil)
    {
        return name;
    }
    
    return [NSNull null];
}
@end
