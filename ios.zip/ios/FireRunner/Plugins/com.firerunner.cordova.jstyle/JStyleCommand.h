//
//  JStyleCommand.h
//  FireRunner
//
//  Created by Artem Lakomov on 6/22/15.
//
//

#import <Foundation/Foundation.h>
#import <Cordova/CDVPlugin.h>

@interface JStyleCommand : NSObject

@property (nonatomic, retain) NSString* commandName;
@property (nonatomic, retain) NSString * commandCallback;
@property int rxCounter;
@property int commandTimeout;
@property (nonatomic, retain) NSData * data;

@end
