#import "SpacemanBlocks.h"
#import <Cordova/CDVPlugin.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "JStyleConstants.h"
#import "JStyleCommands.h"
#import "JStyleCommand.h"
#import "JStyleScanner.h"

@interface JStyle : CDVPlugin <CBCentralManagerDelegate, CBPeripheralDelegate> {
    NSUUID* address;
    NSUUID* service;
    NSUUID* tx;
    NSUUID* rx;
    NSObject* name;
    NSString* connectDeviceCallback;
    JStyleCommand* currentCommand;
    NSMutableDictionary* operationCallbacks;
    NSMutableArray* values;
    NSMutableArray* queue;
    CBCentralManager *centralManager;    
    CBPeripheral* activePeripheral;
    JStyleCommands* commands;
    SMDelayedBlockHandle handle;
    JStyleScanner *scanner;
}

- (void) scan:(CDVInvokedUrlCommand *)command;
- (void) isConnected:(CDVInvokedUrlCommand *)command;
- (void) connectDevice:(CDVInvokedUrlCommand*)command;
- (void) setDateTime:(CDVInvokedUrlCommand*)command;
- (void) getDayActivity:(CDVInvokedUrlCommand*)command;
- (void) getTotalDayActivity:(CDVInvokedUrlCommand*)command;
- (void) getCurrentActivity:(CDVInvokedUrlCommand*)command;
- (void) setPersonalInformation:(CDVInvokedUrlCommand*)command;
- (void) getPersonalInformation:(CDVInvokedUrlCommand*)command;
- (void) setTargetSteps:(CDVInvokedUrlCommand*)command;
- (void) getTargetSteps:(CDVInvokedUrlCommand*)command;
- (void) startRealTime:(CDVInvokedUrlCommand*)command;
- (void) stopRealTime:(CDVInvokedUrlCommand*)command;
- (void) startHeartRate:(CDVInvokedUrlCommand*)command;
- (void) stopHeartRate:(CDVInvokedUrlCommand*)command;
- (void) vibrate:(CDVInvokedUrlCommand*)command;
- (void) getDeviceName:(CDVInvokedUrlCommand*)command;
- (void) getDeviceInfo:(CDVInvokedUrlCommand*)command;
- (void) startBonding:(CDVInvokedUrlCommand*)command;
- (void) reset:(CDVInvokedUrlCommand*)command;


@end
