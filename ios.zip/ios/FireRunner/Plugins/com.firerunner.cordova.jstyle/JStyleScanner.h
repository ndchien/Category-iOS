#import "SpacemanBlocks.h"
#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVCommandDelegateImpl.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <Foundation/Foundation.h>
#import "JStyleConstants.h"

@interface JStyleScanner : NSObject <CBCentralManagerDelegate, CBPeripheralDelegate>
{
    CBCentralManager *centralManager;
    CDVInvokedUrlCommand *scanCommand;
    CDVCommandDelegateImpl *scanDelegate;
    SMDelayedBlockHandle handle;
    NSMutableArray *discoveredDevices;
    BOOL isScanning;
    int timeout;
}

- (void) scan:(CDVInvokedUrlCommand *)command :(CDVCommandDelegateImpl*)delegate;

@end
