#import "FacebookSharePlugin.h"

@implementation FacebookSharePlugin

- (void)applicationDidBecomeActive {
    // Call the 'activateApp' method to log an app event for use in analytics and advertising reporting.
    [FBSDKAppEvents activateApp];
}

- (void) shareActivity:(CDVInvokedUrlCommand *)cmd
{
    currentCallback = cmd.callbackId;
    
    NSDictionary *activity = cmd.arguments[0];
    NSString *activityUrl = cmd.arguments[1];
    NSString *imageUrl = cmd.arguments[2];
    NSString *description = cmd.arguments[3];
    BOOL isOwnerSharing = [cmd.arguments[4] boolValue];
    NSArray *data = [activity objectForKey:@"data"];
    NSString *ownerId = nil;
    if([activity objectForKey:@"owner"] != nil) [[[activity objectForKey:@"owner"] objectForKey:@"fbId"] stringValue];
    
    UIViewController *rootViewController = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
    dialog.fromViewController = rootViewController;
    dialog.delegate = self;
    
    
    if(isOwnerSharing){
        NSDictionary *properties = @{
                                     //@"fb:profile_id": ownerId,
                                     @"og:type": @"fitness.course",
                                     @"og:see_also": [NSArray arrayWithObject:activityUrl],
                                     //@"og:image": imageUrl,
                                     @"og:title": [activity objectForKey:@"title"],
                                     @"og:description": description,
                                     @"fitness:duration:value": [activity objectForKey:@"duration"],
                                     @"fitness:duration:units": @"s",
                                     @"fitness:distance:value": [activity objectForKey:@"distance"],
                                     @"fitness:distance:units": @"km",
                                     @"fitness:speed:value": [NSNumber numberWithDouble:[[activity objectForKey:@"speed"] doubleValue] * 1000 / 3600],
                                     @"fitness:speed:units": @"m/s",
                                     @"fitness:calories": [activity objectForKey:@"calories"],
                                     @"fitness:metrics:location:latitude": [data[0] objectForKey:@"lat"],
                                     @"fitness:metrics:location:longitude": [data[0] objectForKey:@"lon"]
                                     };
        
        FBSDKShareOpenGraphObject *object = [FBSDKShareOpenGraphObject objectWithProperties:properties];
        FBSDKShareOpenGraphAction *action = [[FBSDKShareOpenGraphAction alloc] init];
        action.actionType = @"fitness.runs";
        if([[activity objectForKey:@"type"] isEqualToString:@"biking"]){
            action.actionType = @"fitness.bikes";
        } else if([[activity objectForKey:@"type"] isEqualToString:@"walking"]){
            action.actionType = @"fitness.walks";
        }
        [action setObject:object forKey:@"fitness:course"];
        
        
        FBSDKShareOpenGraphContent *ogcontent = [[FBSDKShareOpenGraphContent alloc] init];
        ogcontent.action = action;
        ogcontent.previewPropertyName = @"fitness:course";
        
        if(ownerId != nil)
        ogcontent.peopleIDs = [NSArray arrayWithObject:ownerId];
        
        dialog.shareContent = ogcontent;
        dialog.mode = FBSDKShareDialogModeAutomatic;
        
    } else {
        
        FBSDKShareLinkContent *content = [[FBSDKShareLinkContent alloc] init];
        content.contentURL = [NSURL URLWithString:activityUrl];
        content.contentTitle = [activity objectForKey:@"title"];
        content.contentDescription = description;
        content.imageURL = [NSURL URLWithString:imageUrl];
        dialog.shareContent = content;
        dialog.mode = FBSDKShareDialogModeShareSheet;
        
    }
    
    [dialog show];
    
}

- (void) shareEvent:(CDVInvokedUrlCommand *)cmd
{
    currentCallback = cmd.callbackId;
    
    NSDictionary *event = cmd.arguments[0];
    NSString *eventUrl = cmd.arguments[1];
    NSString *imageUrl = cmd.arguments[2];
    NSString *description = cmd.arguments[3];
    
    UIViewController *rootViewController = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
    dialog.fromViewController = rootViewController;
    dialog.delegate = self;
    
    FBSDKShareLinkContent *content = [[FBSDKShareLinkContent alloc] init];
    content.contentURL = [NSURL URLWithString:eventUrl];
    content.contentTitle = [event objectForKey:@"title"];
    content.contentDescription = description;
    content.imageURL = [NSURL URLWithString:imageUrl];
    dialog.shareContent = content;
    dialog.mode = FBSDKShareDialogModeShareSheet;
    
    
    [dialog show];
    
}

-(void) sharer:	(id<FBSDKSharing>)sharer didCompleteWithResults:	(NSDictionary *)results;
{
    if(currentCallback != nil)
    {
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCallback];
    }
    currentCallback = nil;
}


-(void) sharerDidCancel:(id<FBSDKSharing>)sharer
{
    if(currentCallback != nil)
    {
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCallback];
    }
    currentCallback = nil;
}

-(void) sharer:	(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error
{
    if(currentCallback != nil)
    {
        NSLog(@"FB sharing error: %@", error);
        NSDictionary *returnObj = [NSDictionary dictionaryWithObjectsAndKeys: error, @"message", nil];
        CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:returnObj];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:currentCallback];
    }
    currentCallback = nil;
}


@end
