#import <Foundation/Foundation.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <Cordova/CDV.h>

@interface FacebookSharePlugin : CDVPlugin <FBSDKSharingDelegate>
{
    NSString* currentCallback;
}
    - (void) shareActivity:(CDVInvokedUrlCommand *)command;
- (void) shareEvent:(CDVInvokedUrlCommand *)command;
@end
