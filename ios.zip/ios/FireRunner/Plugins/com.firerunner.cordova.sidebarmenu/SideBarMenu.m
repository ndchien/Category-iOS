#import "SideBarMenu.h"
#import "SWRevealViewController.h"
#import <objc/runtime.h>

@implementation SideBarMenu

- (id)init
{
    self = [super init];
    if (self)
    {
    }
    return self;
}


- (void) setMenuItems:(CDVInvokedUrlCommand *)cmd
{
    UIViewController *controller = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    rootViewController = (SWRevealViewController *) controller;
    tableViewController = (SidebarTableViewController*) rootViewController.rearViewController;
    tableViewController.menuItems = [cmd.arguments objectAtIndex:0];
    
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:cmd.callbackId];
    
}

- (void) setBackgroundColor:(CDVInvokedUrlCommand *)cmd
{
    unsigned int rgbValue = 0;
    NSScanner* scanner = [NSScanner scannerWithString:[cmd.arguments objectAtIndex:0]];
    [scanner setScanLocation:1];
    [scanner scanHexInt:&rgbValue];
    
    UIColor *color = [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
    
    
    UIViewController *controller = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    rootViewController = (SWRevealViewController *) controller;
    rootViewController.frontViewShadowOpacity = 0;
    tableViewController = (SidebarTableViewController*) rootViewController.rearViewController;
    
    tableViewController.view.backgroundColor = color;
    tableViewController.bgColor = color;
    
        
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:cmd.callbackId];
    
}

- (void) toggle:(CDVInvokedUrlCommand *)cmd
{
    [rootViewController revealToggleAnimated:YES];
    
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:cmd.callbackId];
    
}


@end
