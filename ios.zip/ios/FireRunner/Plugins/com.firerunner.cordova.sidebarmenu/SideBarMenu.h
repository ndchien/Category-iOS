#import <Foundation/Foundation.h>
#import <Cordova/CDV.h>
#import "SWRevealViewController.h"
#import "SidebarTableViewController.h"

@interface SideBarMenu : CDVPlugin
{
    SWRevealViewController *rootViewController;
    SidebarTableViewController *tableViewController;
}
- (void) setMenuItems:(CDVInvokedUrlCommand *)command;
- (void) setBackgroundColor:(CDVInvokedUrlCommand *)command;
- (void) toggle:(CDVInvokedUrlCommand *)command;
@end
