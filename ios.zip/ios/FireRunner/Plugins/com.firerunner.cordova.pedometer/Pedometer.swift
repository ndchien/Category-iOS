//
//  Pedometer.swift
//  FireRunner
//
//  Created by Artem Lakomov on 9/21/14.
//
//

import Foundation
import CoreLocation
import CoreMotion

@available(iOS 8.0, *)
public class Pedometer: CDVPlugin {
    
    var stepCounter = CMPedometer()
    var runStarted = NSDate(timeIntervalSince1970: 0)
    var lastRunSteps = 0
    var bioProfile : NSDictionary?
    let defaultStride = 0.75
    let maxHistoryDays = 7
    
    
    func initialize(command: CDVInvokedUrlCommand){
        let pluginResult = CDVPluginResult(status: CDVCommandStatus_OK)

        if(command.arguments.count > 0){

            self.bioProfile = command.arguments[0] as? NSDictionary

            print(self.bioProfile)

        }

        commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)

    }

    

    func isSupported(command: CDVInvokedUrlCommand){
        
        let res = NSDictionary(object: CMPedometer.isStepCountingAvailable(), forKey: "isSupported")
        
        let pluginResult = CDVPluginResult(status:CDVCommandStatus_OK, messageAsDictionary:res as [NSObject : AnyObject])

        commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)

    }

    

    func start(command: CDVInvokedUrlCommand){

     self.commandDelegate!.runInBackground {

            if(CMPedometer.isStepCountingAvailable()){

                self.stepCounter.startPedometerUpdatesFromDate(NSDate(), withHandler: {

                    data, error in

                    if(data != nil){

                        self.lastRunSteps = data!.numberOfSteps as Int

                    }

                })

            }

            self.runStarted = NSDate()

            

            let pluginResult = CDVPluginResult(status: CDVCommandStatus_OK)

            self.commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)

        }

    }

    
    func stop(command: CDVInvokedUrlCommand){

        self.runStarted = NSDate(timeIntervalSince1970: 0)

        self.lastRunSteps = 0

        if(CMPedometer.isStepCountingAvailable()){

            self.stepCounter.stopPedometerUpdates()

        }

        let pluginResult = CDVPluginResult(status: CDVCommandStatus_OK)

        commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)

    }

    

    func getCurrentReading(command: CDVInvokedUrlCommand){

        

        self.commandDelegate!.runInBackground {

            

            var reading = NSMutableDictionary()

            reading.setObject(0, forKey: "todayWalkingSteps")

            reading.setObject(0, forKey: "todayWalkingMinutes")

            reading.setObject(0, forKey: "todayWalkingMeters")

            reading.setObject(0, forKey: "todayRunningSteps")

            reading.setObject(0, forKey: "todayRunningMinutes")

            reading.setObject(0, forKey: "todayRunningSteps")

            reading.setObject(0, forKey: "lastRunSteps")

            reading.setObject(0, forKey: "lastRunMinutes")

            

            var now = NSDate()

            var gregorian = NSCalendar.currentCalendar()
            
            var dateComponents = gregorian.components([.Year, .Month, .Day] , fromDate:  now)

            var today = gregorian.dateFromComponents(dateComponents)

            

            if(CMPedometer.isStepCountingAvailable()){

                self.stepCounter.queryPedometerDataFromDate(today!, toDate: now, withHandler: {

                    data, error in

                    if(data != nil){

                        reading.setObject(data!.numberOfSteps, forKey: "todayWalkingSteps")

                        if(self.bioProfile?.objectForKey("stride") != nil)

                        {

                            var stride = (self.bioProfile?.objectForKey("stride") as! NSNumber).floatValue / 100

                            //println("Stride \(stride)")

                            var meters = ((data!.numberOfSteps.floatValue * stride) as NSNumber).integerValue

                            //println("Meters \(meters)")

                            if(stride > 0){

                                reading.setObject(meters, forKey: "todayWalkingMeters")

                            }

                        }

                    }

                    if(self.runStarted.timeIntervalSince1970 != 0){

                        reading.setObject(self.lastRunSteps, forKey: "lastRunSteps")

                    }

                    

                    var pluginResult = CDVPluginResult(status: CDVCommandStatus_OK, messageAsDictionary  : reading as [NSObject : AnyObject])

                    self.commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)   

                    

                })

            } else {

                var pluginResult = CDVPluginResult(status: CDVCommandStatus_OK, messageAsDictionary  : reading as [NSObject : AnyObject])

                self.commandDelegate!.sendPluginResult(pluginResult, callbackId:command.callbackId)

            }

        }

        

    }

    

    func getReadingHistory(command: CDVInvokedUrlCommand){

        

        self.commandDelegate!.runInBackground {

            

            let readings = NSMutableArray()

            self.getDayReading(0, readings: readings, cmd: command)

            

        }

        

    }

    

    func getDayReading(dayIndex: Int, readings: NSMutableArray, cmd: CDVInvokedUrlCommand)

    {
        
        

        var past = NSDate(timeIntervalSinceNow: Double(-1*24*60*60 * dayIndex) )

        var gregorian = NSCalendar.currentCalendar()
        
        var dateComponents = gregorian.components([.Year, .Month, .Day] , fromDate:  past)

        
        var dateStart = gregorian.dateFromComponents(dateComponents)
        var dateEnd = dateStart?.dateByAddingTimeInterval(24*60*60)
        
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        var stringDate = dateFormatter.stringFromDate(dateStart!)
        
        var reading = NSMutableDictionary()
        reading.setObject(stringDate, forKey: "date")
        reading.setObject(0, forKey: "todayWalkingSteps")
        reading.setObject(0, forKey: "todayWalkingMinutes")
        reading.setObject(0, forKey: "todayWalkingMeters")
        reading.setObject(0, forKey: "todayRunningSteps")
        reading.setObject(0, forKey: "todayRunningMinutes")
        reading.setObject(0, forKey: "todayRunningSteps")
        reading.setObject(0, forKey: "lastRunSteps")
        reading.setObject(0, forKey: "lastRunMinutes")
        
        if(CMPedometer.isStepCountingAvailable()){
            self.stepCounter.queryPedometerDataFromDate(dateStart!, toDate: dateEnd!, withHandler: {
                data, error in
                if(data != nil){
                    reading.setObject(data!.numberOfSteps, forKey: "todayWalkingSteps")
                    if(self.bioProfile?.objectForKey("stride") != nil)
                    {
                        var stride = (self.bioProfile?.objectForKey("stride") as! NSNumber).floatValue / 100
                        //println("Stride \(stride)")
                        var meters = ((data!.numberOfSteps.floatValue * stride) as NSNumber).integerValue
                        //println("Meters \(meters)")
                        if(stride > 0){
                            reading.setObject(meters, forKey: "todayWalkingMeters")
                        }
                    }
                    readings.addObject(reading)
                }
                if(dayIndex < self.maxHistoryDays) {
                    self.getDayReading(dayIndex + 1, readings: readings, cmd: cmd) }
                else {
                    var pluginResult = CDVPluginResult(status: CDVCommandStatus_OK,   messageAsArray  : readings as [AnyObject] )
                    self.commandDelegate!.sendPluginResult(pluginResult, callbackId:cmd.callbackId)
                }
            })
        }
        
    }
}

