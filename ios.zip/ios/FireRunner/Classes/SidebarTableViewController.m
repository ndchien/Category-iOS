//
//  SidebarTableViewController.m
//  SidebarDemo
//
//  Created by Simon Ng on 10/11/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import "SidebarTableViewController.h"
#import "SWRevealViewController.h"
#import <Cordova/CDVViewController.h>


@interface SidebarTableViewController ()

@end


@implementation SidebarTableViewController

@synthesize bgColor, menuItems;

- (void)viewDidLoad {
    [super viewDidLoad];   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return menuItems.count + 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    cell.backgroundColor = self.bgColor;
    NSInteger number = indexPath.item;
    
    if(number > 0){
        
        NSDictionary *menuItem = (NSDictionary *)[menuItems objectAtIndex:(number - 1)];
        
        UIButton *button = [[UIButton alloc] init];
        
        button.titleLabel.font = [UIFont fontWithName:@"Lato-Regular" size:20.0f];
        [button setTitle:[menuItem objectForKey:@"title"] forState:UIControlStateNormal];
                
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        
        button.contentEdgeInsets = UIEdgeInsetsMake(10.0f, 50.0f, 0.0f, 10.0f);
        button.tag = number - 1;
        
        [cell addSubview:button];
        [button sizeToFit];
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 30,40)];
        [lbl setTextColor:[UIColor whiteColor]];
        lbl.font = [UIFont fontWithName:@"icomoon" size:20.0f];
        NSString *ico = [self icon:[menuItem objectForKey:@"icon"]];
        lbl.text = ico;
        [cell addSubview:lbl];
        
        
        
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger number = indexPath.item;
    return number == 0 ? 50.0f : 45.0f;
}

- (NSIndexPath *)tableView:(UITableView *)tableView
  willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

-(void)buttonAction:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    NSDictionary *menuItem = (NSDictionary *)[menuItems objectAtIndex:btn.tag];
    
    UIViewController *controller = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    SWRevealViewController *rootViewController = (SWRevealViewController *) controller;
    CDVViewController *cordovaController = (CDVViewController*) rootViewController.frontViewController;
    
    NSString *url = [cordovaController.webView stringByEvaluatingJavaScriptFromString:@"window.location.href"];
    NSString *hash = [cordovaController.webView stringByEvaluatingJavaScriptFromString:@"window.location.hash"];
    
    NSString *newUrl = [url stringByReplacingOccurrencesOfString:hash withString:[menuItem objectForKey:@"url"]];
    
    [cordovaController.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:newUrl ]]];
    
    [rootViewController revealToggleAnimated:YES];
}

-(NSString*)icon:(NSString*)name
{
    const char* icn;
    
    if([name isEqualToString:@"home"])
    {
        icn = "\uE60b";
    }
    else if([name isEqualToString:@"running"])
    {
        icn = "\uE607";
    }
    else if([name isEqualToString:@"events"])
    {
        icn = "\uE609";
    }
    else if([name isEqualToString:@"biodata"])
    {
        icn = "\uE608";
    }
    else if([name isEqualToString:@"social"])
    {
        icn = "\uE610";
    }
    else if([name isEqualToString:@"news"])
    {
        icn = "\uE60C";
    }
    else if([name isEqualToString:@"getfit"])
    {
        icn = "\uE614";
    }
    else if([name isEqualToString:@"menu_profile_icon"])
    {
        icn = "\uE612";
    }
    else
    {
        icn = "\uE60b";
    }
    
    return [NSString stringWithUTF8String:icn];
}


@end
